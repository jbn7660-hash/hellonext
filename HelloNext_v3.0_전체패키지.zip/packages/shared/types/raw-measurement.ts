/** Layer A: Raw Measurement (DC-1, DC-3 — Immutable) */
export interface RawMeasurement {
  readonly id: string;
  readonly session_id: string;
  readonly frame_index: number;
  readonly spatial_data: SpatialData;
  readonly measurement_confidence: number | null;
  readonly source_model: string;
  readonly source_version: string;
  readonly created_at: string;
}

export interface SpatialData {
  keypoints: Keypoint[];
  joint_angles: Record<string, number>;
  visibility_scores: Record<string, number>;
}

export interface Keypoint {
  name: string;
  x: number;
  y: number;
  z?: number;
  visibility: number;
}
