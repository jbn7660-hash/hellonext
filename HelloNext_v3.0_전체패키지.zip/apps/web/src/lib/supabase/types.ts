/**
 * Supabase Database Types
 *
 * Auto-generated type definitions for the HelloNext database schema.
 * In production, regenerate with: supabase gen types typescript --local > types.ts
 *
 * @module lib/supabase/types
 */

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export type UserRole = 'pro' | 'member';
export type ProTier = 'starter' | 'pro' | 'academy';
export type MemoStatus = 'recording' | 'transcribing' | 'structuring' | 'draft' | 'published';
export type ReportStatus = 'draft' | 'published' | 'read';
export type LinkStatus = 'invited' | 'active' | 'removed';
export type VideoSource = 'camera' | 'gallery' | 'simulator';
export type Feeling = 'good' | 'unsure' | 'off';
export type AiTone = 'observe' | 'suggest' | 'guide';
export type CouponType = 'plg' | 'purchased';
export type CouponStatus = 'unused' | 'assigned' | 'redeemed' | 'expired';
export type SubscriptionTier = 'pro' | 'academy';
export type SubscriptionStatus = 'active' | 'past_due' | 'cancelled';
export type PaymentType = 'subscription' | 'coupon_bundle';
export type PaymentStatus = 'completed' | 'refunded' | 'failed';
export type NotificationType = 'report' | 'reminder' | 'coupon' | 'system';

export interface Database {
  public: {
    Tables: {
      pro_profiles: {
        Row: {
          id: string;
          user_id: string;
          display_name: string;
          studio_name: string | null;
          specialty: string | null;
          tier: ProTier;
          plg_coupons_remaining: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          display_name: string;
          studio_name?: string | null;
          specialty?: string | null;
          tier?: ProTier;
          plg_coupons_remaining?: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          display_name?: string;
          studio_name?: string | null;
          specialty?: string | null;
          tier?: ProTier;
          plg_coupons_remaining?: number;
          updated_at?: string;
        };
      };
      member_profiles: {
        Row: {
          id: string;
          user_id: string;
          display_name: string;
          is_premium: boolean;
          premium_expires_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          display_name: string;
          is_premium?: boolean;
          premium_expires_at?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          display_name?: string;
          is_premium?: boolean;
          premium_expires_at?: string | null;
          updated_at?: string;
        };
      };
      pro_member_links: {
        Row: {
          id: string;
          pro_id: string;
          member_id: string | null;
          invite_code: string;
          status: LinkStatus;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          pro_id: string;
          member_id?: string | null;
          invite_code: string;
          status?: LinkStatus;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          pro_id?: string;
          member_id?: string | null;
          invite_code?: string;
          status?: LinkStatus;
          updated_at?: string;
        };
      };
      voice_memos: {
        Row: {
          id: string;
          pro_id: string;
          member_id: string | null;
          audio_url: string;
          duration_sec: number;
          transcript: string | null;
          structured_json: Json | null;
          status: MemoStatus;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          pro_id: string;
          member_id?: string | null;
          audio_url: string;
          duration_sec: number;
          transcript?: string | null;
          structured_json?: Json | null;
          status?: MemoStatus;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          pro_id?: string;
          member_id?: string | null;
          audio_url?: string;
          duration_sec?: number;
          transcript?: string | null;
          structured_json?: Json | null;
          status?: MemoStatus;
          updated_at?: string;
        };
      };
      reports: {
        Row: {
          id: string;
          voice_memo_id: string | null;
          pro_id: string;
          member_id: string;
          link_id: string;
          title: string;
          content: Json;
          error_tags: Json;
          homework: string | null;
          status: ReportStatus;
          published_at: string | null;
          read_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          voice_memo_id?: string | null;
          pro_id: string;
          member_id: string;
          link_id: string;
          title: string;
          content?: Json;
          error_tags?: Json;
          homework?: string | null;
          status?: ReportStatus;
          published_at?: string | null;
          read_at?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          voice_memo_id?: string | null;
          pro_id?: string;
          member_id?: string;
          link_id?: string;
          title?: string;
          content?: Json;
          error_tags?: Json;
          homework?: string | null;
          status?: ReportStatus;
          published_at?: string | null;
          read_at?: string | null;
          updated_at?: string;
        };
      };
      swing_videos: {
        Row: {
          id: string;
          member_id: string;
          cloudinary_id: string;
          video_url: string;
          thumbnail_url: string | null;
          duration_sec: number | null;
          source: VideoSource;
          created_at: string;
        };
        Insert: {
          id?: string;
          member_id: string;
          cloudinary_id: string;
          video_url: string;
          thumbnail_url?: string | null;
          duration_sec?: number | null;
          source?: VideoSource;
          created_at?: string;
        };
        Update: {
          id?: string;
          member_id?: string;
          cloudinary_id?: string;
          video_url?: string;
          thumbnail_url?: string | null;
          duration_sec?: number | null;
          source?: VideoSource;
        };
      };
      pose_data: {
        Row: {
          id: string;
          video_id: string;
          keypoints: Json;
          angles: Json;
          metrics: Json | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          video_id: string;
          keypoints: Json;
          angles: Json;
          metrics?: Json | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          video_id?: string;
          keypoints?: Json;
          angles?: Json;
          metrics?: Json | null;
        };
      };
      feel_checks: {
        Row: {
          id: string;
          video_id: string;
          member_id: string;
          feeling: Feeling;
          feel_accuracy: number | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          video_id: string;
          member_id: string;
          feeling: Feeling;
          feel_accuracy?: number | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          video_id?: string;
          member_id?: string;
          feeling?: Feeling;
          feel_accuracy?: number | null;
        };
      };
      ai_observations: {
        Row: {
          id: string;
          video_id: string;
          member_id: string;
          pro_id: string | null;
          observation_text: string;
          tone: AiTone;
          coach_consultation_flag: boolean;
          visible_tags: Json;
          hidden_tags: Json;
          created_at: string;
        };
        Insert: {
          id?: string;
          video_id: string;
          member_id: string;
          pro_id?: string | null;
          observation_text: string;
          tone?: AiTone;
          coach_consultation_flag?: boolean;
          visible_tags?: Json;
          hidden_tags?: Json;
          created_at?: string;
        };
        Update: {
          id?: string;
          video_id?: string;
          member_id?: string;
          pro_id?: string | null;
          observation_text?: string;
          tone?: AiTone;
          coach_consultation_flag?: boolean;
          visible_tags?: Json;
          hidden_tags?: Json;
        };
      };
      ai_scope_settings: {
        Row: {
          id: string;
          pro_id: string;
          member_id: string;
          visible_error_patterns: Json;
          ai_tone: AiTone;
          updated_at: string;
        };
        Insert: {
          id?: string;
          pro_id: string;
          member_id: string;
          visible_error_patterns?: Json;
          ai_tone?: AiTone;
          updated_at?: string;
        };
        Update: {
          id?: string;
          pro_id?: string;
          member_id?: string;
          visible_error_patterns?: Json;
          ai_tone?: AiTone;
          updated_at?: string;
        };
      };
      coupons: {
        Row: {
          id: string;
          pro_id: string;
          code: string;
          type: CouponType;
          status: CouponStatus;
          assigned_member_id: string | null;
          expires_at: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          pro_id: string;
          code: string;
          type: CouponType;
          status?: CouponStatus;
          assigned_member_id?: string | null;
          expires_at: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          pro_id?: string;
          code?: string;
          type?: CouponType;
          status?: CouponStatus;
          assigned_member_id?: string | null;
          expires_at?: string;
        };
      };
      coupon_redemptions: {
        Row: {
          id: string;
          coupon_id: string;
          member_id: string;
          premium_days: number;
          redeemed_at: string;
        };
        Insert: {
          id?: string;
          coupon_id: string;
          member_id: string;
          premium_days?: number;
          redeemed_at?: string;
        };
        Update: {
          id?: string;
          coupon_id?: string;
          member_id?: string;
          premium_days?: number;
          redeemed_at?: string;
        };
      };
      subscriptions: {
        Row: {
          id: string;
          pro_id: string;
          tier: SubscriptionTier;
          status: SubscriptionStatus;
          toss_billing_key: string | null;
          current_period_start: string;
          current_period_end: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          pro_id: string;
          tier: SubscriptionTier;
          status?: SubscriptionStatus;
          toss_billing_key?: string | null;
          current_period_start: string;
          current_period_end: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          pro_id?: string;
          tier?: SubscriptionTier;
          status?: SubscriptionStatus;
          toss_billing_key?: string | null;
          current_period_start?: string;
          current_period_end?: string;
          updated_at?: string;
        };
      };
      payments: {
        Row: {
          id: string;
          user_id: string;
          toss_payment_key: string | null;
          amount: number;
          type: PaymentType;
          status: PaymentStatus;
          metadata: Json | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          toss_payment_key?: string | null;
          amount: number;
          type: PaymentType;
          status?: PaymentStatus;
          metadata?: Json | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          toss_payment_key?: string | null;
          amount?: number;
          type?: PaymentType;
          status?: PaymentStatus;
          metadata?: Json | null;
        };
      };
      notifications: {
        Row: {
          id: string;
          user_id: string;
          type: NotificationType;
          title: string;
          body: string | null;
          data: Json | null;
          is_read: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          type: NotificationType;
          title: string;
          body?: string | null;
          data?: Json | null;
          is_read?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          type?: NotificationType;
          title?: string;
          body?: string | null;
          data?: Json | null;
          is_read?: boolean;
        };
      };
      error_patterns: {
        Row: {
          id: number;
          code: string;
          name_ko: string;
          name_en: string;
          description: string | null;
          position: string;
          causality_parents: Json;
        };
        Insert: {
          id?: number;
          code: string;
          name_ko: string;
          name_en: string;
          description?: string | null;
          position: string;
          causality_parents?: Json;
        };
        Update: {
          id?: number;
          code?: string;
          name_ko?: string;
          name_en?: string;
          description?: string | null;
          position?: string;
          causality_parents?: Json;
        };
      };
      glossary_terms: {
        Row: {
          id: string;
          pro_id: string;
          original_term: string;
          standardized_term: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          pro_id: string;
          original_term: string;
          standardized_term: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          pro_id?: string;
          original_term?: string;
          standardized_term?: string;
        };
      };
    };
    Functions: {
      get_my_pro_id: {
        Args: Record<string, never>;
        Returns: string;
      };
      get_my_member_id: {
        Args: Record<string, never>;
        Returns: string;
      };
    };
    Enums: Record<string, never>;
  };
}

/** Convenience type aliases */
export type Tables<T extends keyof Database['public']['Tables']> =
  Database['public']['Tables'][T]['Row'];
export type InsertTables<T extends keyof Database['public']['Tables']> =
  Database['public']['Tables'][T]['Insert'];
export type UpdateTables<T extends keyof Database['public']['Tables']> =
  Database['public']['Tables'][T]['Update'];
