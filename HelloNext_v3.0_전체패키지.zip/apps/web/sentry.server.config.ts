/**
 * Sentry Server Configuration (v3.0 Patent Engine Monitoring)
 * API route monitoring, database query tracking, Edge Function instrumentation
 *
 * Auto-loaded by @sentry/nextjs
 */

import * as Sentry from '@sentry/nextjs';

Sentry.init({
  // DSN Configuration
  dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,
  enabled: process.env.NODE_ENV === 'production',
  environment: process.env.NODE_ENV,

  // Version tracking
  release: process.env.NEXT_PUBLIC_APP_VERSION || '2.0.0',

  // Higher sampling rate for server-side (more events available)
  tracesSampleRate: process.env.NODE_ENV === 'production' ? 0.3 : 1.0,

  // Server-side integrations
  integrations: [
    // HTTP request monitoring with request context
    Sentry.requestDataIntegration({
      include: {
        cookies: false,
        headers: true,
        query_string: true,
        url: true,
        body: true,
      },
    }),

    // Continuous profiling for hot paths
    Sentry.profilerIntegration(),

    // Capture unhandled promise rejections
    Sentry.captureConsoleIntegration({
      levels: ['error', 'warn'],
    }),
  ],

  // Database and API error handling
  beforeSend(event) {
    // Sanitize sensitive headers
    if (event.request?.headers) {
      delete event.request.headers['authorization'];
      delete event.request.headers['cookie'];
      delete event.request.headers['x-api-key'];
      delete event.request.headers['x-supabase-auth'];
    }

    // Strip Korean PII patterns from body/message
    if (event.message) {
      // Phone number pattern: 010-1234-5678
      event.message = event.message.replace(/\d{2,3}-\d{3,4}-\d{4}/g, 'XXX-XXXX-XXXX');
      // Name patterns (2-4 Korean characters at word boundaries)
      event.message = event.message.replace(/[\uAC00-\uD7A3]{2,4}(?=\s|$)/g, 'XXXXX');
    }

    // Enhance patent engine API context
    if (event.request?.url?.includes('/api/patents') || event.request?.url?.includes('/patent-engine')) {
      event.tags = {
        ...event.tags,
        'patent.engine': 'api-route',
        'patent.critical': 'true',
      };
      event.contexts = {
        ...event.contexts,
        patent_api: {
          route: extractPatentRoute(event.request?.url || ''),
          method: event.request?.method,
        },
      };
    }

    // Track Edge Function invocations
    if (
      event.request?.url?.includes('/edge/') ||
      event.request?.url?.includes('/.vercel/functions') ||
      event.request?.url?.includes('supabase.co/functions')
    ) {
      event.tags = {
        ...event.tags,
        'patent.engine': 'edge-function',
        'serverless.runtime': 'edge',
      };
      event.contexts = {
        ...event.contexts,
        edge_function: {
          function_name: extractEdgeFunctionName(event.request?.url || ''),
          invocation_time: new Date().toISOString(),
        },
      };
    }

    // Track health check endpoints (lower priority)
    if (event.request?.url?.includes('/api/health')) {
      event.level = 'info';
      return null; // Don't send health check errors
    }

    return event;
  },

  // Breadcrumb enrichment
  beforeBreadcrumb(breadcrumb) {
    // Track database query performance
    if (breadcrumb.category === 'db.query' || breadcrumb.category === 'database') {
      breadcrumb.category = 'database';
      breadcrumb.data = {
        ...breadcrumb.data,
        'patent.engine': 'database',
        'query_type': extractQueryType(breadcrumb.message || ''),
      };
    }

    // Track Supabase specific queries
    if (breadcrumb.data?.url?.includes('supabase')) {
      breadcrumb.category = 'database.supabase';
      breadcrumb.data = {
        ...breadcrumb.data,
        'table': extractTableName(breadcrumb.data?.url || ''),
      };
    }

    // Filter noisy breadcrumbs
    if (breadcrumb.category === 'fetch' && breadcrumb.data?.url?.includes('health')) {
      return null;
    }

    return breadcrumb;
  },

  // Tracing origins
  tracingOrigins: [
    'localhost',
    'arcup.local',
    'arcup.dev',
    /supabase\.co/,
    /vercel\.app/,
    /^\//,
  ],

  // Database monitoring
  attachStacktrace: true,
  maxBreadcrumbs: 100,

  // Profiling configuration
  profilesSampleRate: process.env.NODE_ENV === 'production' ? 0.2 : 0.5,

  // Performance monitoring for specific operations
  tracesSampler(samplingContext) {
    // Higher sampling for patent engine critical paths
    if (samplingContext.transactionContext.op?.includes('patent')) {
      return 1.0;
    }
    // Higher sampling for database operations
    if (samplingContext.transactionContext.op?.includes('db')) {
      return 0.5;
    }
    // Lower sampling for health checks
    if (samplingContext.transactionContext.name?.includes('health')) {
      return 0.05;
    }
    return 0.3;
  },
});

// Helper functions for context extraction

function extractPatentRoute(url: string): string {
  if (url.includes('/api/fsm')) return 'fsm-controller';
  if (url.includes('/api/causal')) return 'causal-analysis';
  if (url.includes('/api/confidence')) return 'measurement-confidence';
  if (url.includes('/api/verification')) return 'verification-handler';
  if (url.includes('/api/edge-weight')) return 'edge-weight-calibration';
  return 'patent-engine';
}

function extractEdgeFunctionName(url: string): string {
  const match = url.match(/functions\/v1\/([^/?]+)/);
  return match ? match[1] : 'unknown';
}

function extractQueryType(message: string): string {
  if (message.includes('SELECT')) return 'select';
  if (message.includes('INSERT')) return 'insert';
  if (message.includes('UPDATE')) return 'update';
  if (message.includes('DELETE')) return 'delete';
  return 'unknown';
}

function extractTableName(url: string): string {
  const match = url.match(/rest\/v\d+\/([^/?]+)/);
  return match ? match[1] : 'unknown';
}

// Create a custom transaction wrapper for API routes
export function createApiTransaction(name: string, op: string = 'http.server') {
  return Sentry.startTransaction({
    name,
    op,
    tags: {
      'patent.engine': 'api-route',
    },
  });
}
