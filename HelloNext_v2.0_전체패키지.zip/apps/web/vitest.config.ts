/**
 * Vitest Configuration
 *
 * Test pyramid: Unit (70%) / Integration (20%) / E2E (10%)
 * Coverage target: 80%+ on core business logic
 */

import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  test: {
    globals: true,
    environment: 'jsdom',
    setupFiles: ['./src/__tests__/setup.ts'],
    include: [
      'src/__tests__/unit/**/*.test.{ts,tsx}',
      'src/__tests__/integration/**/*.test.{ts,tsx}',
    ],
    exclude: ['src/__tests__/e2e/**'],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'json', 'html'],
      include: [
        'src/lib/**/*.ts',
        'src/hooks/**/*.ts',
        'src/app/api/**/*.ts',
        'src/components/**/*.tsx',
      ],
      exclude: [
        'src/__tests__/**',
        'src/**/*.d.ts',
        'src/lib/supabase/types.ts',
      ],
      thresholds: {
        // Core business logic: 80%+
        'src/lib/payments/': { branches: 80, functions: 80, lines: 80 },
        'src/lib/utils/': { branches: 80, functions: 80, lines: 80 },
      },
    },
    alias: {
      '@': path.resolve(__dirname, './src'),
      '@hellonext/shared': path.resolve(__dirname, '../../packages/shared/src'),
    },
  },
});
