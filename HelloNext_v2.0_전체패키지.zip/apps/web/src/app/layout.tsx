/**
 * Root Layout
 *
 * Global layout wrapping all pages. Handles:
 * - Metadata for SEO and PWA manifest
 * - Global CSS import
 * - Font loading (Pretendard)
 * - Viewport configuration for mobile PWA
 */

import type { Metadata, Viewport } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: {
    default: 'HelloNext - Golf Coaching Platform',
    template: '%s | HelloNext',
  },
  description: '프로와 회원을 연결하는 AI 골프 코칭 플랫폼',
  manifest: '/manifest.json',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'default',
    title: 'HelloNext',
  },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: 'cover',
  themeColor: '#22c55e',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ko" suppressHydrationWarning>
      <body className="min-h-screen">
        {children}
      </body>
    </html>
  );
}
