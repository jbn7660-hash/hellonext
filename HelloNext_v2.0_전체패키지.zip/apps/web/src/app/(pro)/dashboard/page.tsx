/**
 * Pro Dashboard Page (F-002)
 *
 * Main landing page for pros. Shows:
 *  - Quick stats (total members, pending reports, orphan memos)
 *  - AI warnings banner (from feel-checks / ai_observations)
 *  - Member list with activity summary
 *  - Quick-record per member
 *
 * @page /dashboard
 * @feature F-002, F-003
 */

'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/hooks/use-auth';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { EmptyState } from '@/components/ui/empty-state';
import { formatRelativeTime } from '@/lib/utils/format';
import { cn } from '@/lib/utils/cn';
import { logger } from '@/lib/utils/logger';

interface MemberSummary {
  id: string;
  display_name: string;
  avatar_url: string | null;
  handicap: number | null;
  recent_report_count: number;
  pending_memo_count: number;
  latest_feel_check: {
    feeling: string;
    created_at: string;
  } | null;
}

interface DashboardStats {
  totalMembers: number;
  pendingReports: number;
  orphanMemos: number;
}

export default function ProDashboardPage() {
  const router = useRouter();
  const { profile, isAuthenticated, loading: authLoading } = useAuth();
  const [members, setMembers] = useState<MemberSummary[]>([]);
  const [stats, setStats] = useState<DashboardStats>({ totalMembers: 0, pendingReports: 0, orphanMemos: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (authLoading || !isAuthenticated) return;

    const fetchDashboard = async () => {
      try {
        const [membersRes, orphanRes] = await Promise.all([
          fetch('/api/members'),
          fetch('/api/voice-memos?orphan=true'),
        ]);

        if (membersRes.ok) {
          const { data } = await membersRes.json();
          setMembers(data ?? []);
          setStats((prev) => ({
            ...prev,
            totalMembers: (data ?? []).length,
            pendingReports: (data ?? []).reduce(
              (sum: number, m: MemberSummary) => sum + m.pending_memo_count,
              0
            ),
          }));
        }

        if (orphanRes.ok) {
          const { data } = await orphanRes.json();
          setStats((prev) => ({ ...prev, orphanMemos: (data ?? []).length }));
        }
      } catch (err) {
        logger.error('Dashboard fetch error', { error: err });
      } finally {
        setLoading(false);
      }
    };

    fetchDashboard();
  }, [authLoading, isAuthenticated]);

  if (authLoading || loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingSpinner size="lg" label="대시보드 로딩 중..." />
      </div>
    );
  }

  return (
    <div className="px-5 pt-safe-top">
      {/* Header */}
      <header className="pt-4 pb-6">
        <p className="text-sm text-text-secondary">안녕하세요,</p>
        <h1 className="text-xl font-bold text-text-primary">
          {(profile as { studio_name?: string })?.studio_name ?? '프로'}님
        </h1>
      </header>

      {/* Stats Cards */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <StatCard label="회원" value={stats.totalMembers} />
        <StatCard label="진행 중 메모" value={stats.pendingReports} accent={stats.pendingReports > 0} />
        <StatCard
          label="고아 메모"
          value={stats.orphanMemos}
          accent={stats.orphanMemos > 0}
          warning={stats.orphanMemos > 3}
        />
      </div>

      {/* AI Warnings Banner */}
      <AIWarningsBanner members={members} />

      {/* Member List */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-base font-semibold text-text-primary">회원 목록</h2>
          <span className="text-xs text-text-tertiary">{members.length}명</span>
        </div>

        {members.length === 0 ? (
          <EmptyState
            title="등록된 회원이 없습니다"
            description="초대 링크를 보내 회원을 추가해보세요."
            action={
              <button type="button" className="btn-primary text-sm px-4 py-2">
                회원 초대
              </button>
            }
          />
        ) : (
          <div className="space-y-2">
            {members.map((member) => (
              <MemberCard
                key={member.id}
                member={member}
                onTap={() => router.push(`/reports?member=${member.id}`)}
              />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

/* ---------- Sub-components ---------- */

function StatCard({
  label,
  value,
  accent,
  warning,
}: {
  label: string;
  value: number;
  accent?: boolean;
  warning?: boolean;
}) {
  return (
    <div className={cn(
      'card p-3 text-center',
      warning && 'border-status-warning/30 bg-status-warning/5'
    )}>
      <p className={cn(
        'text-2xl font-bold',
        warning ? 'text-status-warning' : accent ? 'text-brand-primary' : 'text-text-primary'
      )}>
        {value}
      </p>
      <p className="text-xs text-text-secondary mt-0.5">{label}</p>
    </div>
  );
}

function MemberCard({
  member,
  onTap,
}: {
  member: MemberSummary;
  onTap: () => void;
}) {
  const feelEmoji: Record<string, string> = {
    good: '😊',
    unsure: '😐',
    off: '😟',
  };

  return (
    <button
      type="button"
      onClick={onTap}
      className="w-full card p-4 flex items-center gap-3 text-left hover:border-brand-primary/30 transition-colors"
    >
      {/* Avatar */}
      <div className="w-10 h-10 rounded-full bg-brand-primary/10 flex items-center justify-center text-brand-primary font-semibold text-sm shrink-0">
        {member.display_name.charAt(0)}
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="font-medium text-sm text-text-primary truncate">
            {member.display_name}
          </span>
          {member.handicap != null && (
            <span className="text-xs text-text-tertiary">HC {member.handicap}</span>
          )}
        </div>
        <div className="flex items-center gap-2 mt-0.5">
          <span className="text-xs text-text-secondary">
            리포트 {member.recent_report_count}건 (30일)
          </span>
          {member.latest_feel_check && (
            <span className="text-xs" title={`컨디션: ${member.latest_feel_check.feeling}`}>
              {feelEmoji[member.latest_feel_check.feeling] ?? ''}
            </span>
          )}
        </div>
      </div>

      {/* Pending indicator */}
      {member.pending_memo_count > 0 && (
        <div className="w-5 h-5 rounded-full bg-status-warning text-white text-[10px] font-bold flex items-center justify-center shrink-0">
          {member.pending_memo_count}
        </div>
      )}

      {/* Chevron */}
      <svg className="w-4 h-4 text-text-tertiary shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
        <polyline points="9,18 15,12 9,6" />
      </svg>
    </button>
  );
}

function AIWarningsBanner({ members }: { members: MemberSummary[] }) {
  // Show banner if any member has "off" feel check
  const warningMembers = members.filter(
    (m) => m.latest_feel_check?.feeling === 'off'
  );

  if (warningMembers.length === 0) return null;

  return (
    <div className="mb-4 p-4 rounded-xl bg-status-warning/10 border border-status-warning/20">
      <div className="flex items-start gap-2">
        <span className="text-lg">⚠️</span>
        <div>
          <p className="text-sm font-medium text-text-primary">
            컨디션 주의 회원 ({warningMembers.length}명)
          </p>
          <p className="text-xs text-text-secondary mt-0.5">
            {warningMembers.map((m) => m.display_name).join(', ')}님이 컨디션 불량을 보고했습니다.
          </p>
        </div>
      </div>
    </div>
  );
}
