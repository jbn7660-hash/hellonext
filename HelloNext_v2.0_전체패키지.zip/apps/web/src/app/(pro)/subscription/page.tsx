/**
 * Pro Subscription / Plan Page (F-008 AC-4)
 *
 * Subscription management:
 *  - Current plan display
 *  - Plan comparison (Starter/Pro/Academy)
 *  - TossPayments billing key registration
 *  - Subscription cancellation
 *  - Payment history
 *
 * @page /subscription
 * @feature F-008
 */

'use client';

import { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'next/navigation';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { SUBSCRIPTION_PLANS, TOSS_CLIENT_KEY, COUPON_BUNDLES } from '@/lib/payments/toss';
import { cn } from '@/lib/utils/cn';
import { logger } from '@/lib/utils/logger';

interface Subscription {
  plan_id: string;
  status: string;
  current_period_end?: string;
  card_info?: { issuerCode: string; number: string } | null;
}

interface Payment {
  id: string;
  amount: number;
  type: string;
  status: string;
  method: string;
  created_at: string;
  receipt_url: string | null;
}

export default function SubscriptionPage() {
  const searchParams = useSearchParams();
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);

  // Check if redirected from coupon bundle purchase
  const purchaseType = searchParams.get('purchase');
  const bundleQuantity = searchParams.get('quantity');
  const bundleAmount = searchParams.get('amount');

  const fetchData = useCallback(async () => {
    try {
      const [subRes, payRes] = await Promise.all([
        fetch('/api/subscriptions'),
        fetch('/api/payments?limit=10'),
      ]);

      if (subRes.ok) {
        const { data } = await subRes.json();
        setSubscription(data);
      }
      if (payRes.ok) {
        const { data } = await payRes.json();
        setPayments(data ?? []);
      }
    } catch (err) {
      logger.error('Subscription page fetch error', { error: err });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Auto-trigger coupon bundle payment if redirected
  useEffect(() => {
    if (purchaseType === 'coupon' && bundleQuantity && bundleAmount) {
      handleCouponBundlePurchase(parseInt(bundleQuantity, 10), parseInt(bundleAmount, 10));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [purchaseType]);

  const handleCouponBundlePurchase = async (quantity: number, amount: number) => {
    if (!TOSS_CLIENT_KEY || processing) return;
    setProcessing(true);

    try {
      // @ts-expect-error TossPayments SDK loaded via script tag
      const tossPayments = window.TossPayments(TOSS_CLIENT_KEY);
      const orderId = `coupon-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

      await tossPayments.requestPayment('카드', {
        amount,
        orderId,
        orderName: `쿠폰 ${quantity}장 번들`,
        successUrl: `${window.location.origin}/api/payments/callback?type=coupon_bundle&quantity=${quantity}`,
        failUrl: `${window.location.origin}/subscription?error=payment_failed`,
      });
    } catch (err) {
      logger.error('Coupon bundle payment error', { error: err });
    } finally {
      setProcessing(false);
    }
  };

  const handleSubscribe = async (planId: string) => {
    if (!TOSS_CLIENT_KEY || processing) return;
    setProcessing(true);

    try {
      // @ts-expect-error TossPayments SDK loaded via script tag
      const tossPayments = window.TossPayments(TOSS_CLIENT_KEY);
      const customerKey = `cust-${Date.now()}`;

      await tossPayments.requestBillingKeyAuth('카드', {
        customerKey,
        successUrl: `${window.location.origin}/api/payments/callback?type=subscription&plan=${planId}&customerKey=${customerKey}`,
        failUrl: `${window.location.origin}/subscription?error=billing_failed`,
      });
    } catch (err) {
      logger.error('Subscription billing error', { error: err });
    } finally {
      setProcessing(false);
    }
  };

  const handleCancel = async () => {
    if (!confirm('구독을 해지하시겠습니까? 현재 결제 기간이 끝날 때까지 이용 가능합니다.')) return;

    try {
      const res = await fetch('/api/subscriptions', { method: 'DELETE' });
      if (res.ok) {
        await fetchData();
      } else {
        const data = await res.json();
        alert(data.error ?? '해지에 실패했습니다.');
      }
    } catch (err) {
      logger.error('Subscription cancel error', { error: err });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <LoadingSpinner size="lg" label="플랜 정보 로딩 중..." />
      </div>
    );
  }

  const currentPlan = subscription?.plan_id ?? 'starter';

  return (
    <div className="px-5 pt-4 pb-24">
      <h2 className="text-lg font-bold text-text-primary mb-2">구독 & 플랜</h2>
      <p className="text-sm text-text-secondary mb-6">
        현재 플랜: <span className="font-semibold text-brand-primary">{getPlanName(currentPlan)}</span>
        {subscription?.status === 'canceled' && (
          <span className="text-xs text-status-error ml-2">
            (해지 예정 · {subscription.current_period_end ? new Date(subscription.current_period_end).toLocaleDateString('ko-KR') : ''}까지)
          </span>
        )}
      </p>

      {/* Plan Comparison */}
      <div className="space-y-3 mb-8">
        {SUBSCRIPTION_PLANS.map((plan) => {
          const isCurrent = plan.id === currentPlan;
          const isUpgrade = getPlanOrder(plan.id) > getPlanOrder(currentPlan);

          return (
            <div
              key={plan.id}
              className={cn(
                'card p-4 relative transition-all',
                plan.popular && 'ring-2 ring-brand-primary',
                isCurrent && 'bg-brand-primary/5'
              )}
            >
              {plan.popular && (
                <span className="absolute -top-2 right-4 bg-brand-primary text-white text-[10px] px-2 py-0.5 rounded-full">
                  추천
                </span>
              )}

              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="text-base font-bold text-text-primary">{plan.name}</h3>
                  <p className="text-sm text-text-secondary mt-0.5">
                    {plan.price === 0 ? '무료' : `${plan.price.toLocaleString()}원/월`}
                  </p>
                </div>

                {isCurrent ? (
                  <span className="text-xs bg-brand-primary/10 text-brand-primary px-2 py-1 rounded-full font-medium">
                    현재 플랜
                  </span>
                ) : isUpgrade ? (
                  <button
                    type="button"
                    onClick={() => handleSubscribe(plan.id)}
                    disabled={processing}
                    className="btn-primary text-xs px-4 py-1.5 disabled:opacity-50"
                  >
                    {processing ? '처리 중...' : '업그레이드'}
                  </button>
                ) : null}
              </div>

              <ul className="space-y-1.5">
                {plan.features.map((feature, idx) => (
                  <li key={idx} className="text-xs text-text-secondary flex items-center gap-1.5">
                    <CheckIcon className="w-3.5 h-3.5 text-status-success flex-shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          );
        })}
      </div>

      {/* Cancel Subscription */}
      {subscription?.status === 'active' && currentPlan !== 'starter' && (
        <button
          type="button"
          onClick={handleCancel}
          className="w-full text-center text-xs text-text-tertiary underline py-2 mb-8"
        >
          구독 해지
        </button>
      )}

      {/* Payment History */}
      <div>
        <h3 className="text-sm font-semibold text-text-primary mb-3">결제 내역</h3>
        {payments.length === 0 ? (
          <div className="card p-4 text-center">
            <p className="text-sm text-text-secondary">결제 내역이 없습니다</p>
          </div>
        ) : (
          <div className="space-y-2">
            {payments.map((payment) => (
              <div key={payment.id} className="card p-3 flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-text-primary">
                    {payment.type === 'coupon_bundle' ? '쿠폰 번들' : '구독 결제'}
                  </p>
                  <p className="text-[10px] text-text-tertiary">
                    {new Date(payment.created_at).toLocaleDateString('ko-KR')} · {payment.method}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-text-primary">
                    {payment.amount.toLocaleString()}원
                  </p>
                  <p className={cn(
                    'text-[10px]',
                    payment.status === 'DONE' ? 'text-status-success' : 'text-status-error'
                  )}>
                    {payment.status === 'DONE' ? '완료' : payment.status}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function getPlanName(planId: string): string {
  return SUBSCRIPTION_PLANS.find((p) => p.id === planId)?.name ?? planId;
}

function getPlanOrder(planId: string): number {
  const order: Record<string, number> = { starter: 0, pro: 1, academy: 2 };
  return order[planId] ?? 0;
}

function CheckIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
      <polyline points="20,6 9,17 4,12" />
    </svg>
  );
}
