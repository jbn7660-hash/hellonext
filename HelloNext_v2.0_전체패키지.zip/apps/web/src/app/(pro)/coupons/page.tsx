/**
 * Pro Coupon Management Page (F-008, F-012)
 *
 * Manage PLG coupons:
 *  - View coupon stats (available/activated/expired)
 *  - Generate PLG free coupons (max 3)
 *  - Purchase coupon bundles (5/10/30)
 *  - View/copy/share coupon codes
 *
 * @page /coupons
 * @feature F-008, F-012
 */

'use client';

import { useState, useEffect, useCallback } from 'react';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { EmptyState } from '@/components/ui/empty-state';
import { COUPON_BUNDLES } from '@/lib/payments/toss';
import { cn } from '@/lib/utils/cn';
import { logger } from '@/lib/utils/logger';

interface Coupon {
  id: string;
  code: string;
  source: string;
  status: string;
  activated_at: string | null;
  expires_at: string | null;
  member_user_id: string | null;
  created_at: string;
}

interface CouponStats {
  total: number;
  available: number;
  activated: number;
  expired: number;
  plg_free_used: number;
  plg_free_limit: number;
}

type FilterTab = 'all' | 'available' | 'activated' | 'expired';

export default function CouponsPage() {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [stats, setStats] = useState<CouponStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState<FilterTab>('all');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const fetchCoupons = useCallback(async () => {
    try {
      const params = new URLSearchParams();
      if (activeTab !== 'all') params.set('status', activeTab);

      const res = await fetch(`/api/coupons?${params}`);
      if (res.ok) {
        const data = await res.json();
        setCoupons(data.data ?? []);
        setStats(data.stats);
      }
    } catch (err) {
      logger.error('Coupon fetch error', { error: err });
    } finally {
      setLoading(false);
    }
  }, [activeTab]);

  useEffect(() => {
    fetchCoupons();
  }, [fetchCoupons]);

  const handleGenerateFree = async () => {
    if (generating) return;
    setGenerating(true);

    try {
      const res = await fetch('/api/coupons', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ quantity: 1, source: 'plg_free' }),
      });

      if (res.ok) {
        await fetchCoupons();
      } else {
        const data = await res.json();
        alert(data.error ?? '생성에 실패했습니다.');
      }
    } catch (err) {
      logger.error('Coupon generate error', { error: err });
    } finally {
      setGenerating(false);
    }
  };

  const handlePurchaseBundle = (bundleIndex: number) => {
    const bundle = COUPON_BUNDLES[bundleIndex];
    if (!bundle) return;
    // Navigate to payment flow (TossPayments widget)
    window.location.href = `/subscription?purchase=coupon&quantity=${bundle.quantity}&amount=${bundle.price}`;
  };

  const handleCopyCode = async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedCode(code);
      setTimeout(() => setCopiedCode(null), 2000);
    } catch {
      // Fallback
      const el = document.createElement('textarea');
      el.value = code;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      setCopiedCode(code);
      setTimeout(() => setCopiedCode(null), 2000);
    }
  };

  const filterTabs: { key: FilterTab; label: string }[] = [
    { key: 'all', label: '전체' },
    { key: 'available', label: '사용 가능' },
    { key: 'activated', label: '활성화됨' },
    { key: 'expired', label: '만료됨' },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <LoadingSpinner size="lg" label="쿠폰 로딩 중..." />
      </div>
    );
  }

  return (
    <div className="px-5 pt-4 pb-24">
      <h2 className="text-lg font-bold text-text-primary mb-4">쿠폰 관리</h2>

      {/* Stats Cards */}
      {stats && (
        <div className="grid grid-cols-3 gap-3 mb-6">
          <StatCard label="사용 가능" value={stats.available} color="text-brand-primary" />
          <StatCard label="활성화" value={stats.activated} color="text-status-success" />
          <StatCard label="만료됨" value={stats.expired} color="text-text-tertiary" />
        </div>
      )}

      {/* Generate PLG Free */}
      {stats && stats.plg_free_used < stats.plg_free_limit && (
        <div className="card p-4 mb-4 border-l-4 border-brand-primary">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-text-primary">무료 PLG 쿠폰</p>
              <p className="text-xs text-text-secondary mt-0.5">
                {stats.plg_free_used}/{stats.plg_free_limit}장 사용 · 회원 모집에 활용하세요
              </p>
            </div>
            <button
              type="button"
              onClick={handleGenerateFree}
              disabled={generating}
              className="btn-primary text-xs px-4 py-2 disabled:opacity-50"
            >
              {generating ? '생성 중...' : '무료 생성'}
            </button>
          </div>
        </div>
      )}

      {/* Purchase Bundles */}
      <div className="mb-6">
        <h3 className="text-sm font-semibold text-text-primary mb-3">쿠폰 번들 구매</h3>
        <div className="grid grid-cols-3 gap-2">
          {COUPON_BUNDLES.map((bundle, idx) => (
            <button
              key={bundle.quantity}
              type="button"
              onClick={() => handlePurchaseBundle(idx)}
              className={cn(
                'card p-3 text-center relative transition-all',
                bundle.popular && 'ring-2 ring-brand-primary'
              )}
            >
              {bundle.popular && (
                <span className="absolute -top-2 left-1/2 -translate-x-1/2 bg-brand-primary text-white text-[10px] px-2 py-0.5 rounded-full">
                  인기
                </span>
              )}
              <p className="text-lg font-bold text-text-primary">{bundle.quantity}장</p>
              <p className="text-xs text-text-secondary mt-1">
                {bundle.price.toLocaleString()}원
              </p>
              <p className="text-[10px] text-text-tertiary">
                장당 {bundle.perUnit.toLocaleString()}원
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 mb-4 overflow-x-auto">
        {filterTabs.map((tab) => (
          <button
            key={tab.key}
            type="button"
            onClick={() => setActiveTab(tab.key)}
            className={cn(
              'text-xs px-3 py-1.5 rounded-full whitespace-nowrap font-medium transition-colors',
              activeTab === tab.key
                ? 'bg-brand-primary text-white'
                : 'bg-gray-100 text-text-secondary'
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Coupon List */}
      {coupons.length === 0 ? (
        <EmptyState
          title="쿠폰이 없습니다"
          description="무료 PLG 쿠폰을 생성하거나 번들을 구매하세요."
        />
      ) : (
        <div className="space-y-2">
          {coupons.map((coupon) => (
            <CouponCard
              key={coupon.id}
              coupon={coupon}
              copied={copiedCode === coupon.code}
              onCopy={() => handleCopyCode(coupon.code)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="card p-3 text-center">
      <p className={cn('text-xl font-bold', color)}>{value}</p>
      <p className="text-[10px] text-text-tertiary mt-0.5">{label}</p>
    </div>
  );
}

function CouponCard({
  coupon,
  copied,
  onCopy,
}: {
  coupon: Coupon;
  copied: boolean;
  onCopy: () => void;
}) {
  const statusConfig: Record<string, { label: string; className: string }> = {
    available: { label: '사용 가능', className: 'bg-brand-primary/10 text-brand-primary' },
    activated: { label: '활성화', className: 'bg-status-success/10 text-status-success' },
    expired: { label: '만료', className: 'bg-gray-100 text-text-tertiary' },
    revoked: { label: '취소', className: 'bg-status-error/10 text-status-error' },
  };

  const config = statusConfig[coupon.status] ?? statusConfig.expired;

  return (
    <div className="card p-4 flex items-center justify-between">
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <code className="text-sm font-mono font-bold text-text-primary tracking-wider">
            {coupon.code}
          </code>
          <span className={cn('text-[10px] px-1.5 py-0.5 rounded-full font-medium', config.className)}>
            {config.label}
          </span>
        </div>
        <p className="text-[10px] text-text-tertiary">
          {coupon.source === 'plg_free' ? '무료' : '구매'} · {new Date(coupon.created_at).toLocaleDateString('ko-KR')}
          {coupon.expires_at && ` · ~${new Date(coupon.expires_at).toLocaleDateString('ko-KR')}`}
        </p>
      </div>

      {coupon.status === 'available' && (
        <button
          type="button"
          onClick={onCopy}
          className={cn(
            'text-xs px-3 py-1.5 rounded-lg font-medium transition-all ml-2',
            copied ? 'bg-status-success/10 text-status-success' : 'bg-gray-100 text-text-secondary hover:bg-gray-200'
          )}
        >
          {copied ? '복사됨' : '복사'}
        </button>
      )}
    </div>
  );
}
