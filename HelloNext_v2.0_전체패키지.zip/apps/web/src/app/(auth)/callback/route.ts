/**
 * Auth Callback Route Handler
 *
 * Handles the OAuth callback from Kakao and email confirmation links.
 * Exchanges the auth code for a session, then redirects to the appropriate page.
 *
 * Flow:
 * 1. Receive auth code from Supabase Auth redirect
 * 2. Exchange code for session
 * 3. Redirect to original destination or role-based home
 *
 * @route GET /callback
 * @feature F-007 가입/인증
 */

import { NextResponse, type NextRequest } from 'next/server';
import { createClient } from '@/lib/supabase/server';

export async function GET(request: NextRequest) {
  const { searchParams, origin } = new URL(request.url);

  const code = searchParams.get('code');
  const redirect = searchParams.get('redirect') ?? '/';
  const errorParam = searchParams.get('error');

  // Handle OAuth error
  if (errorParam) {
    const loginUrl = new URL('/login', origin);
    loginUrl.searchParams.set('error', errorParam);
    return NextResponse.redirect(loginUrl);
  }

  // Exchange the code for a session
  if (code) {
    const supabase = await createClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);

    if (error) {
      const loginUrl = new URL('/login', origin);
      loginUrl.searchParams.set('error', 'auth_exchange_failed');
      return NextResponse.redirect(loginUrl);
    }

    // Determine user role and redirect appropriately
    const { data: { user } } = await supabase.auth.getUser();

    if (user) {
      // Check if user has completed onboarding
      const { data: proProfile } = await supabase
        .from('pro_profiles')
        .select('id, studio_name')
        .eq('user_id', user.id)
        .single();

      if (proProfile) {
        // Pro user — check if onboarding is complete
        if (!proProfile.studio_name) {
          return NextResponse.redirect(new URL('/(pro)/onboarding', origin));
        }
        // If redirect is generic, go to dashboard
        const targetUrl = redirect === '/' ? '/(pro)/dashboard' : redirect;
        return NextResponse.redirect(new URL(targetUrl, origin));
      }

      const { data: memberProfile } = await supabase
        .from('member_profiles')
        .select('id')
        .eq('user_id', user.id)
        .single();

      if (memberProfile) {
        const targetUrl = redirect === '/' ? '/(member)/swingbook' : redirect;
        return NextResponse.redirect(new URL(targetUrl, origin));
      }
    }
  }

  // Fallback: redirect to the requested page or home
  return NextResponse.redirect(new URL(redirect, origin));
}
