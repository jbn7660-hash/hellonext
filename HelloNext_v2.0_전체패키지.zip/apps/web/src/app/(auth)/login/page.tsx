/**
 * Login Page
 *
 * Supports two authentication methods:
 * 1. Kakao Social Login (primary)
 * 2. Email + Password (fallback for development)
 *
 * Role selection: Users choose "프로" or "회원" before signing up.
 * Existing users are routed to their role-specific home after login.
 *
 * @page (auth)/login
 * @feature F-007 가입/인증
 */

'use client';

import { useState, useCallback } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { logger } from '@/lib/utils/logger';

type AuthMode = 'login' | 'signup';
type UserRole = 'pro' | 'member';

export default function LoginPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirectTo = searchParams.get('redirect') ?? '/';

  const [mode, setMode] = useState<AuthMode>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>('pro');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const supabase = createClient();

  const handleKakaoLogin = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const { error: authError } = await supabase.auth.signInWithOAuth({
        provider: 'kakao',
        options: {
          redirectTo: `${window.location.origin}/callback?redirect=${encodeURIComponent(redirectTo)}&role=${role}`,
        },
      });

      if (authError) {
        logger.error('Kakao OAuth failed', { error: authError.message });
        setError('카카오 로그인에 실패했습니다. 다시 시도해주세요.');
      }
    } catch (err) {
      logger.error('Kakao login unexpected error', { error: err });
      setError('알 수 없는 오류가 발생했습니다.');
    } finally {
      setLoading(false);
    }
  }, [supabase, redirectTo, role]);

  const handleEmailAuth = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      if (mode === 'signup') {
        const { error: signUpError } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              role,
              display_name: email.split('@')[0],
            },
            emailRedirectTo: `${window.location.origin}/callback?redirect=${encodeURIComponent(redirectTo)}`,
          },
        });

        if (signUpError) {
          logger.error('Email signup failed', { error: signUpError.message });
          setError(signUpError.message === 'User already registered'
            ? '이미 등록된 이메일입니다. 로그인을 시도해주세요.'
            : '회원가입에 실패했습니다.');
          return;
        }

        setError(null);
        alert('확인 이메일을 발송했습니다. 이메일을 확인해주세요.');
      } else {
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email,
          password,
        });

        if (signInError) {
          logger.error('Email login failed', { error: signInError.message });
          setError('이메일 또는 비밀번호가 올바르지 않습니다.');
          return;
        }

        logger.info('Email login success', { email });
        router.push(redirectTo);
        router.refresh();
      }
    } catch (err) {
      logger.error('Email auth unexpected error', { error: err });
      setError('알 수 없는 오류가 발생했습니다.');
    } finally {
      setLoading(false);
    }
  }, [supabase, email, password, mode, role, redirectTo, router]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-surface-secondary px-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-brand-600">HelloNext</h1>
          <p className="mt-2 text-sm text-text-secondary">
            AI 골프 코칭 플랫폼
          </p>
        </div>

        {/* Role Selection (signup only) */}
        {mode === 'signup' && (
          <div className="mb-6">
            <p className="mb-3 text-sm font-medium text-text-primary">
              가입 유형을 선택하세요
            </p>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setRole('pro')}
                className={`rounded-2xl border-2 px-4 py-3 text-sm font-medium transition-all ${
                  role === 'pro'
                    ? 'border-brand-500 bg-brand-50 text-brand-700'
                    : 'border-gray-200 text-text-secondary hover:border-gray-300'
                }`}
              >
                <span className="block text-lg">&#127948;</span>
                골프 프로
              </button>
              <button
                type="button"
                onClick={() => setRole('member')}
                className={`rounded-2xl border-2 px-4 py-3 text-sm font-medium transition-all ${
                  role === 'member'
                    ? 'border-brand-500 bg-brand-50 text-brand-700'
                    : 'border-gray-200 text-text-secondary hover:border-gray-300'
                }`}
              >
                <span className="block text-lg">&#9971;</span>
                골프 회원
              </button>
            </div>
          </div>
        )}

        {/* Kakao Login */}
        <button
          type="button"
          onClick={handleKakaoLogin}
          disabled={loading}
          className="mb-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#FEE500] px-6 py-3 text-sm font-semibold text-[#191919] transition-colors hover:bg-[#FADA0A] disabled:opacity-50"
        >
          <svg width="18" height="18" viewBox="0 0 18 18" aria-hidden="true">
            <path
              fill="#191919"
              d="M9 1C4.58 1 1 3.79 1 7.21c0 2.17 1.45 4.08 3.64 5.18-.16.55-.58 2-.66 2.31-.11.39.14.38.3.28.12-.08 1.93-1.31 2.71-1.84.65.09 1.32.14 2.01.14 4.42 0 8-2.79 8-6.21S13.42 1 9 1"
            />
          </svg>
          카카오로 {mode === 'login' ? '로그인' : '시작하기'}
        </button>

        {/* Divider */}
        <div className="relative mb-4">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-200" />
          </div>
          <div className="relative flex justify-center text-xs">
            <span className="bg-surface-secondary px-2 text-text-tertiary">또는</span>
          </div>
        </div>

        {/* Email Form */}
        <form onSubmit={handleEmailAuth} className="space-y-3">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="이메일"
            required
            autoComplete="email"
            className="input-field"
          />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="비밀번호"
            required
            minLength={6}
            autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
            className="input-field"
          />
          <button
            type="submit"
            disabled={loading}
            className="btn-primary w-full"
          >
            {loading ? '처리중...' : mode === 'login' ? '로그인' : '회원가입'}
          </button>
        </form>

        {/* Error */}
        {error && (
          <p className="mt-3 text-center text-sm text-status-error" role="alert">
            {error}
          </p>
        )}

        {/* Toggle mode */}
        <p className="mt-6 text-center text-sm text-text-secondary">
          {mode === 'login' ? (
            <>
              계정이 없으신가요?{' '}
              <button
                type="button"
                onClick={() => { setMode('signup'); setError(null); }}
                className="font-medium text-brand-600 hover:underline"
              >
                회원가입
              </button>
            </>
          ) : (
            <>
              이미 계정이 있으신가요?{' '}
              <button
                type="button"
                onClick={() => { setMode('login'); setError(null); }}
                className="font-medium text-brand-600 hover:underline"
              >
                로그인
              </button>
            </>
          )}
        </p>
      </div>
    </div>
  );
}
