/**
 * Voice Memo API — Single Memo Operations
 *
 * GET    /api/voice-memos/[id]  — Get memo details
 * PATCH  /api/voice-memos/[id]  — Update memo (assign member, edit)
 *
 * @route /api/voice-memos/[id]
 * @feature F-001, F-003
 */

import { NextResponse, type NextRequest } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { z } from 'zod';
import { logger } from '@/lib/utils/logger';

const UpdateMemoSchema = z.object({
  member_id: z.string().uuid().nullable().optional(),
  status: z.enum(['recording', 'transcribing', 'structuring', 'draft', 'published']).optional(),
});

type RouteParams = { params: Promise<{ id: string }> };

/** GET: Fetch single memo with related report */
export async function GET(_request: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params;
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { data, error } = await supabase
      .from('voice_memos')
      .select('*, reports(*)')
      .eq('id', id)
      .single();

    if (error || !data) {
      return NextResponse.json({ error: 'Memo not found' }, { status: 404 });
    }

    return NextResponse.json({ data });
  } catch (err) {
    logger.error('Memo GET error', { error: err });
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

/** PATCH: Update memo (e.g., assign member to orphan memo) */
export async function PATCH(request: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params;
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const parsed = UpdateMemoSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: 'Validation failed', details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const { data, error } = await supabase
      .from('voice_memos')
      .update(parsed.data)
      .eq('id', id)
      .select('*')
      .single();

    if (error) {
      logger.error('Memo update failed', { memoId: id, error: error.message });
      return NextResponse.json({ error: 'Failed to update memo' }, { status: 500 });
    }

    // If member was just assigned, re-trigger pipeline to create report
    if (parsed.data.member_id && data) {
      const { data: proProfile } = await supabase
        .from('pro_profiles')
        .select('id')
        .eq('user_id', user.id)
        .single();

      if (proProfile && data.structured_json) {
        logger.info('Member assigned to orphan memo, creating report', {
          memoId: id,
          memberId: parsed.data.member_id,
        });

        // Find link
        const { data: link } = await supabase
          .from('pro_member_links')
          .select('id')
          .eq('pro_id', proProfile.id)
          .eq('member_id', parsed.data.member_id)
          .eq('status', 'active')
          .single();

        if (link) {
          const structured = data.structured_json as {
            title: string;
            sections: unknown[];
            summary: string;
            error_tags: string[];
            homework: string | null;
          };

          await supabase.from('reports').insert({
            voice_memo_id: id,
            pro_id: proProfile.id,
            member_id: parsed.data.member_id,
            link_id: link.id,
            title: structured.title,
            content: {
              sections: structured.sections,
              summary: structured.summary,
              overallTone: 'constructive',
            },
            error_tags: structured.error_tags,
            homework: structured.homework,
            status: 'draft',
          });
        }
      }
    }

    return NextResponse.json({ data });
  } catch (err) {
    logger.error('Memo PATCH error', { error: err });
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
