/**
 * Voice Memos API — List & Create
 *
 * GET  /api/voice-memos  — List pro's voice memos (paginated)
 * POST /api/voice-memos  — Create new memo + trigger pipeline
 *
 * @route /api/voice-memos
 * @feature F-001, F-003
 */

import { NextResponse, type NextRequest } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { z } from 'zod';
import { logger } from '@/lib/utils/logger';

const CreateMemoSchema = z.object({
  audio_url: z.string().url(),
  duration_sec: z.number().int().min(1).max(120),
  member_id: z.string().uuid().nullable().optional(),
});

/** GET: List memos for current pro */
export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') ?? '0', 10);
    const limit = Math.min(parseInt(searchParams.get('limit') ?? '20', 10), 50);
    const orphanOnly = searchParams.get('orphan') === 'true';

    let query = supabase
      .from('voice_memos')
      .select('*, reports(id, status)', { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(page * limit, (page + 1) * limit - 1);

    if (orphanOnly) {
      query = query.is('member_id', null).neq('status', 'published');
    }

    const { data, error, count } = await query;

    if (error) {
      logger.error('Failed to fetch memos', { error: error.message });
      return NextResponse.json({ error: 'Failed to fetch memos' }, { status: 500 });
    }

    return NextResponse.json({
      data,
      pagination: { page, limit, total: count ?? 0 },
    });
  } catch (err) {
    logger.error('Voice memos GET unexpected error', { error: err });
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

/** POST: Create new memo and trigger voice-to-report pipeline */
export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get pro profile
    const { data: proProfile } = await supabase
      .from('pro_profiles')
      .select('id')
      .eq('user_id', user.id)
      .single();

    if (!proProfile) {
      return NextResponse.json({ error: 'Pro profile not found' }, { status: 403 });
    }

    // Validate body
    const body = await request.json();
    const parsed = CreateMemoSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: 'Validation failed', details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const { audio_url, duration_sec, member_id } = parsed.data;

    // Create memo record
    const { data: memo, error: insertError } = await supabase
      .from('voice_memos')
      .insert({
        pro_id: proProfile.id,
        member_id: member_id ?? null,
        audio_url,
        duration_sec,
        status: 'recording',
      })
      .select('*')
      .single();

    if (insertError || !memo) {
      logger.error('Failed to create memo', { error: insertError?.message });
      return NextResponse.json({ error: 'Failed to create memo' }, { status: 500 });
    }

    logger.info('Memo created, triggering pipeline', { memoId: memo.id });

    // Trigger voice-to-report Edge Function (async)
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

    if (supabaseUrl && serviceKey) {
      fetch(`${supabaseUrl}/functions/v1/voice-to-report`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${serviceKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          memo_id: memo.id,
          pro_id: proProfile.id,
        }),
      }).catch((err) => {
        logger.error('Failed to trigger pipeline', { error: err });
      });
    }

    return NextResponse.json({ data: memo }, { status: 201 });
  } catch (err) {
    logger.error('Voice memos POST unexpected error', { error: err });
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
