/**
 * Toss Payments Webhook
 *
 * POST /api/payments/webhook — Handle Toss payment status callbacks
 *
 * Handles:
 *  - Payment status changes (DONE, CANCELED, PARTIAL_CANCELED)
 *  - Billing (subscription) payment results
 *
 * @route /api/payments/webhook
 * @feature F-008
 */

import { NextResponse, type NextRequest } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { timingSafeEqual, createHmac } from 'crypto';
import { logger } from '@/lib/utils/logger';

// Use service role for webhook (no user auth context)
function getServiceClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );
}

interface TossWebhookPayload {
  eventType: 'PAYMENT_STATUS_CHANGED' | 'BILLING_STATUS_CHANGED';
  data: {
    paymentKey: string;
    orderId: string;
    status: string;
    transactionKey?: string;
    cancels?: Array<{
      cancelAmount: number;
      cancelReason: string;
      canceledAt: string;
    }>;
  };
}

export async function POST(request: NextRequest) {
  try {
    // Verify webhook signature (mandatory)
    const webhookSecret = process.env.TOSS_WEBHOOK_SECRET;
    if (!webhookSecret) {
      logger.error('TOSS_WEBHOOK_SECRET is not configured');
      return NextResponse.json({ error: 'Server misconfiguration' }, { status: 500 });
    }

    const rawBody = await request.text();
    const signature = request.headers.get('toss-signature') ?? '';

    // HMAC-SHA256 timing-safe comparison to prevent timing attacks
    const expectedSig = createHmac('sha256', webhookSecret).update(rawBody).digest('hex');
    const sigBuffer = Buffer.from(signature, 'hex');
    const expectedBuffer = Buffer.from(expectedSig, 'hex');

    if (sigBuffer.length !== expectedBuffer.length || !timingSafeEqual(sigBuffer, expectedBuffer)) {
      logger.warn('Toss webhook signature mismatch', { signature: signature.slice(0, 8) + '...' });
      return NextResponse.json({ error: 'Invalid signature' }, { status: 401 });
    }

    const payload: TossWebhookPayload = JSON.parse(rawBody);
    const supabase = getServiceClient();

    logger.info('Toss webhook received', {
      eventType: payload.eventType,
      paymentKey: payload.data.paymentKey,
      status: payload.data.status,
    });

    // Update payment record
    const { data: payment, error: updateError } = await supabase
      .from('payments')
      .update({
        status: payload.data.status,
        webhook_data: payload.data,
        updated_at: new Date().toISOString(),
      })
      .eq('payment_key', payload.data.paymentKey)
      .select('id, pro_id, type, amount, status')
      .single();

    if (updateError) {
      logger.error('Webhook payment update failed', { error: updateError.message });
      // Return 200 to prevent Toss from retrying — log for manual reconciliation
      return NextResponse.json({ received: true, processed: false });
    }

    // Handle cancellation: revoke associated coupons if applicable
    if (
      payload.data.status === 'CANCELED' &&
      payment.type === 'coupon_bundle'
    ) {
      const { error: revokeError } = await supabase
        .from('coupons')
        .update({ status: 'revoked' })
        .eq('bundle_order_id', payment.id)
        .eq('status', 'available'); // Only revoke unused ones

      if (revokeError) {
        logger.error('Coupon revocation failed', { paymentId: payment.id, error: revokeError.message });
      }
    }

    // Handle subscription billing result
    if (
      payload.eventType === 'BILLING_STATUS_CHANGED' &&
      payment.type === 'subscription'
    ) {
      if (payload.data.status === 'DONE') {
        // Extend subscription period
        await supabase
          .from('subscriptions')
          .update({
            status: 'active',
            current_period_end: getNextBillingDate().toISOString(),
            last_payment_id: payment.id,
          })
          .eq('pro_id', payment.pro_id)
          .eq('status', 'active');
      } else if (['ABORTED', 'EXPIRED'].includes(payload.data.status)) {
        // Mark subscription as past_due
        await supabase
          .from('subscriptions')
          .update({ status: 'past_due' })
          .eq('pro_id', payment.pro_id)
          .eq('status', 'active');

        // Notify pro
        const { data: proProfile } = await supabase
          .from('pro_profiles')
          .select('user_id')
          .eq('id', payment.pro_id)
          .single();

        if (proProfile) {
          await supabase.functions.invoke('send-notification', {
            body: {
              user_id: proProfile.user_id,
              type: 'payment_failed',
              title: '결제 실패',
              body: '구독 결제에 실패했습니다. 결제 수단을 확인해주세요.',
              data: { payment_id: payment.id },
            },
          });
        }
      }
    }

    return NextResponse.json({ received: true, processed: true });
  } catch (err) {
    logger.error('Webhook error', { error: err });
    // Always return 200 for webhooks to prevent infinite retries
    return NextResponse.json({ received: true, processed: false });
  }
}

function getNextBillingDate(): Date {
  const next = new Date();
  next.setMonth(next.getMonth() + 1);
  return next;
}
