/**
 * Payments API
 *
 * POST /api/payments — Confirm a one-time payment (coupon bundle purchase)
 * GET  /api/payments — List payment history
 *
 * @route /api/payments
 * @feature F-008
 */

import { NextResponse, type NextRequest } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { confirmPayment, TossPaymentError } from '@/lib/payments/toss';
import { z } from 'zod';
import { logger } from '@/lib/utils/logger';

const ConfirmPaymentSchema = z.object({
  paymentKey: z.string().min(1),
  orderId: z.string().min(1),
  amount: z.number().positive(),
  type: z.enum(['coupon_bundle', 'subscription']),
  metadata: z.object({
    bundle_quantity: z.number().optional(),
    plan_id: z.string().optional(),
  }).optional(),
});

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const parsed = ConfirmPaymentSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: 'Validation failed', details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const { paymentKey, orderId, amount, type, metadata } = parsed.data;

    // 1. Confirm payment with Toss
    let tossResult;
    try {
      tossResult = await confirmPayment({ paymentKey, orderId, amount });
    } catch (err) {
      if (err instanceof TossPaymentError) {
        logger.error('Toss payment confirmation failed', { code: err.code, message: err.message });
        return NextResponse.json(
          { error: err.message, code: err.code },
          { status: 400 }
        );
      }
      throw err;
    }

    // 2. Record payment in DB
    const { data: proProfile } = await supabase
      .from('pro_profiles')
      .select('id')
      .eq('user_id', user.id)
      .single();

    if (!proProfile) {
      return NextResponse.json({ error: 'Pro profile not found' }, { status: 403 });
    }

    const { data: payment, error: insertError } = await supabase
      .from('payments')
      .insert({
        pro_id: proProfile.id,
        payment_key: tossResult.paymentKey,
        order_id: tossResult.orderId,
        amount: tossResult.totalAmount,
        status: tossResult.status,
        method: tossResult.method,
        type,
        metadata: metadata ?? {},
        approved_at: tossResult.approvedAt,
        receipt_url: tossResult.receipt?.url ?? null,
      })
      .select()
      .single();

    if (insertError) {
      logger.error('Payment record insert failed', { error: insertError.message });
      // Payment was confirmed with Toss but DB insert failed — log for reconciliation
      return NextResponse.json({ error: 'Payment confirmed but record failed. Contact support.' }, { status: 500 });
    }

    // 3. If coupon bundle purchase → generate coupons
    if (type === 'coupon_bundle' && metadata?.bundle_quantity) {
      const { error: couponError } = await supabase.functions.invoke('coupon-activate', {
        body: {
          action: 'generate',
          quantity: metadata.bundle_quantity,
          source: 'purchased_bundle',
          bundle_order_id: payment.id,
        },
      });

      if (couponError) {
        logger.error('Post-payment coupon generation failed', { paymentId: payment.id, error: couponError });
        // Don't fail the response — coupons can be generated manually
      }
    }

    logger.info('Payment confirmed', {
      paymentId: payment.id,
      amount: tossResult.totalAmount,
      type,
    });

    return NextResponse.json({ data: payment }, { status: 201 });
  } catch (err) {
    logger.error('Payments POST error', { error: err });
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { data: proProfile } = await supabase
      .from('pro_profiles')
      .select('id')
      .eq('user_id', user.id)
      .single();

    if (!proProfile) {
      return NextResponse.json({ error: 'Pro profile not found' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') ?? '1', 10);
    const limit = parseInt(searchParams.get('limit') ?? '20', 10);
    const offset = (page - 1) * limit;

    const { data, count, error } = await supabase
      .from('payments')
      .select('*', { count: 'exact' })
      .eq('pro_id', proProfile.id)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) {
      logger.error('Payments fetch failed', { error: error.message });
      return NextResponse.json({ error: 'Failed to fetch payments' }, { status: 500 });
    }

    return NextResponse.json({
      data,
      pagination: { page, limit, total: count ?? 0 },
    });
  } catch (err) {
    logger.error('Payments GET error', { error: err });
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
