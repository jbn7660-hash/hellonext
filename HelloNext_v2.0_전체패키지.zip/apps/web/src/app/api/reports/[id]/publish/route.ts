/**
 * Report Publish API
 *
 * POST /api/reports/[id]/publish — Publish draft report to member
 *
 * Flow:
 * 1. Update report status to 'published'
 * 2. Trigger notification to member (Kakao + in-app)
 *
 * @route /api/reports/[id]/publish
 * @feature F-001
 */

import { NextResponse, type NextRequest } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { logger } from '@/lib/utils/logger';

type RouteParams = { params: Promise<{ id: string }> };

export async function POST(_request: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params;
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Fetch report (RLS ensures only pro's own reports)
    const { data: report, error: fetchError } = await supabase
      .from('reports')
      .select('*, member_profiles!inner(user_id, display_name)')
      .eq('id', id)
      .eq('status', 'draft')
      .single();

    if (fetchError || !report) {
      return NextResponse.json(
        { error: 'Draft report not found' },
        { status: 404 }
      );
    }

    // Publish
    const { error: updateError } = await supabase
      .from('reports')
      .update({
        status: 'published',
        published_at: new Date().toISOString(),
      })
      .eq('id', id);

    if (updateError) {
      logger.error('Failed to publish report', { reportId: id, error: updateError.message });
      return NextResponse.json({ error: 'Failed to publish' }, { status: 500 });
    }

    // Trigger notification via Edge Function
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    const memberProfile = report.member_profiles as { user_id: string; display_name: string };

    if (supabaseUrl && serviceKey) {
      fetch(`${supabaseUrl}/functions/v1/send-notification`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${serviceKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          user_id: memberProfile.user_id,
          type: 'report',
          title: '새 리포트가 도착했습니다',
          body: `${report.title}`,
          data: { report_id: id },
          channels: ['kakao', 'push', 'in_app'],
        }),
      }).catch((err) => {
        logger.error('Failed to trigger notification', { error: err });
      });
    }

    logger.info('Report published', { reportId: id, memberId: report.member_id });

    return NextResponse.json({ success: true, report_id: id });
  } catch (err) {
    logger.error('Report publish error', { error: err });
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
