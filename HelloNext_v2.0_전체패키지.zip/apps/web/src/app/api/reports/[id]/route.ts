/**
 * Report API — Single Report Operations
 *
 * GET   /api/reports/[id]  — Get report details
 * PATCH /api/reports/[id]  — Update report (edit content, mark as read)
 *
 * @route /api/reports/[id]
 * @feature F-001
 */

import { NextResponse, type NextRequest } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { z } from 'zod';
import { logger } from '@/lib/utils/logger';

const UpdateReportSchema = z.object({
  title: z.string().min(1).optional(),
  content: z.record(z.unknown()).optional(),
  homework: z.string().nullable().optional(),
  error_tags: z.array(z.string()).optional(),
  status: z.enum(['draft', 'published', 'read']).optional(),
});

type RouteParams = { params: Promise<{ id: string }> };

export async function GET(_request: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params;
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { data, error } = await supabase
      .from('reports')
      .select(`
        *,
        voice_memos(id, transcript, duration_sec),
        pro_profiles!inner(display_name, studio_name),
        member_profiles!inner(display_name)
      `)
      .eq('id', id)
      .single();

    if (error || !data) {
      return NextResponse.json({ error: 'Report not found' }, { status: 404 });
    }

    // If member is reading, mark as read
    const { data: memberProfile } = await supabase
      .from('member_profiles')
      .select('id')
      .eq('user_id', user.id)
      .single();

    if (memberProfile && data.member_id === memberProfile.id && data.status === 'published') {
      await supabase
        .from('reports')
        .update({ status: 'read', read_at: new Date().toISOString() })
        .eq('id', id);
    }

    return NextResponse.json({ data });
  } catch (err) {
    logger.error('Report GET error', { error: err });
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PATCH(request: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params;
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const parsed = UpdateReportSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: 'Validation failed', details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const { data, error } = await supabase
      .from('reports')
      .update(parsed.data)
      .eq('id', id)
      .select('*')
      .single();

    if (error) {
      logger.error('Report update failed', { reportId: id, error: error.message });
      return NextResponse.json({ error: 'Failed to update report' }, { status: 500 });
    }

    return NextResponse.json({ data });
  } catch (err) {
    logger.error('Report PATCH error', { error: err });
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
