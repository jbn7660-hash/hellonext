/**
 * Coupons API
 *
 * GET  /api/coupons — List pro's coupons (for pro) or member's activated coupons (for member)
 * POST /api/coupons — Generate new coupon codes (pro only)
 *
 * @route /api/coupons
 * @feature F-012
 */

import { NextResponse, type NextRequest } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { z } from 'zod';
import { logger } from '@/lib/utils/logger';

const GenerateSchema = z.object({
  quantity: z.number().int().min(1).max(30),
  source: z.enum(['plg_free', 'purchased_bundle']),
  bundle_order_id: z.string().uuid().optional(),
});

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status'); // available, activated, expired
    const page = parseInt(searchParams.get('page') ?? '1', 10);
    const limit = parseInt(searchParams.get('limit') ?? '20', 10);

    // Check if user is a pro
    const { data: proProfile } = await supabase
      .from('pro_profiles')
      .select('id')
      .eq('user_id', user.id)
      .single();

    let query;

    if (proProfile) {
      // Pro: see all their coupons
      query = supabase
        .from('coupons')
        .select('id, code, source, status, activated_at, expires_at, member_user_id, created_at', { count: 'exact' })
        .eq('pro_id', proProfile.id)
        .order('created_at', { ascending: false });
    } else {
      // Member: see their activated coupons
      query = supabase
        .from('coupons')
        .select('id, code, source, status, activated_at, expires_at, pro_id, created_at, pro_profiles!inner(display_name)', { count: 'exact' })
        .eq('member_user_id', user.id)
        .order('activated_at', { ascending: false });
    }

    if (status) {
      query = query.eq('status', status);
    }

    const offset = (page - 1) * limit;
    query = query.range(offset, offset + limit - 1);

    const { data, count, error } = await query;

    if (error) {
      logger.error('Coupons fetch failed', { error: error.message });
      return NextResponse.json({ error: 'Failed to fetch coupons' }, { status: 500 });
    }

    // Summary stats for pro
    let stats = null;
    if (proProfile) {
      const { data: allCoupons } = await supabase
        .from('coupons')
        .select('status, source')
        .eq('pro_id', proProfile.id);

      if (allCoupons) {
        stats = {
          total: allCoupons.length,
          available: allCoupons.filter((c) => c.status === 'available').length,
          activated: allCoupons.filter((c) => c.status === 'activated').length,
          expired: allCoupons.filter((c) => c.status === 'expired').length,
          plg_free_used: allCoupons.filter((c) => c.source === 'plg_free').length,
          plg_free_limit: 3,
        };
      }
    }

    return NextResponse.json({
      data,
      stats,
      pagination: { page, limit, total: count ?? 0 },
    });
  } catch (err) {
    logger.error('Coupons GET error', { error: err });
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const parsed = GenerateSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: 'Validation failed', details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    // Invoke Edge Function for generation
    const { data, error } = await supabase.functions.invoke('coupon-activate', {
      body: { action: 'generate', ...parsed.data },
    });

    if (error) {
      logger.error('Coupon generate invoke failed', { error });
      return NextResponse.json({ error: 'Failed to generate coupons' }, { status: 500 });
    }

    logger.info('Coupons generated', {
      userId: user.id,
      quantity: parsed.data.quantity,
      source: parsed.data.source,
    });

    return NextResponse.json(data, { status: 201 });
  } catch (err) {
    logger.error('Coupons POST error', { error: err });
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
