/**
 * Subscriptions API
 *
 * GET  /api/subscriptions — Get current subscription status
 * POST /api/subscriptions — Create or update subscription (billing key registration)
 * DELETE /api/subscriptions — Cancel subscription
 *
 * @route /api/subscriptions
 * @feature F-008
 */

import { NextResponse, type NextRequest } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { issueBillingKey, cancelPayment, TossPaymentError } from '@/lib/payments/toss';
import { z } from 'zod';
import { logger } from '@/lib/utils/logger';

const SubscribeSchema = z.object({
  authKey: z.string().min(1),
  customerKey: z.string().min(1),
  plan_id: z.enum(['pro', 'academy']),
});

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { data: proProfile } = await supabase
      .from('pro_profiles')
      .select('id')
      .eq('user_id', user.id)
      .single();

    if (!proProfile) {
      return NextResponse.json({ error: 'Pro profile not found' }, { status: 403 });
    }

    const { data: subscription } = await supabase
      .from('subscriptions')
      .select('*')
      .eq('pro_id', proProfile.id)
      .in('status', ['active', 'past_due', 'trialing'])
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    return NextResponse.json({
      data: subscription ?? { plan_id: 'starter', status: 'free' },
    });
  } catch (err) {
    logger.error('Subscriptions GET error', { error: err });
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const parsed = SubscribeSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: 'Validation failed', details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const { data: proProfile } = await supabase
      .from('pro_profiles')
      .select('id')
      .eq('user_id', user.id)
      .single();

    if (!proProfile) {
      return NextResponse.json({ error: 'Pro profile not found' }, { status: 403 });
    }

    // Issue billing key with Toss
    let billingResult;
    try {
      billingResult = await issueBillingKey(parsed.data.authKey, parsed.data.customerKey);
    } catch (err) {
      if (err instanceof TossPaymentError) {
        return NextResponse.json(
          { error: err.message, code: err.code },
          { status: 400 }
        );
      }
      throw err;
    }

    // Upsert subscription
    const periodEnd = new Date();
    periodEnd.setMonth(periodEnd.getMonth() + 1);

    const { data: subscription, error: upsertError } = await supabase
      .from('subscriptions')
      .upsert(
        {
          pro_id: proProfile.id,
          plan_id: parsed.data.plan_id,
          status: 'active',
          billing_key: billingResult.billingKey,
          customer_key: billingResult.customerKey,
          card_info: billingResult.card ?? null,
          current_period_start: new Date().toISOString(),
          current_period_end: periodEnd.toISOString(),
        },
        { onConflict: 'pro_id' }
      )
      .select()
      .single();

    if (upsertError) {
      logger.error('Subscription upsert failed', { error: upsertError.message });
      return NextResponse.json({ error: 'Failed to save subscription' }, { status: 500 });
    }

    // Update pro profile plan
    await supabase
      .from('pro_profiles')
      .update({ plan: parsed.data.plan_id })
      .eq('id', proProfile.id);

    logger.info('Subscription created', {
      proId: proProfile.id,
      planId: parsed.data.plan_id,
    });

    return NextResponse.json({ data: subscription }, { status: 201 });
  } catch (err) {
    logger.error('Subscriptions POST error', { error: err });
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { data: proProfile } = await supabase
      .from('pro_profiles')
      .select('id')
      .eq('user_id', user.id)
      .single();

    if (!proProfile) {
      return NextResponse.json({ error: 'Pro profile not found' }, { status: 403 });
    }

    const { data: subscription } = await supabase
      .from('subscriptions')
      .select('*')
      .eq('pro_id', proProfile.id)
      .eq('status', 'active')
      .single();

    if (!subscription) {
      return NextResponse.json({ error: 'No active subscription' }, { status: 404 });
    }

    // Cancel at period end (don't immediately revoke access)
    const { error: cancelError } = await supabase
      .from('subscriptions')
      .update({
        status: 'canceled',
        cancel_at_period_end: true,
        canceled_at: new Date().toISOString(),
      })
      .eq('id', subscription.id);

    if (cancelError) {
      logger.error('Subscription cancel failed', { error: cancelError.message });
      return NextResponse.json({ error: 'Failed to cancel' }, { status: 500 });
    }

    // Downgrade plan at period end (keep active until then)
    logger.info('Subscription canceled', {
      proId: proProfile.id,
      effectiveEnd: subscription.current_period_end,
    });

    return NextResponse.json({
      data: {
        status: 'canceled',
        effective_end: subscription.current_period_end,
        message: `구독이 해지되었습니다. ${new Date(subscription.current_period_end).toLocaleDateString('ko-KR')}까지 이용 가능합니다.`,
      },
    });
  } catch (err) {
    logger.error('Subscriptions DELETE error', { error: err });
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
