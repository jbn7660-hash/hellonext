/**
 * Member Coupon Redeem Page (F-012)
 *
 * Simple form for members to enter a coupon code
 * and link to a pro coach.
 *
 * @page /redeem
 * @feature F-012
 */

'use client';

import { useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { cn } from '@/lib/utils/cn';
import { logger } from '@/lib/utils/logger';

type RedeemState = 'idle' | 'loading' | 'success' | 'error';

interface RedeemResult {
  pro_name: string;
  expires_at: string;
  message: string;
}

export default function RedeemPage() {
  const router = useRouter();
  const [code, setCode] = useState('');
  const [state, setState] = useState<RedeemState>('idle');
  const [result, setResult] = useState<RedeemResult | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  // Format input: auto-uppercase and insert dash
  const handleCodeChange = (value: string) => {
    const clean = value.toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (clean.length <= 8) {
      const formatted = clean.length > 4 ? `${clean.slice(0, 4)}-${clean.slice(4)}` : clean;
      setCode(formatted);
    }
  };

  const handleRedeem = useCallback(async () => {
    const cleanCode = code.replace(/-/g, '').trim();
    if (cleanCode.length < 6) {
      setErrorMsg('쿠폰 코드를 정확히 입력해주세요.');
      setState('error');
      return;
    }

    setState('loading');
    setErrorMsg('');

    try {
      const res = await fetch(`/api/coupons/${code}/redeem`, {
        method: 'POST',
      });

      const data = await res.json();

      if (!res.ok) {
        setErrorMsg(data.error ?? '쿠폰 활성화에 실패했습니다.');
        setState('error');
        return;
      }

      setResult({
        pro_name: data.pro_name,
        expires_at: data.expires_at,
        message: data.message,
      });
      setState('success');
    } catch (err) {
      setErrorMsg('네트워크 오류가 발생했습니다.');
      setState('error');
      logger.error('Coupon redeem error', { error: err });
    }
  }, [code]);

  // Success state
  if (state === 'success' && result) {
    return (
      <div className="px-5 pt-12 flex flex-col items-center text-center">
        <div className="w-20 h-20 rounded-full bg-status-success/10 flex items-center justify-center mb-6">
          <svg className="w-10 h-10 text-status-success" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
            <polyline points="20,6 9,17 4,12" />
          </svg>
        </div>

        <h2 className="text-xl font-bold text-text-primary mb-2">쿠폰 활성화 완료!</h2>
        <p className="text-sm text-text-secondary mb-1">{result.message}</p>
        <p className="text-xs text-text-tertiary mb-8">
          유효기간: ~{new Date(result.expires_at).toLocaleDateString('ko-KR')}
        </p>

        <div className="flex gap-3 w-full max-w-xs">
          <button
            type="button"
            onClick={() => router.push('/practice')}
            className="flex-1 btn-primary py-3 text-sm"
          >
            연습 시작하기
          </button>
          <button
            type="button"
            onClick={() => {
              setCode('');
              setState('idle');
              setResult(null);
            }}
            className="flex-1 card py-3 text-center text-sm font-medium text-text-secondary"
          >
            다른 쿠폰 입력
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="px-5 pt-8">
      <h2 className="text-lg font-bold text-text-primary mb-2">쿠폰 입력</h2>
      <p className="text-sm text-text-secondary mb-8">
        프로님에게 받은 쿠폰 코드를 입력하세요
      </p>

      {/* Code Input */}
      <div className="mb-4">
        <input
          type="text"
          value={code}
          onChange={(e) => handleCodeChange(e.target.value)}
          placeholder="XXXX-XXXX"
          maxLength={9}
          className={cn(
            'w-full text-center text-2xl font-mono font-bold tracking-[0.3em] py-4 px-6',
            'border-2 rounded-2xl outline-none transition-colors',
            'placeholder:text-text-tertiary/30 placeholder:tracking-[0.3em]',
            state === 'error'
              ? 'border-status-error bg-status-error/5'
              : 'border-gray-200 focus:border-brand-primary bg-surface-primary'
          )}
          autoFocus
          autoComplete="off"
          onKeyDown={(e) => e.key === 'Enter' && handleRedeem()}
        />
      </div>

      {/* Error message */}
      {state === 'error' && errorMsg && (
        <div className="mb-4 p-3 bg-status-error/10 rounded-xl animate-fade-in">
          <p className="text-sm text-status-error text-center">{errorMsg}</p>
        </div>
      )}

      {/* Submit */}
      <button
        type="button"
        onClick={handleRedeem}
        disabled={state === 'loading' || code.replace(/-/g, '').length < 6}
        className="w-full btn-primary py-3.5 text-base font-semibold disabled:opacity-40 transition-opacity"
      >
        {state === 'loading' ? '확인 중...' : '쿠폰 활성화'}
      </button>

      {/* Help text */}
      <p className="text-xs text-text-tertiary text-center mt-4">
        쿠폰은 활성화 후 90일간 유효합니다
      </p>
    </div>
  );
}
