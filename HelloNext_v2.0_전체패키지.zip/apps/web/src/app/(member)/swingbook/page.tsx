/**
 * Member SwingBook Page (F-004)
 *
 * Timeline view of all swing videos with linked reports.
 * Supports gallery import (F-009) and side-by-side comparison (AC-3).
 *
 * @page /swingbook
 * @feature F-004, F-009
 */

'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { VideoDropzone } from '@/components/swing/video-dropzone';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { EmptyState } from '@/components/ui/empty-state';
import { formatDate, formatDuration } from '@/lib/utils/format';
import { cn } from '@/lib/utils/cn';
import { logger } from '@/lib/utils/logger';

interface SwingEntry {
  id: string;
  thumbnail_url: string;
  cloudinary_url: string;
  duration_sec: number;
  status: string;
  source: string;
  created_at: string;
  has_report: boolean;
  error_tags?: string[];
}

export default function SwingBookPage() {
  const router = useRouter();
  const [entries, setEntries] = useState<SwingEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [compareMode, setCompareMode] = useState(false);
  const [compareSelection, setCompareSelection] = useState<string[]>([]);

  const fetchEntries = useCallback(async () => {
    try {
      const res = await fetch('/api/swing-videos?limit=50');
      if (res.ok) {
        const { data } = await res.json();
        setEntries(data ?? []);
      }
    } catch (err) {
      logger.error('SwingBook fetch error', { error: err });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchEntries();
  }, [fetchEntries]);

  const handleCompareToggle = useCallback((id: string) => {
    setCompareSelection((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      if (prev.length >= 2) return [prev[1]!, id]; // Keep last 2
      return [...prev, id];
    });
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <LoadingSpinner size="lg" label="스윙북 로딩 중..." />
      </div>
    );
  }

  return (
    <div className="px-5 pt-4">
      {/* Dropzone — Gallery Import (F-009 AC-4) */}
      <VideoDropzone
        mode="member"
        onUploadComplete={() => fetchEntries()}
        className="mb-4"
      />

      {/* Header + Compare Toggle */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-bold text-text-primary">내 스윙북</h2>
        {entries.length >= 2 && (
          <button
            type="button"
            onClick={() => {
              setCompareMode(!compareMode);
              setCompareSelection([]);
            }}
            className={cn(
              'text-xs px-3 py-1 rounded-full font-medium transition-colors',
              compareMode
                ? 'bg-brand-primary text-white'
                : 'bg-gray-100 text-text-secondary'
            )}
          >
            {compareMode ? '비교 취소' : '비교하기'}
          </button>
        )}
      </div>

      {/* Compare Action Bar */}
      {compareMode && compareSelection.length === 2 && (
        <div className="mb-4 p-3 bg-brand-primary/10 rounded-xl flex items-center justify-between animate-fade-in">
          <span className="text-sm text-brand-primary font-medium">2개 영상 선택됨</span>
          <button
            type="button"
            onClick={() => {
              router.push(`/swingbook/compare?a=${compareSelection[0]}&b=${compareSelection[1]}`);
            }}
            className="btn-primary text-xs px-4 py-1.5"
          >
            나란히 비교
          </button>
        </div>
      )}

      {/* Timeline */}
      {entries.length === 0 ? (
        <EmptyState
          title="첫 스윙을 촬영하세요"
          description="연습 탭에서 스윙을 촬영하거나 갤러리에서 영상을 가져오세요."
          action={
            <button
              type="button"
              onClick={() => router.push('/practice')}
              className="btn-primary text-sm px-4 py-2"
            >
              연습 시작
            </button>
          }
        />
      ) : (
        <div className="grid grid-cols-2 gap-3">
          {entries.map((entry) => (
            <SwingCard
              key={entry.id}
              entry={entry}
              compareMode={compareMode}
              isSelected={compareSelection.includes(entry.id)}
              onSelect={() => compareMode ? handleCompareToggle(entry.id) : router.push(`/swingbook/${entry.id}`)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function SwingCard({
  entry,
  compareMode,
  isSelected,
  onSelect,
}: {
  entry: SwingEntry;
  compareMode: boolean;
  isSelected: boolean;
  onSelect: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onSelect}
      className={cn(
        'relative rounded-xl overflow-hidden border-2 transition-all text-left',
        isSelected ? 'border-brand-primary ring-2 ring-brand-primary/20' : 'border-transparent',
        compareMode && 'cursor-pointer'
      )}
    >
      {/* Thumbnail */}
      <div className="aspect-[3/4] bg-gray-100 relative">
        <img
          src={entry.thumbnail_url}
          alt="스윙 영상"
          className="w-full h-full object-cover"
          loading="lazy"
        />

        {/* Duration badge */}
        <div className="absolute bottom-2 right-2 bg-black/60 text-white text-[10px] px-1.5 py-0.5 rounded">
          {formatDuration(entry.duration_sec)}
        </div>

        {/* Status badge */}
        {entry.status === 'analyzed' && (
          <div className="absolute top-2 left-2 bg-brand-primary text-white text-[10px] px-1.5 py-0.5 rounded">
            AI 분석 완료
          </div>
        )}

        {/* Report linked indicator */}
        {entry.has_report && (
          <div className="absolute top-2 right-2 bg-status-success text-white text-[10px] px-1.5 py-0.5 rounded">
            📋
          </div>
        )}

        {/* Compare checkbox overlay */}
        {compareMode && (
          <div className="absolute inset-0 bg-black/10 flex items-center justify-center">
            <div className={cn(
              'w-6 h-6 rounded-full border-2 flex items-center justify-center',
              isSelected ? 'bg-brand-primary border-brand-primary' : 'border-white bg-black/20'
            )}>
              {isSelected && (
                <svg className="w-4 h-4 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={3}>
                  <polyline points="20,6 9,17 4,12" />
                </svg>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Date */}
      <div className="p-2">
        <p className="text-xs text-text-tertiary">{formatDate(entry.created_at)}</p>
      </div>
    </button>
  );
}
