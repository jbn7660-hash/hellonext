/**
 * Member Progress Tab (F-010)
 *
 * Visualizes member's swing improvement journey:
 *  - Feel accuracy trend (feel vs AI observation match)
 *  - Error pattern frequency heatmap
 *  - Practice streak & volume stats
 *  - AI observation trend per position
 *  - Linked report history
 *
 * @page /progress
 * @feature F-010
 */

'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { EmptyState } from '@/components/ui/empty-state';
import { cn } from '@/lib/utils/cn';
import { logger } from '@/lib/utils/logger';

interface ProgressStats {
  total_swings: number;
  total_practice_days: number;
  current_streak: number;
  feel_accuracy_rate: number; // 0-100
  most_common_errors: Array<{ code: string; name: string; count: number }>;
  weekly_swings: Array<{ week: string; count: number }>;
  position_trends: Array<{
    position: string;
    recent_score: number; // 0-100
    previous_score: number;
    trend: 'improving' | 'stable' | 'declining';
  }>;
  recent_reports: Array<{
    id: string;
    title: string;
    date: string;
    pro_name: string;
  }>;
}

type TimeRange = '1w' | '1m' | '3m' | 'all';

export default function ProgressPage() {
  const router = useRouter();
  const [stats, setStats] = useState<ProgressStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState<TimeRange>('1m');

  const fetchProgress = useCallback(async () => {
    try {
      const res = await fetch(`/api/progress?range=${timeRange}`);
      if (res.ok) {
        const { data } = await res.json();
        setStats(data);
      }
    } catch (err) {
      logger.error('Progress fetch error', { error: err });
    } finally {
      setLoading(false);
    }
  }, [timeRange]);

  useEffect(() => {
    setLoading(true);
    fetchProgress();
  }, [fetchProgress]);

  const timeRanges: { key: TimeRange; label: string }[] = [
    { key: '1w', label: '1주' },
    { key: '1m', label: '1개월' },
    { key: '3m', label: '3개월' },
    { key: 'all', label: '전체' },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <LoadingSpinner size="lg" label="진척도 분석 중..." />
      </div>
    );
  }

  if (!stats || stats.total_swings === 0) {
    return (
      <div className="px-5 pt-4">
        <h2 className="text-lg font-bold text-text-primary mb-4">내 진척도</h2>
        <EmptyState
          title="아직 데이터가 없어요"
          description="연습 탭에서 첫 스윙을 촬영하면 진척도를 확인할 수 있습니다."
          action={
            <button
              type="button"
              onClick={() => router.push('/practice')}
              className="btn-primary text-sm px-4 py-2"
            >
              연습 시작
            </button>
          }
        />
      </div>
    );
  }

  return (
    <div className="px-5 pt-4 pb-24">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-bold text-text-primary">내 진척도</h2>

        {/* Time Range Filter */}
        <div className="flex gap-1">
          {timeRanges.map((tr) => (
            <button
              key={tr.key}
              type="button"
              onClick={() => setTimeRange(tr.key)}
              className={cn(
                'text-[10px] px-2 py-1 rounded-full font-medium transition-colors',
                timeRange === tr.key
                  ? 'bg-brand-primary text-white'
                  : 'bg-gray-100 text-text-tertiary'
              )}
            >
              {tr.label}
            </button>
          ))}
        </div>
      </div>

      {/* Key Stats */}
      <div className="grid grid-cols-4 gap-2 mb-6">
        <MiniStat label="총 스윙" value={stats.total_swings} />
        <MiniStat label="연습일" value={stats.total_practice_days} />
        <MiniStat label="연속일" value={stats.current_streak} suffix="일" />
        <MiniStat
          label="Feel 정확도"
          value={stats.feel_accuracy_rate}
          suffix="%"
          color={stats.feel_accuracy_rate >= 60 ? 'text-status-success' : 'text-status-warning'}
        />
      </div>

      {/* Feel Accuracy Card */}
      <div className="card p-4 mb-4">
        <h3 className="text-sm font-semibold text-text-primary mb-2">Feel vs Real 정확도</h3>
        <div className="flex items-center gap-3">
          <div className="relative w-16 h-16">
            <svg className="w-16 h-16 -rotate-90" viewBox="0 0 36 36">
              <circle cx="18" cy="18" r="16" fill="none" stroke="#f0f0f0" strokeWidth="3" />
              <circle
                cx="18"
                cy="18"
                r="16"
                fill="none"
                stroke="currentColor"
                strokeWidth="3"
                strokeDasharray={`${stats.feel_accuracy_rate} ${100 - stats.feel_accuracy_rate}`}
                strokeLinecap="round"
                className={stats.feel_accuracy_rate >= 60 ? 'text-status-success' : 'text-status-warning'}
              />
            </svg>
            <span className="absolute inset-0 flex items-center justify-center text-xs font-bold text-text-primary">
              {stats.feel_accuracy_rate}%
            </span>
          </div>
          <div className="flex-1">
            <p className="text-xs text-text-secondary leading-relaxed">
              {stats.feel_accuracy_rate >= 70
                ? '내가 느끼는 감각과 실제 움직임이 잘 일치하고 있어요!'
                : stats.feel_accuracy_rate >= 40
                  ? '조금씩 감각이 맞아가고 있어요. 꾸준히 연습해보세요.'
                  : '느끼는 것과 실제가 다를 수 있어요. Feel Check를 더 신중히 해보세요.'}
            </p>
          </div>
        </div>
      </div>

      {/* Weekly Activity */}
      {stats.weekly_swings.length > 0 && (
        <div className="card p-4 mb-4">
          <h3 className="text-sm font-semibold text-text-primary mb-3">주간 연습량</h3>
          <div className="flex items-end gap-1 h-20">
            {stats.weekly_swings.map((week, idx) => {
              const max = Math.max(...stats.weekly_swings.map((w) => w.count), 1);
              const height = (week.count / max) * 100;
              return (
                <div key={idx} className="flex-1 flex flex-col items-center gap-1">
                  <div
                    className="w-full bg-brand-primary/20 rounded-t transition-all"
                    style={{ height: `${Math.max(height, 4)}%` }}
                  >
                    <div
                      className="w-full bg-brand-primary rounded-t transition-all"
                      style={{ height: '100%' }}
                    />
                  </div>
                  <span className="text-[8px] text-text-tertiary">{week.week}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Position Trend */}
      {stats.position_trends.length > 0 && (
        <div className="card p-4 mb-4">
          <h3 className="text-sm font-semibold text-text-primary mb-3">포지션별 변화</h3>
          <div className="space-y-2">
            {stats.position_trends.map((pt) => (
              <div key={pt.position} className="flex items-center gap-3">
                <span className="text-xs font-medium text-text-secondary w-8">{pt.position}</span>
                <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className={cn(
                      'h-full rounded-full transition-all',
                      pt.trend === 'improving' ? 'bg-status-success' :
                      pt.trend === 'stable' ? 'bg-brand-primary' : 'bg-status-warning'
                    )}
                    style={{ width: `${pt.recent_score}%` }}
                  />
                </div>
                <TrendIcon trend={pt.trend} />
                <span className="text-[10px] text-text-tertiary w-8 text-right">
                  {pt.recent_score}%
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Most Common Errors */}
      {stats.most_common_errors.length > 0 && (
        <div className="card p-4 mb-4">
          <h3 className="text-sm font-semibold text-text-primary mb-3">자주 나타나는 패턴</h3>
          <div className="space-y-2">
            {stats.most_common_errors.slice(0, 5).map((ep) => (
              <div key={ep.code} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] bg-gray-100 text-text-tertiary px-1.5 py-0.5 rounded font-mono">
                    {ep.code}
                  </span>
                  <span className="text-xs text-text-secondary">{ep.name}</span>
                </div>
                <span className="text-xs font-medium text-text-primary">{ep.count}회</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recent Reports */}
      {stats.recent_reports.length > 0 && (
        <div className="mb-4">
          <h3 className="text-sm font-semibold text-text-primary mb-3">최근 레슨 리포트</h3>
          <div className="space-y-2">
            {stats.recent_reports.map((report) => (
              <button
                key={report.id}
                type="button"
                onClick={() => router.push(`/my-reports/${report.id}`)}
                className="card p-3 w-full text-left flex items-center justify-between"
              >
                <div>
                  <p className="text-sm font-medium text-text-primary">{report.title}</p>
                  <p className="text-[10px] text-text-tertiary">
                    {report.pro_name} · {new Date(report.date).toLocaleDateString('ko-KR')}
                  </p>
                </div>
                <ChevronIcon className="w-4 h-4 text-text-tertiary" />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function MiniStat({
  label,
  value,
  suffix = '',
  color = 'text-text-primary',
}: {
  label: string;
  value: number;
  suffix?: string;
  color?: string;
}) {
  return (
    <div className="card p-2 text-center">
      <p className={cn('text-base font-bold', color)}>
        {value}{suffix}
      </p>
      <p className="text-[9px] text-text-tertiary">{label}</p>
    </div>
  );
}

function TrendIcon({ trend }: { trend: string }) {
  if (trend === 'improving') {
    return (
      <svg className="w-3 h-3 text-status-success" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 4l-8 8h5v8h6v-8h5z" />
      </svg>
    );
  }
  if (trend === 'declining') {
    return (
      <svg className="w-3 h-3 text-status-warning" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 20l8-8h-5V4h-6v8H4z" />
      </svg>
    );
  }
  return (
    <svg className="w-3 h-3 text-text-tertiary" viewBox="0 0 24 24" fill="currentColor">
      <rect x="4" y="10" width="16" height="4" rx="1" />
    </svg>
  );
}

function ChevronIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
      <polyline points="9,6 15,12 9,18" />
    </svg>
  );
}
