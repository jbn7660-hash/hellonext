/**
 * E2E Test: Practice Flow (핵심 사용자 여정 #1)
 *
 * Member 연습 플로우:
 *  1. Login → Practice 탭 이동
 *  2. 카메라 촬영 시작
 *  3. Feel Check 입력 (AI 원칙 4 준수 검증)
 *  4. AI 분석 결과 확인
 *
 * @playwright
 * @feature F-005
 */

import { test, expect } from '@playwright/test';

test.describe('Practice Flow (Member)', () => {
  test.beforeEach(async ({ page }) => {
    // Setup: Login as member via test account
    await page.goto('/login');
    await page.fill('[data-testid="email-input"]', 'test-member@hellonext.io');
    await page.click('[data-testid="email-login-btn"]');
    // Wait for redirect to member dashboard
    await page.waitForURL('/practice');
  });

  test('should display practice page with camera button', async ({ page }) => {
    await expect(page.locator('[data-testid="start-recording-btn"]')).toBeVisible();
    await expect(page.locator('h2')).toContainText('연습');
  });

  test('should enforce Feel Check before AI analysis (AI Principle 4)', async ({ page }) => {
    // Start recording
    await page.click('[data-testid="start-recording-btn"]');

    // Simulate camera recording (permission granted)
    await page.waitForSelector('[data-testid="recording-indicator"]', { timeout: 5000 });

    // Stop recording
    await page.click('[data-testid="stop-recording-btn"]');

    // Upload phase
    await page.waitForSelector('[data-testid="uploading-indicator"]', { timeout: 10000 });

    // CRITICAL: Feel Check MUST appear before analysis
    await expect(page.locator('[data-testid="feel-check-form"]')).toBeVisible();

    // AI analysis should NOT be visible yet
    await expect(page.locator('[data-testid="analysis-result"]')).not.toBeVisible();

    // Complete Feel Check
    await page.click('[data-testid="feel-good-btn"]');
    await page.click('[data-testid="feel-submit-btn"]');

    // NOW analysis should begin
    await page.waitForSelector('[data-testid="analyzing-indicator"]', { timeout: 5000 });

    // Wait for result
    await page.waitForSelector('[data-testid="analysis-result"]', { timeout: 30000 });
    await expect(page.locator('[data-testid="analysis-result"]')).toBeVisible();
  });

  test('should show 3 feel options: good, unsure, off', async ({ page }) => {
    // Navigate to feel check (simulate post-recording state)
    await page.goto('/practice?state=feel_check&videoId=test-123');

    await expect(page.locator('[data-testid="feel-good-btn"]')).toBeVisible();
    await expect(page.locator('[data-testid="feel-unsure-btn"]')).toBeVisible();
    await expect(page.locator('[data-testid="feel-off-btn"]')).toBeVisible();
  });
});
