/**
 * Unit Tests: FSM State Transition Validation
 *
 * 유한 상태 머신(FSM) 상태 전이 검증
 * - DC-5 위반 에러 확인
 * - Patent 4 Claim 1(e)의 복구 조치 5가지 검증
 * - target_id NULL 불변성 확인
 *
 * @feature F-020
 * @patent Patent 4
 * @requirement DC-5
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';

// ─── Type Definitions ────────────────────────────────────────────

type MeasurementState = 'UNBOUND' | 'PREPROCESSED' | 'LINKED' | 'FINALIZED';

interface StateTransition {
  from: MeasurementState;
  to: MeasurementState;
  targetId: string | null;
}

interface FSMValidationResult {
  isValid: boolean;
  error?: string;
  recoveryAction?: string;
}

// ─── FSM Validator Implementation (mock) ────────────────────────

class FSMValidator {
  /**
   * 상태 전이의 유효성을 검증합니다.
   * DC-5: 유효한 전이만 허용
   */
  validateTransition(transition: StateTransition): FSMValidationResult {
    const { from, to, targetId } = transition;

    // 유효한 상태 전이 경로
    const validTransitions: Record<MeasurementState, MeasurementState[]> = {
      UNBOUND: ['PREPROCESSED'],
      PREPROCESSED: ['LINKED'],
      LINKED: ['FINALIZED'],
      FINALIZED: [],
    };

    // 1. 전이 경로 유효성 확인
    if (!validTransitions[from].includes(to)) {
      return {
        isValid: false,
        error: `DC-5: Invalid transition from ${from} to ${to}`,
      };
    }

    // 2. target_id NULL 불변성 확인
    // UNBOUND, PREPROCESSED: NULL required
    // LINKED, FINALIZED: non-NULL required
    if ((from === 'UNBOUND' || from === 'PREPROCESSED') && targetId !== null) {
      return {
        isValid: false,
        error: `DC-5: target_id must be NULL in ${from} state`,
      };
    }

    if ((to === 'LINKED' || to === 'FINALIZED') && targetId === null) {
      return {
        isValid: false,
        error: `DC-5: target_id must be non-NULL in ${to} state`,
      };
    }

    return { isValid: true };
  }

  /**
   * Patent 4 Claim 1(e)의 복구 조치 5가지 중 적절한 조치를 반환합니다.
   */
  getRecoveryAction(failedTransition: StateTransition): string | null {
    const { from, to } = failedTransition;

    // 복구 조치 1: 건너뛴 상태로 돌아가기
    if (from === 'UNBOUND' && to === 'LINKED') {
      return 'Recovery Action 1: Reset to UNBOUND, retry with PREPROCESSED state';
    }

    // 복구 조치 2: 전 상태로 롤백
    if (from === 'PREPROCESSED' && to === 'FINALIZED') {
      return 'Recovery Action 2: Rollback to PREPROCESSED, wait for LINKED transition';
    }

    // 복구 조치 3: 자동 복구 시도
    if (from === 'FINALIZED') {
      return 'Recovery Action 3: Cannot recover from FINALIZED, requires manual intervention';
    }

    // 복구 조치 4: 캐시 초기화
    if (from === 'UNBOUND' && to === 'FINALIZED') {
      return 'Recovery Action 4: Clear preprocessing cache, restart from UNBOUND';
    }

    // 복구 조치 5: 상태 잠금 해제
    if (from === 'LINKED' && to === 'PREPROCESSED') {
      return 'Recovery Action 5: Unlock state machine, return to PREPROCESSED';
    }

    return null;
  }
}

// ─── Tests ──────────────────────────────────────────────────────

describe('FSM State Transition Validation (DC-5, Patent 4)', () => {
  let validator: FSMValidator;

  beforeEach(() => {
    validator = new FSMValidator();
  });

  describe('Valid Transitions', () => {
    // ─── 유효한 상태 전이 ───
    it('should allow UNBOUND → PREPROCESSED with NULL target_id', () => {
      const result = validator.validateTransition({
        from: 'UNBOUND',
        to: 'PREPROCESSED',
        targetId: null,
      });

      expect(result.isValid).toBe(true);
      expect(result.error).toBeUndefined();
    });

    it('should allow PREPROCESSED → LINKED with non-NULL target_id', () => {
      const result = validator.validateTransition({
        from: 'PREPROCESSED',
        to: 'LINKED',
        targetId: 'target-123',
      });

      expect(result.isValid).toBe(true);
      expect(result.error).toBeUndefined();
    });

    it('should allow LINKED → FINALIZED with non-NULL target_id', () => {
      const result = validator.validateTransition({
        from: 'LINKED',
        to: 'FINALIZED',
        targetId: 'target-456',
      });

      expect(result.isValid).toBe(true);
      expect(result.error).toBeUndefined();
    });
  });

  describe('Invalid Transitions (DC-5 violations)', () => {
    // ─── 무효한 상태 전이 ───
    it('should reject UNBOUND → LINKED (skip PREPROCESSED)', () => {
      const result = validator.validateTransition({
        from: 'UNBOUND',
        to: 'LINKED',
        targetId: 'target-123',
      });

      expect(result.isValid).toBe(false);
      expect(result.error).toContain('DC-5: Invalid transition');
    });

    it('should reject UNBOUND → FINALIZED (skip PREPROCESSED and LINKED)', () => {
      const result = validator.validateTransition({
        from: 'UNBOUND',
        to: 'FINALIZED',
        targetId: 'target-123',
      });

      expect(result.isValid).toBe(false);
      expect(result.error).toContain('DC-5: Invalid transition');
    });

    it('should reject PREPROCESSED → FINALIZED (skip LINKED)', () => {
      const result = validator.validateTransition({
        from: 'PREPROCESSED',
        to: 'FINALIZED',
        targetId: 'target-123',
      });

      expect(result.isValid).toBe(false);
      expect(result.error).toContain('DC-5: Invalid transition');
    });

    it('should reject any transition from FINALIZED state', () => {
      const result = validator.validateTransition({
        from: 'FINALIZED',
        to: 'PREPROCESSED',
        targetId: null,
      });

      expect(result.isValid).toBe(false);
      expect(result.error).toContain('DC-5: Invalid transition');
    });
  });

  describe('target_id NULL Invariant', () => {
    // ─── target_id NULL 불변성 ───
    it('should reject UNBOUND → PREPROCESSED with non-NULL target_id', () => {
      const result = validator.validateTransition({
        from: 'UNBOUND',
        to: 'PREPROCESSED',
        targetId: 'target-123',
      });

      expect(result.isValid).toBe(false);
      expect(result.error).toContain('target_id must be NULL in UNBOUND state');
    });

    it('should reject PREPROCESSED → LINKED with NULL target_id', () => {
      const result = validator.validateTransition({
        from: 'PREPROCESSED',
        to: 'LINKED',
        targetId: null,
      });

      expect(result.isValid).toBe(false);
      expect(result.error).toContain('target_id must be non-NULL in LINKED state');
    });

    it('should reject LINKED → FINALIZED with NULL target_id', () => {
      const result = validator.validateTransition({
        from: 'LINKED',
        to: 'FINALIZED',
        targetId: null,
      });

      expect(result.isValid).toBe(false);
      expect(result.error).toContain('target_id must be non-NULL in FINALIZED state');
    });

    it('should reject PREPROCESSED state with non-NULL target_id', () => {
      const result = validator.validateTransition({
        from: 'PREPROCESSED',
        to: 'PREPROCESSED',
        targetId: 'target-invalid',
      });

      expect(result.isValid).toBe(false);
      expect(result.error).toContain('target_id must be NULL in PREPROCESSED state');
    });
  });

  describe('Recovery Actions (Patent 4 Claim 1(e))', () => {
    // ─── Patent 4의 5가지 복구 조치 ───
    it('Recovery Action 1: should recommend reset on UNBOUND → LINKED skip', () => {
      const failedTransition: StateTransition = {
        from: 'UNBOUND',
        to: 'LINKED',
        targetId: 'target-123',
      };

      const recovery = validator.getRecoveryAction(failedTransition);
      expect(recovery).toContain('Recovery Action 1');
      expect(recovery).toContain('PREPROCESSED');
    });

    it('Recovery Action 2: should recommend rollback on PREPROCESSED → FINALIZED skip', () => {
      const failedTransition: StateTransition = {
        from: 'PREPROCESSED',
        to: 'FINALIZED',
        targetId: 'target-123',
      };

      const recovery = validator.getRecoveryAction(failedTransition);
      expect(recovery).toContain('Recovery Action 2');
      expect(recovery).toContain('Rollback');
    });

    it('Recovery Action 3: should fail on FINALIZED state (manual intervention required)', () => {
      const failedTransition: StateTransition = {
        from: 'FINALIZED',
        to: 'LINKED',
        targetId: 'target-123',
      };

      const recovery = validator.getRecoveryAction(failedTransition);
      expect(recovery).toContain('Recovery Action 3');
      expect(recovery).toContain('manual intervention');
    });

    it('Recovery Action 4: should recommend cache clear on UNBOUND → FINALIZED skip', () => {
      const failedTransition: StateTransition = {
        from: 'UNBOUND',
        to: 'FINALIZED',
        targetId: 'target-123',
      };

      const recovery = validator.getRecoveryAction(failedTransition);
      expect(recovery).toContain('Recovery Action 4');
      expect(recovery).toContain('cache');
    });

    it('Recovery Action 5: should recommend state unlock (backward transition)', () => {
      const failedTransition: StateTransition = {
        from: 'LINKED',
        to: 'PREPROCESSED',
        targetId: null,
      };

      const recovery = validator.getRecoveryAction(failedTransition);
      expect(recovery).toContain('Recovery Action 5');
      expect(recovery).toContain('Unlock');
    });
  });

  describe('Complex Transition Scenarios', () => {
    // ─── 복잡한 전이 시나리오 ───
    it('should validate complete happy path: UNBOUND → PREPROCESSED → LINKED → FINALIZED', () => {
      const transitions: StateTransition[] = [
        { from: 'UNBOUND', to: 'PREPROCESSED', targetId: null },
        { from: 'PREPROCESSED', to: 'LINKED', targetId: 'target-1' },
        { from: 'LINKED', to: 'FINALIZED', targetId: 'target-1' },
      ];

      transitions.forEach((t) => {
        const result = validator.validateTransition(t);
        expect(result.isValid).toBe(true);
      });
    });

    it('should fail fast on first invalid transition in sequence', () => {
      const badTransition: StateTransition = {
        from: 'UNBOUND',
        to: 'FINALIZED',
        targetId: 'target-123',
      };

      const result = validator.validateTransition(badTransition);
      expect(result.isValid).toBe(false);
      expect(result.error).toBeDefined();
    });

    it('should detect multiple violations (path + target_id)', () => {
      // UNBOUND → FINALIZED (invalid path) + non-NULL target_id (invalid for UNBOUND)
      const result = validator.validateTransition({
        from: 'UNBOUND',
        to: 'FINALIZED',
        targetId: 'target-123',
      });

      expect(result.isValid).toBe(false);
      // Should report path error first
      expect(result.error).toContain('Invalid transition');
    });
  });

  describe('Edge Cases and Boundary Conditions', () => {
    // ─── 경계 조건 및 엣지 케이스 ───
    it('should handle empty string as NULL for target_id', () => {
      const result = validator.validateTransition({
        from: 'UNBOUND',
        to: 'PREPROCESSED',
        targetId: '' as unknown as null, // Treat empty string as falsy
      });

      // Should still be valid if treated as null
      expect(result.isValid).toBe(true);
    });

    it('should reject very long target_id string', () => {
      const longId = 'a'.repeat(1000);
      const result = validator.validateTransition({
        from: 'PREPROCESSED',
        to: 'LINKED',
        targetId: longId,
      });

      // Path is valid, target_id format not validated here (separate layer)
      expect(result.isValid).toBe(true);
    });

    it('should reject UUID-like target_id in UNBOUND state', () => {
      const result = validator.validateTransition({
        from: 'UNBOUND',
        to: 'PREPROCESSED',
        targetId: '550e8400-e29b-41d4-a716-446655440000',
      });

      expect(result.isValid).toBe(false);
      expect(result.error).toContain('must be NULL');
    });
  });
});
