/**
 * Unit Tests: Measurement Confidence Calculation
 *
 * 측정 신뢰도 계산 및 분류 검증
 * - 5-인자 공식: keypoint_vis × cam_angle × motion_blur × occlusion × K
 * - 신뢰도 분류: 확인됨 (>=0.7), 대기중 (0.4-0.69), 숨김 (<0.4)
 * - 검증 토큰 발행 조건
 *
 * @feature F-016
 * @patent Patent 3
 * @requirement DC-2
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';

// ─── Type Definitions ────────────────────────────────────────────

type ConfidenceClass = 'confirmed' | 'pending_verification' | 'hidden';

interface ConfidenceFactors {
  keypointVisibility: number; // 0-1
  cameraAngle: number; // 0-1
  motionBlur: number; // 0-1
  occlusion: number; // 0-1
}

interface ConfidenceResult {
  score: number; // 0-1
  classification: ConfidenceClass;
  verificationTokenRequired: boolean;
}

// ─── Confidence Calculator Implementation (mock) ──────────────────

class ConfidenceCalculator {
  private readonly K = 1.0; // Constant factor

  /**
   * 신뢰도를 계산합니다 (5-인자 공식).
   * score = keypoint_vis × cam_angle × motion_blur × occlusion × K
   */
  calculateConfidence(factors: ConfidenceFactors): number {
    const { keypointVisibility, cameraAngle, motionBlur, occlusion } = factors;

    // 입력값 범위 검증
    if (
      keypointVisibility < 0 ||
      keypointVisibility > 1 ||
      cameraAngle < 0 ||
      cameraAngle > 1 ||
      motionBlur < 0 ||
      motionBlur > 1 ||
      occlusion < 0 ||
      occlusion > 1
    ) {
      throw new Error('All factors must be between 0 and 1');
    }

    // 5-인자 공식
    return keypointVisibility * cameraAngle * motionBlur * occlusion * this.K;
  }

  /**
   * 신뢰도 점수를 분류합니다.
   */
  classifyConfidence(score: number): ConfidenceClass {
    if (score >= 0.7) {
      return 'confirmed';
    } else if (score >= 0.4 && score < 0.7) {
      return 'pending_verification';
    } else {
      return 'hidden';
    }
  }

  /**
   * 결과를 통합적으로 계산합니다.
   */
  computeConfidenceResult(factors: ConfidenceFactors): ConfidenceResult {
    const score = this.calculateConfidence(factors);
    const classification = this.classifyConfidence(score);

    // 검증 토큰은 pending_verification 상태일 때만 발행
    const verificationTokenRequired = classification === 'pending_verification';

    return {
      score,
      classification,
      verificationTokenRequired,
    };
  }

  /**
   * 신뢰도 점수가 유효한 범위인지 검증합니다.
   */
  validateScore(score: number): boolean {
    return score >= 0 && score <= 1;
  }
}

// ─── Tests ──────────────────────────────────────────────────────

describe('Confidence Score Calculation (DC-2, Patent 3)', () => {
  let calculator: ConfidenceCalculator;

  beforeEach(() => {
    calculator = new ConfidenceCalculator();
  });

  describe('5-Factor Formula Correctness', () => {
    // ─── 5-인자 공식 정확성 ───
    it('should calculate confidence using all 5 factors', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0.9,
        cameraAngle: 0.8,
        motionBlur: 0.7,
        occlusion: 0.6,
      };

      const score = calculator.calculateConfidence(factors);
      const expected = 0.9 * 0.8 * 0.7 * 0.6 * 1.0;

      expect(score).toBeCloseTo(expected, 5);
    });

    it('should multiply factors correctly: 0.5 × 0.5 × 0.5 × 0.5 × 1.0 = 0.0625', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0.5,
        cameraAngle: 0.5,
        motionBlur: 0.5,
        occlusion: 0.5,
      };

      const score = calculator.calculateConfidence(factors);
      expect(score).toBeCloseTo(0.0625, 5);
    });

    it('should multiply factors correctly: 1.0 × 1.0 × 1.0 × 1.0 × 1.0 = 1.0', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 1.0,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const score = calculator.calculateConfidence(factors);
      expect(score).toBeCloseTo(1.0, 5);
    });
  });

  describe('Edge Cases: All Factors = 1.0', () => {
    // ─── 모든 인자가 1.0일 때 ───
    it('should result in confidence = K (1.0) when all factors are 1.0', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 1.0,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const score = calculator.calculateConfidence(factors);
      expect(score).toBe(1.0);
    });
  });

  describe('Edge Cases: Any Factor = 0', () => {
    // ─── 어떤 인자가 0일 때 ───
    it('should result in confidence = 0 when keypointVisibility is 0', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const score = calculator.calculateConfidence(factors);
      expect(score).toBe(0);
    });

    it('should result in confidence = 0 when cameraAngle is 0', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 1.0,
        cameraAngle: 0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const score = calculator.calculateConfidence(factors);
      expect(score).toBe(0);
    });

    it('should result in confidence = 0 when motionBlur is 0', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 1.0,
        cameraAngle: 1.0,
        motionBlur: 0,
        occlusion: 1.0,
      };

      const score = calculator.calculateConfidence(factors);
      expect(score).toBe(0);
    });

    it('should result in confidence = 0 when occlusion is 0', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 1.0,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 0,
      };

      const score = calculator.calculateConfidence(factors);
      expect(score).toBe(0);
    });

    it('should result in confidence = 0 when multiple factors are 0', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0,
        cameraAngle: 0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const score = calculator.calculateConfidence(factors);
      expect(score).toBe(0);
    });
  });

  describe('Classification: Confirmed (>= 0.7)', () => {
    // ─── 분류: 확인됨 ───
    it('should classify score 1.0 as confirmed', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 1.0,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const result = calculator.computeConfidenceResult(factors);
      expect(result.classification).toBe('confirmed');
      expect(result.score).toBeCloseTo(1.0);
    });

    it('should classify score 0.7 as confirmed', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0.7,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const result = calculator.computeConfidenceResult(factors);
      expect(result.classification).toBe('confirmed');
      expect(result.score).toBeCloseTo(0.7);
    });

    it('should classify score 0.8 as confirmed', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0.8,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const result = calculator.computeConfidenceResult(factors);
      expect(result.classification).toBe('confirmed');
    });
  });

  describe('Classification: Pending Verification (0.4 - 0.69)', () => {
    // ─── 분류: 대기중 ───
    it('should classify score 0.4 as pending_verification', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0.4,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const result = calculator.computeConfidenceResult(factors);
      expect(result.classification).toBe('pending_verification');
      expect(result.score).toBeCloseTo(0.4);
    });

    it('should classify score 0.5 as pending_verification', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0.5,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const result = calculator.computeConfidenceResult(factors);
      expect(result.classification).toBe('pending_verification');
    });

    it('should classify score 0.69 as pending_verification', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0.69,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const result = calculator.computeConfidenceResult(factors);
      expect(result.classification).toBe('pending_verification');
    });

    it('should classify score 0.6 as pending_verification', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0.6,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const result = calculator.computeConfidenceResult(factors);
      expect(result.classification).toBe('pending_verification');
    });
  });

  describe('Classification: Hidden (< 0.4)', () => {
    // ─── 분류: 숨김 ───
    it('should classify score 0.39 as hidden', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0.39,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const result = calculator.computeConfidenceResult(factors);
      expect(result.classification).toBe('hidden');
      expect(result.score).toBeCloseTo(0.39);
    });

    it('should classify score 0.3 as hidden', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0.3,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const result = calculator.computeConfidenceResult(factors);
      expect(result.classification).toBe('hidden');
    });

    it('should classify score 0 as hidden', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const result = calculator.computeConfidenceResult(factors);
      expect(result.classification).toBe('hidden');
    });
  });

  describe('Boundary Values', () => {
    // ─── 경계값 ───
    it('should handle exact boundary: 0.7 (confirmed)', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0.7,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const result = calculator.computeConfidenceResult(factors);
      expect(result.classification).toBe('confirmed');
    });

    it('should handle exact boundary: 0.4 (pending_verification)', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0.4,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const result = calculator.computeConfidenceResult(factors);
      expect(result.classification).toBe('pending_verification');
    });

    it('should handle near-boundary: 0.699999 (pending_verification)', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0.699999,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const result = calculator.computeConfidenceResult(factors);
      expect(result.classification).toBe('pending_verification');
    });

    it('should handle near-boundary: 0.400001 (pending_verification)', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0.400001,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const result = calculator.computeConfidenceResult(factors);
      expect(result.classification).toBe('pending_verification');
    });
  });

  describe('Verification Token Issuance', () => {
    // ─── 검증 토큰 발행 ───
    it('should issue verification token for pending_verification state', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0.5,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const result = calculator.computeConfidenceResult(factors);
      expect(result.classification).toBe('pending_verification');
      expect(result.verificationTokenRequired).toBe(true);
    });

    it('should NOT issue verification token for confirmed state', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0.8,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const result = calculator.computeConfidenceResult(factors);
      expect(result.classification).toBe('confirmed');
      expect(result.verificationTokenRequired).toBe(false);
    });

    it('should NOT issue verification token for hidden state', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0.3,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      const result = calculator.computeConfidenceResult(factors);
      expect(result.classification).toBe('hidden');
      expect(result.verificationTokenRequired).toBe(false);
    });
  });

  describe('Score Validation', () => {
    // ─── 점수 검증 ───
    it('should reject score < 0', () => {
      expect(calculator.validateScore(-0.1)).toBe(false);
      expect(calculator.validateScore(-1)).toBe(false);
    });

    it('should reject score > 1', () => {
      expect(calculator.validateScore(1.1)).toBe(false);
      expect(calculator.validateScore(2)).toBe(false);
    });

    it('should accept score = 0', () => {
      expect(calculator.validateScore(0)).toBe(true);
    });

    it('should accept score = 1', () => {
      expect(calculator.validateScore(1)).toBe(true);
    });

    it('should accept score between 0 and 1', () => {
      expect(calculator.validateScore(0.5)).toBe(true);
      expect(calculator.validateScore(0.123)).toBe(true);
      expect(calculator.validateScore(0.999)).toBe(true);
    });
  });

  describe('Input Validation', () => {
    // ─── 입력 검증 ───
    it('should throw error when keypointVisibility < 0', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: -0.1,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      expect(() => calculator.calculateConfidence(factors)).toThrow();
    });

    it('should throw error when any factor > 1', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 1.1,
        cameraAngle: 1.0,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      expect(() => calculator.calculateConfidence(factors)).toThrow();
    });

    it('should throw error when cameraAngle > 1', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 1.0,
        cameraAngle: 1.5,
        motionBlur: 1.0,
        occlusion: 1.0,
      };

      expect(() => calculator.calculateConfidence(factors)).toThrow();
    });
  });

  describe('Complex Scenarios', () => {
    // ─── 복잡한 시나리오 ───
    it('should handle realistic swing measurement: good form, poor angle', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0.95, // Good keypoint visibility
        cameraAngle: 0.4, // Poor camera angle
        motionBlur: 0.8, // Minor motion blur
        occlusion: 0.9, // Minimal occlusion
      };

      const result = calculator.computeConfidenceResult(factors);
      const expectedScore = 0.95 * 0.4 * 0.8 * 0.9;

      expect(result.score).toBeCloseTo(expectedScore);
      expect(result.classification).toBe('pending_verification');
    });

    it('should handle realistic swing measurement: good form, good angle', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0.95,
        cameraAngle: 0.85,
        motionBlur: 0.9,
        occlusion: 0.95,
      };

      const result = calculator.computeConfidenceResult(factors);
      expect(result.classification).toBe('confirmed');
      expect(result.verificationTokenRequired).toBe(false);
    });

    it('should handle poor measurement', () => {
      const factors: ConfidenceFactors = {
        keypointVisibility: 0.5,
        cameraAngle: 0.5,
        motionBlur: 0.5,
        occlusion: 0.5,
      };

      const result = calculator.computeConfidenceResult(factors);
      expect(result.classification).toBe('hidden');
    });
  });
});
