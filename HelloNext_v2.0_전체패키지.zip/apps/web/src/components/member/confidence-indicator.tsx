/**
 * Confidence Indicator Component
 *
 * Shows measurement confidence state to members.
 * - Confirmed: green solid indicator
 * - Pending: yellow dashed with "검토 필요" label
 * - Hidden: not rendered
 *
 * @module components/member/confidence-indicator
 * @feature DC-2
 */

'use client';

import { getConfidenceDisplayProps } from '@/lib/patent/state-classifier';
import type { ConfidenceState } from '@/lib/patent/state-classifier';

interface ConfidenceIndicatorProps {
  state: ConfidenceState;
  score?: number;
  showLabel?: boolean;
  showScore?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export function ConfidenceIndicator({
  state,
  score,
  showLabel = true,
  showScore = false,
  size = 'md',
}: ConfidenceIndicatorProps) {
  // Don't render hidden measurements
  if (state === 'hidden') {
    return null;
  }

  const displayProps = getConfidenceDisplayProps(state);

  const sizeClasses = {
    sm: {
      indicator: 'h-2 w-2',
      text: 'text-xs',
    },
    md: {
      indicator: 'h-3 w-3',
      text: 'text-sm',
    },
    lg: {
      indicator: 'h-4 w-4',
      text: 'text-base',
    },
  };

  const borderStyle =
    state === 'pending'
      ? 'border-2 border-dashed'
      : 'border-2 border-solid';

  const backgroundColor =
    state === 'confirmed' ? 'bg-green-600' : 'bg-yellow-500';

  return (
    <div className="flex items-center gap-2">
      {/* Indicator circle */}
      <div
        className={`${sizeClasses[size].indicator} rounded-full ${backgroundColor} ${borderStyle} border-gray-300`}
      />

      {/* Label and score */}
      {showLabel && (
        <span className={`font-medium ${displayProps.color} ${sizeClasses[size].text}`}>
          {displayProps.label}
        </span>
      )}

      {showScore && score !== undefined && (
        <span className={`text-gray-600 ${sizeClasses[size].text}`}>
          {Math.round(score * 100)}%
        </span>
      )}
    </div>
  );
}

/**
 * Inline confidence badge for use within measurement displays.
 */
export function ConfidenceBadge({
  state,
  score,
  compact = false,
}: {
  state: ConfidenceState;
  score?: number;
  compact?: boolean;
}) {
  // Don't render hidden measurements
  if (state === 'hidden') {
    return null;
  }

  const displayProps = getConfidenceDisplayProps(state);
  const scorePercent = score ? Math.round(score * 100) : null;

  const backgroundMap: Record<ConfidenceState, string> = {
    confirmed: 'bg-green-100 text-green-800',
    pending: 'bg-yellow-100 text-yellow-800',
    hidden: 'bg-gray-100 text-gray-800',
  };

  if (compact) {
    return (
      <span className={`inline-block px-2 py-1 rounded text-xs font-medium ${backgroundMap[state]}`}>
        {displayProps.icon}
      </span>
    );
  }

  return (
    <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${backgroundMap[state]}`}>
      {displayProps.label}
      {scorePercent && <span className="ml-1">({scorePercent}%)</span>}
    </span>
  );
}
