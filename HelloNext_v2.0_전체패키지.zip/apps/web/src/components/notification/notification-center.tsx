/**
 * NotificationCenter Component
 *
 * Bell icon with badge + dropdown/sheet showing recent notifications.
 * Subscribes to Realtime for instant delivery.
 *
 * @module components/notification/notification-center
 * @feature F-014
 */

'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { useRealtimeBroadcast } from '@/hooks/use-realtime';
import { useAuth } from '@/hooks/use-auth';
import { formatRelativeTime } from '@/lib/utils/format';
import { cn } from '@/lib/utils/cn';
import { logger } from '@/lib/utils/logger';

interface Notification {
  id: string;
  type: 'report' | 'reminder' | 'coupon' | 'system';
  title: string;
  body: string;
  data: Record<string, string>;
  is_read: boolean;
  created_at: string;
}

export function NotificationCenter() {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);

  // Fetch notifications
  const fetchNotifications = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/notifications?page=1');
      if (res.ok) {
        const data = await res.json();
        setNotifications(data.data);
        setUnreadCount(data.unread_count);
      }
    } catch (err) {
      logger.error('Failed to fetch notifications', { error: err });
    } finally {
      setLoading(false);
    }
  }, []);

  // Initial fetch
  useEffect(() => {
    fetchNotifications();
  }, [fetchNotifications]);

  // Realtime: listen for new notifications
  useRealtimeBroadcast<{ type: string; title: string; body: string; data: Record<string, string> }>(
    `user-${user?.id ?? 'none'}`,
    'notification',
    (payload) => {
      const newNotif: Notification = {
        id: `temp-${Date.now()}`,
        type: payload.type as Notification['type'],
        title: payload.title,
        body: payload.body,
        data: payload.data ?? {},
        is_read: false,
        created_at: new Date().toISOString(),
      };
      setNotifications((prev) => [newNotif, ...prev]);
      setUnreadCount((prev) => prev + 1);
    },
    !!user?.id
  );

  // Close on outside click
  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [isOpen]);

  // Mark all as read
  const handleMarkAllRead = useCallback(async () => {
    try {
      await fetch('/api/notifications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mark_all: true }),
      });
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
      setUnreadCount(0);
    } catch (err) {
      logger.error('Failed to mark all read', { error: err });
    }
  }, []);

  const typeIcon: Record<string, string> = {
    report: '📋',
    reminder: '⏰',
    coupon: '🎟️',
    system: '📢',
  };

  return (
    <div className="relative" ref={panelRef}>
      {/* Bell Button */}
      <button
        type="button"
        onClick={() => {
          setIsOpen(!isOpen);
          if (!isOpen) fetchNotifications();
        }}
        className="relative p-2 rounded-full hover:bg-gray-100 transition-colors"
        aria-label="알림"
      >
        <BellIcon className="w-5 h-5 text-text-secondary" />
        {unreadCount > 0 && (
          <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-status-error text-white text-[10px] font-bold rounded-full flex items-center justify-center">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {/* Dropdown Panel */}
      {isOpen && (
        <div className="absolute right-0 top-12 w-80 max-h-96 bg-surface-primary rounded-xl shadow-xl border border-gray-100 overflow-hidden animate-fade-in z-50">
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
            <h3 className="text-sm font-semibold text-text-primary">알림</h3>
            {unreadCount > 0 && (
              <button
                type="button"
                onClick={handleMarkAllRead}
                className="text-xs text-brand-primary"
              >
                모두 읽음
              </button>
            )}
          </div>

          {/* List */}
          <div className="overflow-y-auto max-h-80">
            {loading && notifications.length === 0 ? (
              <div className="py-8 text-center text-sm text-text-tertiary">로딩 중...</div>
            ) : notifications.length === 0 ? (
              <div className="py-8 text-center text-sm text-text-tertiary">
                알림이 없습니다
              </div>
            ) : (
              notifications.map((notif) => (
                <div
                  key={notif.id}
                  className={cn(
                    'px-4 py-3 border-b border-gray-50 hover:bg-gray-50 transition-colors',
                    !notif.is_read && 'bg-brand-primary/5'
                  )}
                >
                  <div className="flex items-start gap-2">
                    <span className="text-base mt-0.5">{typeIcon[notif.type] ?? '📌'}</span>
                    <div className="flex-1 min-w-0">
                      <p className={cn(
                        'text-sm',
                        notif.is_read ? 'text-text-secondary' : 'text-text-primary font-medium'
                      )}>
                        {notif.title}
                      </p>
                      <p className="text-xs text-text-tertiary mt-0.5 line-clamp-2">
                        {notif.body}
                      </p>
                      <p className="text-[10px] text-text-tertiary mt-1">
                        {formatRelativeTime(notif.created_at)}
                      </p>
                    </div>
                    {!notif.is_read && (
                      <span className="w-2 h-2 rounded-full bg-brand-primary shrink-0 mt-2" />
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function BellIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
      <path d="M13.73 21a2 2 0 0 1-3.46 0" />
    </svg>
  );
}
