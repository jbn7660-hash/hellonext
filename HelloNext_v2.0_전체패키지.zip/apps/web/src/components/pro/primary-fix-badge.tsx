/**
 * Primary Fix Badge Component
 *
 * Badge component displaying the primary fix recommendation.
 * Shows the error pattern name and IIS score.
 *
 * @module components/pro/primary-fix-badge
 * @feature F-015
 */

'use client';

interface PrimaryFixBadgeProps {
  errorPattern: string;
  iisScore: number;
  rationale?: string;
  className?: string;
}

export function PrimaryFixBadge({
  errorPattern,
  iisScore,
  rationale,
  className = '',
}: PrimaryFixBadgeProps) {
  const iisPercent = Math.round(iisScore * 100);

  return (
    <div
      className={`rounded-lg border-2 border-red-500 bg-red-50 p-4 ${className}`}
      title={rationale}
    >
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <h3 className="font-semibold text-red-900">기본 수정 권장</h3>
          <p className="mt-1 text-sm text-red-800">{errorPattern}</p>
          {rationale && <p className="mt-2 text-xs text-red-700">{rationale}</p>}
        </div>
        <div className="ml-4 text-right">
          <div className="text-3xl font-bold text-red-600">{iisPercent}%</div>
          <p className="text-xs text-red-600">IIS</p>
        </div>
      </div>
    </div>
  );
}
