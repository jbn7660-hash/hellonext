/**
 * Edit Delta History Component
 *
 * Displays a list of edit deltas for a coaching decision.
 * Shows before/after diff for each edited field.
 *
 * @module components/pro/edit-delta-history
 * @feature F-010 (Edit Tracking)
 */

'use client';

interface EditDelta {
  timestamp: string;
  fieldName: string;
  beforeValue: string | number | boolean;
  afterValue: string | number | boolean;
  editedBy: string;
}

interface EditDeltaHistoryProps {
  deltas: EditDelta[];
  showEditor?: boolean;
}

export function EditDeltaHistory({ deltas, showEditor = true }: EditDeltaHistoryProps) {
  if (deltas.length === 0) {
    return (
      <div className="rounded-lg border border-gray-200 bg-gray-50 p-4 text-center">
        <p className="text-sm text-gray-500">수정 기록이 없습니다</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="font-semibold text-gray-900">수정 기록</h3>
      <div className="space-y-3">
        {deltas.map((delta, index) => (
          <div
            key={index}
            className="rounded-lg border border-gray-200 bg-white p-4"
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-gray-900">{delta.fieldName}</span>
                <span className="text-xs text-gray-500">
                  {new Date(delta.timestamp).toLocaleString('ko-KR')}
                </span>
              </div>
              {showEditor && (
                <span className="text-xs text-gray-600 bg-gray-100 px-2 py-1 rounded">
                  {delta.editedBy}
                </span>
              )}
            </div>

            {/* Before/After */}
            <div className="flex items-center gap-3">
              {/* Before */}
              <div className="flex-1">
                <p className="text-xs text-gray-600 mb-1">수정 전</p>
                <div className="rounded bg-red-50 border border-red-200 px-3 py-2 font-mono text-sm text-red-700">
                  {typeof delta.beforeValue === 'boolean'
                    ? delta.beforeValue
                      ? '예'
                      : '아니오'
                    : String(delta.beforeValue)}
                </div>
              </div>

              {/* Arrow */}
              <div className="text-gray-400">→</div>

              {/* After */}
              <div className="flex-1">
                <p className="text-xs text-gray-600 mb-1">수정 후</p>
                <div className="rounded bg-green-50 border border-green-200 px-3 py-2 font-mono text-sm text-green-700">
                  {typeof delta.afterValue === 'boolean'
                    ? delta.afterValue
                      ? '예'
                      : '아니오'
                    : String(delta.afterValue)}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
