/**
 * Causal Graph Viewer Component
 *
 * Simple DAG visualization of causal graph showing error patterns and their relationships.
 * Uses inline SVG for rendering without external graph library dependencies.
 *
 * @module components/pro/causal-graph-viewer
 * @feature F-015
 */

'use client';

import { useMemo } from 'react';
import type { CausalGraphNode, CausalGraphEdge } from '@/hooks/use-causal-graph';

interface CausalGraphViewerProps {
  nodes: CausalGraphNode[];
  edges: CausalGraphEdge[];
  primaryFixNodeId?: string;
  width?: number;
  height?: number;
}

/**
 * Calculate node positions using a simple hierarchical layout.
 */
function calculateNodePositions(
  nodes: CausalGraphNode[],
  width: number,
  height: number
): Map<string, { x: number; y: number }> {
  const positions = new Map<string, { x: number; y: number }>();

  if (nodes.length === 0) return positions;

  if (nodes.length === 1) {
    positions.set(nodes[0].id, { x: width / 2, y: height / 2 });
    return positions;
  }

  const padding = 60;
  const usableWidth = width - padding * 2;
  const usableHeight = height - padding * 2;

  nodes.forEach((node, index) => {
    const angle = (index / nodes.length) * Math.PI * 2;
    const radius = Math.min(usableWidth, usableHeight) / 3;
    const x = width / 2 + radius * Math.cos(angle);
    const y = height / 2 + radius * Math.sin(angle);
    positions.set(node.id, { x, y });
  });

  return positions;
}

export function CausalGraphViewer({
  nodes,
  edges,
  primaryFixNodeId,
  width = 400,
  height = 300,
}: CausalGraphViewerProps) {
  const nodePositions = useMemo(
    () => calculateNodePositions(nodes, width, height),
    [nodes, width, height]
  );

  const nodeRadius = 30;

  // Early return if no nodes
  if (nodes.length === 0) {
    return (
      <div className="flex h-full items-center justify-center rounded-lg border border-gray-200 bg-gray-50">
        <p className="text-sm text-gray-500">인과 그래프가 없습니다</p>
      </div>
    );
  }

  return (
    <div className="rounded-lg border border-gray-200 bg-white p-4">
      <svg width={width} height={height} className="border border-gray-100 rounded">
        {/* Draw edges */}
        {edges.map((edge) => {
          const sourcePos = nodePositions.get(edge.source);
          const targetPos = nodePositions.get(edge.target);

          if (!sourcePos || !targetPos) return null;

          // Arrow parameters
          const dx = targetPos.x - sourcePos.x;
          const dy = targetPos.y - sourcePos.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          const angle = Math.atan2(dy, dx);

          // Adjust start and end points to node boundaries
          const startX = sourcePos.x + nodeRadius * Math.cos(angle);
          const startY = sourcePos.y + nodeRadius * Math.sin(angle);
          const endX = targetPos.x - nodeRadius * Math.cos(angle);
          const endY = targetPos.y - nodeRadius * Math.sin(angle);

          // Arrow head size
          const arrowSize = 8;

          return (
            <g key={`edge-${edge.source}-${edge.target}`}>
              {/* Line */}
              <line
                x1={startX}
                y1={startY}
                x2={endX}
                y2={endY}
                stroke={`rgba(59, 130, 246, ${edge.weight * 0.8})`}
                strokeWidth={Math.max(1, edge.weight * 3)}
                markerEnd={`url(#arrowhead-${edge.weight})`}
              />
              {/* Weight label */}
              <text
                x={(startX + endX) / 2}
                y={(startY + endY) / 2 - 5}
                textAnchor="middle"
                fontSize="12"
                fill="#666"
                className="pointer-events-none"
              >
                {edge.weight.toFixed(2)}
              </text>
            </g>
          );
        })}

        {/* Arrow markers */}
        <defs>
          {[0.2, 0.4, 0.6, 0.8, 1.0].map((weight) => (
            <marker
              key={`arrowhead-${weight}`}
              id={`arrowhead-${weight}`}
              markerWidth="10"
              markerHeight="10"
              refX="9"
              refY="3"
              orient="auto"
            >
              <polygon
                points="0 0, 10 3, 0 6"
                fill={`rgba(59, 130, 246, ${weight * 0.8})`}
              />
            </marker>
          ))}
        </defs>

        {/* Draw nodes */}
        {nodes.map((node) => {
          const pos = nodePositions.get(node.id);
          if (!pos) return null;

          const isPrimaryFix = node.id === primaryFixNodeId;
          const strokeColor = isPrimaryFix ? '#ef4444' : '#d1d5db';
          const strokeWidth = isPrimaryFix ? 3 : 2;
          const fill = isPrimaryFix ? '#fee2e2' : '#f9fafb';

          return (
            <g key={node.id}>
              {/* Circle background */}
              <circle
                cx={pos.x}
                cy={pos.y}
                r={nodeRadius}
                fill={fill}
                stroke={strokeColor}
                strokeWidth={strokeWidth}
              />
              {/* IIS Score badge */}
              <circle
                cx={pos.x + nodeRadius - 6}
                cy={pos.y - nodeRadius + 6}
                r={12}
                fill="#3b82f6"
              />
              <text
                x={pos.x + nodeRadius - 6}
                y={pos.y - nodeRadius + 10}
                textAnchor="middle"
                fontSize="10"
                fill="white"
                fontWeight="bold"
              >
                {node.iisScore.toFixed(1)}
              </text>
              {/* Node label */}
              <text
                x={pos.x}
                y={pos.y + 5}
                textAnchor="middle"
                fontSize="12"
                fill="#1f2937"
                className="pointer-events-none font-semibold"
              >
                {node.label.substring(0, 8)}
                {node.label.length > 8 ? '...' : ''}
              </text>
              {/* Primary fix indicator */}
              {isPrimaryFix && (
                <text
                  x={pos.x}
                  y={pos.y + nodeRadius + 20}
                  textAnchor="middle"
                  fontSize="11"
                  fill="#ef4444"
                  fontWeight="bold"
                >
                  Primary
                </text>
              )}
            </g>
          );
        })}
      </svg>

      {/* Legend */}
      <div className="mt-4 space-y-2 text-sm">
        <div className="flex items-center gap-2">
          <div className="h-6 w-6 rounded border-2 border-gray-300 bg-gray-50" />
          <span className="text-gray-700">일반 에러 패턴</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-6 w-6 rounded border-2 border-red-600 bg-red-50" />
          <span className="text-gray-700">기본 수정 대상</span>
        </div>
      </div>
    </div>
  );
}
