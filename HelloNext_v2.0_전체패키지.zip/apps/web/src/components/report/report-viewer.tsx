/**
 * ReportViewer Component
 *
 * Renders a structured golf lesson report.
 * Displays: summary, error pattern analysis, drill recommendations,
 * homework assignments, and transcript reference.
 *
 * Used by both pro (editing mode) and member (read-only mode).
 *
 * @module components/report/report-viewer
 * @feature F-001
 */

'use client';

import { useState, useCallback } from 'react';
import { cn } from '@/lib/utils/cn';
import { formatDate, formatDuration } from '@/lib/utils/format';
import type { ReportContent, ReportSection } from '@hellonext/shared/types/report';
import { ERROR_PATTERN_MAP } from '@hellonext/shared/constants/error-patterns';
import { SWING_POSITION_MAP } from '@hellonext/shared/constants/swing-positions';
import { logger } from '@/lib/utils/logger';

interface ReportData {
  id: string;
  title: string;
  content: ReportContent;
  homework: string | null;
  error_tags: string[];
  status: 'draft' | 'published' | 'read';
  created_at: string;
  published_at: string | null;
  voice_memos?: {
    id: string;
    transcript: string | null;
    duration_sec: number;
  };
  pro_profiles?: {
    display_name: string;
    studio_name: string;
  };
  member_profiles?: {
    display_name: string;
  };
}

interface ReportViewerProps {
  report: ReportData;
  mode: 'pro' | 'member';
  onEdit?: (field: string, value: unknown) => void;
  onPublish?: () => void;
}

export function ReportViewer({ report, mode, onEdit, onPublish }: ReportViewerProps) {
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(['summary']));

  const toggleSection = useCallback((key: string) => {
    setExpandedSections((prev) => {
      const next = new Set(prev);
      if (next.has(key)) {
        next.delete(key);
      } else {
        next.add(key);
      }
      return next;
    });
  }, []);

  const isPro = mode === 'pro';

  return (
    <article className="space-y-4">
      {/* Report Header */}
      <header className="pb-4 border-b border-gray-100">
        <div className="flex items-center gap-2 mb-1">
          <StatusBadge status={report.status} />
          <span className="text-xs text-text-tertiary">
            {formatDate(report.created_at)}
          </span>
        </div>
        <h1 className="text-lg font-bold text-text-primary">{report.title}</h1>
        {report.member_profiles && (
          <p className="text-sm text-text-secondary mt-1">
            {report.member_profiles.display_name}님 레슨 리포트
          </p>
        )}
        {report.pro_profiles && mode === 'member' && (
          <p className="text-sm text-text-secondary mt-0.5">
            {report.pro_profiles.display_name} 프로 · {report.pro_profiles.studio_name}
          </p>
        )}
      </header>

      {/* Report Sections */}
      {report.content.sections?.map((section) => (
        <CollapsibleSection
          key={section.key}
          section={section}
          isExpanded={expandedSections.has(section.key)}
          onToggle={() => toggleSection(section.key)}
        />
      ))}

      {/* Error Pattern Tags */}
      {report.error_tags.length > 0 && (
        <section className="card p-4">
          <h3 className="text-sm font-semibold text-text-primary mb-3">감지된 에러 패턴</h3>
          <div className="flex flex-wrap gap-2">
            {report.error_tags.map((code) => {
              const pattern = ERROR_PATTERN_MAP[code];
              const position = pattern ? SWING_POSITION_MAP[pattern.position] : null;

              return (
                <div
                  key={code}
                  className="bg-status-error/10 text-status-error text-xs px-3 py-1.5 rounded-full"
                >
                  <span className="font-medium">{code}</span>
                  {pattern && (
                    <span className="ml-1 text-status-error/70">
                      {pattern.nameKo}
                      {position && ` (${position.nameKo})`}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Homework */}
      {report.homework && (
        <section className="card p-4 border-l-4 border-brand-primary">
          <h3 className="text-sm font-semibold text-text-primary mb-2">숙제</h3>
          <p className="text-sm text-text-secondary whitespace-pre-wrap">{report.homework}</p>
          {isPro && onEdit && (
            <button
              type="button"
              onClick={() => onEdit('homework', report.homework)}
              className="text-xs text-brand-primary mt-2"
            >
              수정
            </button>
          )}
        </section>
      )}

      {/* Transcript Reference */}
      {report.voice_memos?.transcript && (
        <TranscriptSection
          transcript={report.voice_memos.transcript}
          durationSec={report.voice_memos.duration_sec}
        />
      )}

      {/* Pro Actions */}
      {isPro && report.status === 'draft' && (
        <div className="flex gap-3 pt-4">
          <button
            type="button"
            onClick={onPublish}
            className="btn-primary flex-1 py-3 text-sm"
          >
            회원에게 전송
          </button>
        </div>
      )}
    </article>
  );
}

/* ---------- Sub-components ---------- */

function CollapsibleSection({
  section,
  isExpanded,
  onToggle,
}: {
  section: ReportSection;
  isExpanded: boolean;
  onToggle: () => void;
}) {
  const sectionIcons: Record<string, string> = {
    summary: '📝',
    error_analysis: '🔍',
    drill_recommendation: '🎯',
    progress: '📈',
    mental_note: '🧠',
  };

  return (
    <section className="card overflow-hidden">
      <button
        type="button"
        onClick={onToggle}
        className="w-full flex items-center justify-between p-4 text-left"
      >
        <div className="flex items-center gap-2">
          <span>{sectionIcons[section.key] ?? '📋'}</span>
          <h3 className="text-sm font-semibold text-text-primary">{section.title}</h3>
        </div>
        <svg
          className={cn('w-4 h-4 text-text-tertiary transition-transform', isExpanded && 'rotate-180')}
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth={2}
        >
          <polyline points="6,9 12,15 18,9" />
        </svg>
      </button>

      {isExpanded && (
        <div className="px-4 pb-4 animate-fade-in">
          <div className="text-sm text-text-secondary whitespace-pre-wrap leading-relaxed">
            {section.content}
          </div>
          {section.bullets && section.bullets.length > 0 && (
            <ul className="mt-3 space-y-1.5">
              {section.bullets.map((bullet, idx) => (
                <li key={idx} className="flex items-start gap-2 text-sm text-text-secondary">
                  <span className="text-brand-primary mt-0.5">•</span>
                  <span>{bullet}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </section>
  );
}

function TranscriptSection({
  transcript,
  durationSec,
}: {
  transcript: string;
  durationSec: number;
}) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <section className="card p-4">
      <button
        type="button"
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between text-left"
      >
        <div className="flex items-center gap-2">
          <span>🎙️</span>
          <h3 className="text-sm font-semibold text-text-primary">원본 녹음 텍스트</h3>
          <span className="text-xs text-text-tertiary">{formatDuration(durationSec)}</span>
        </div>
        <span className="text-xs text-brand-primary">
          {isExpanded ? '접기' : '펼치기'}
        </span>
      </button>

      {isExpanded && (
        <div className="mt-3 p-3 bg-gray-50 rounded-lg animate-fade-in">
          <p className="text-xs text-text-secondary whitespace-pre-wrap leading-relaxed font-mono">
            {transcript}
          </p>
        </div>
      )}
    </section>
  );
}

function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; className: string }> = {
    draft: { label: '초안', className: 'bg-gray-100 text-gray-600' },
    published: { label: '전송됨', className: 'bg-brand-primary/10 text-brand-primary' },
    read: { label: '읽음', className: 'bg-status-success/10 text-status-success' },
  };

  const { label, className } = config[status] ?? { label: status, className: 'bg-gray-100 text-gray-600' };

  return (
    <span className={cn('text-xs px-2 py-0.5 rounded-full font-medium', className)}>
      {label}
    </span>
  );
}
