/**
 * LoadingSpinner Component
 *
 * @module components/ui/loading-spinner
 */

'use client';

import { cn } from '@/lib/utils/cn';

interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  label?: string;
}

const sizeMap = {
  sm: 'w-4 h-4 border-2',
  md: 'w-8 h-8 border-2',
  lg: 'w-12 h-12 border-3',
};

export function LoadingSpinner({ size = 'md', className, label }: LoadingSpinnerProps) {
  return (
    <div className={cn('flex flex-col items-center gap-2', className)} role="status">
      <div
        className={cn(
          sizeMap[size],
          'rounded-full border-brand-primary/30 border-t-brand-primary animate-spin'
        )}
      />
      {label && <p className="text-sm text-text-secondary">{label}</p>}
      <span className="sr-only">{label ?? '로딩 중...'}</span>
    </div>
  );
}
