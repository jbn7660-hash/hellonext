/**
 * UI Store (Zustand)
 *
 * Global UI state management for tabs, modals, and navigation.
 *
 * @module stores/ui-store
 * @dependencies zustand
 * @exports useUIStore
 */

import { create } from 'zustand';

type ProTab = 'dashboard' | 'reports' | 'coupons' | 'settings';
type MemberTab = 'swingbook' | 'practice' | 'progress' | 'reports';

interface UIState {
  /** Current active tab for pro view */
  proActiveTab: ProTab;
  /** Current active tab for member view */
  memberActiveTab: MemberTab;
  /** Whether bottom sheet is visible */
  isBottomSheetOpen: boolean;
  /** Bottom sheet content identifier */
  bottomSheetContent: string | null;
  /** Whether any modal is visible */
  isModalOpen: boolean;
  /** Modal content identifier */
  modalContent: string | null;

  /** Actions */
  setProTab: (tab: ProTab) => void;
  setMemberTab: (tab: MemberTab) => void;
  openBottomSheet: (content: string) => void;
  closeBottomSheet: () => void;
  openModal: (content: string) => void;
  closeModal: () => void;
}

export const useUIStore = create<UIState>((set) => ({
  proActiveTab: 'dashboard',
  memberActiveTab: 'swingbook',
  isBottomSheetOpen: false,
  bottomSheetContent: null,
  isModalOpen: false,
  modalContent: null,

  setProTab: (tab) => set({ proActiveTab: tab }),
  setMemberTab: (tab) => set({ memberActiveTab: tab }),
  openBottomSheet: (content) =>
    set({ isBottomSheetOpen: true, bottomSheetContent: content }),
  closeBottomSheet: () =>
    set({ isBottomSheetOpen: false, bottomSheetContent: null }),
  openModal: (content) =>
    set({ isModalOpen: true, modalContent: content }),
  closeModal: () =>
    set({ isModalOpen: false, modalContent: null }),
}));
