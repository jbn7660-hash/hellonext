/**
 * Confidence State Classifier
 *
 * Classifies confidence scores into 3-tier states for UI display.
 * Maps confidence levels to user-facing labels and visual properties.
 *
 * Single Source of Truth: @hellonext/shared의 ConfidenceState, classifyConfidence를 사용.
 * 이 파일은 UI 표시 로직(label, color, icon)만 담당.
 *
 * @module lib/patent/state-classifier
 * @feature DC-2
 */

import {
  type ConfidenceState,
  CONFIDENCE_STATES,
  classifyConfidence,
} from '@hellonext/shared';

// Re-export for backward compatibility (이 파일을 import하는 consumer 유지)
export { type ConfidenceState, CONFIDENCE_STATES, classifyConfidence };

/**
 * Display properties for confidence state.
 */
export interface ConfidenceDisplayProps {
  label: string;
  color: string;
  icon: string;
}

/**
 * Get display properties for a confidence state.
 * Note: shared의 ConfidenceState 값은 'confirmed' | 'pending_verification' | 'hidden'
 *
 * @param state - Confidence state (from shared package)
 * @returns Display properties with label, color, and icon
 */
export function getConfidenceDisplayProps(state: ConfidenceState): ConfidenceDisplayProps {
  switch (state) {
    case 'confirmed':
      return {
        label: '확정',
        color: 'text-green-600',
        icon: '✓',
      };
    case 'pending_verification':
      return {
        label: '검토 필요',
        color: 'text-yellow-600',
        icon: '⚠',
      };
    case 'hidden':
      return {
        label: '숨김',
        color: 'text-gray-500',
        icon: '◯',
      };
  }
}

/**
 * Get background color class for confidence state.
 *
 * @param state - Confidence state
 * @returns Tailwind background color class
 */
export function getConfidenceBackgroundColor(state: ConfidenceState): string {
  switch (state) {
    case 'confirmed':
      return 'bg-green-50';
    case 'pending_verification':
      return 'bg-yellow-50';
    case 'hidden':
      return 'bg-gray-50';
  }
}

/**
 * Get border color class for confidence state.
 *
 * @param state - Confidence state
 * @returns Tailwind border color class
 */
export function getConfidenceBorderColor(state: ConfidenceState): string {
  switch (state) {
    case 'confirmed':
      return 'border-green-200';
    case 'pending_verification':
      return 'border-yellow-200';
    case 'hidden':
      return 'border-gray-200';
  }
}
