/**
 * Client-side Preliminary Confidence Calculator
 *
 * Implements DC-2: preliminary confidence calculation using 5-factor formula.
 * Final K-adjusted score comes from server after reviewing edit history.
 *
 * @module lib/patent/confidence-calculator
 * @feature DC-2
 */

/**
 * Calculate preliminary confidence score using 5-factor formula.
 * Range: [0, 1] where 1 is highest confidence.
 *
 * Score = V_c * (1 - P_a) * (1 - P_m) * (1 - P_o) * S_f
 *
 * @param keypointVisibility - Visibility score [0, 1]
 * @param cameraAngle - Camera angle in degrees
 * @param motionBlur - Motion blur score [0, 1]
 * @param occlusion - Occlusion score [0, 1]
 * @returns Preliminary confidence score [0, 1]
 */
export function calculatePreliminaryConfidence(
  keypointVisibility: number,
  cameraAngle: number,
  motionBlur: number,
  occlusion: number
): number {
  // Clamp inputs to valid ranges
  const Vc = Math.max(0, Math.min(1, keypointVisibility));
  const Pa = estimateCameraAnglePenalty(cameraAngle);
  const Pm = estimateMotionBlurPenalty(motionBlur);
  const Po = Math.max(0, Math.min(1, occlusion));
  const Sf = 1.0; // Sensor feedback factor (default to 1.0)

  const score = Vc * (1 - Pa) * (1 - Pm) * (1 - Po) * Sf;

  return Math.max(0, Math.min(1, score));
}

/**
 * Estimate camera angle penalty.
 * Maps angle deviation to penalty in [0, 1].
 *
 * Optimal angle is 0°. Penalty increases with deviation.
 * At 45°, penalty = 0.25. At 90°, penalty = 1.0.
 *
 * @param angle - Camera angle in degrees
 * @returns Penalty score [0, 1]
 */
export function estimateCameraAnglePenalty(angle: number): number {
  // Normalize angle to [0, 90]
  const normalizedAngle = Math.abs(angle) % 180;
  const deviationAngle = normalizedAngle > 90 ? 180 - normalizedAngle : normalizedAngle;

  // Linear penalty: penalty = angle / 90
  return Math.max(0, Math.min(1, deviationAngle / 90));
}

/**
 * Estimate motion blur penalty.
 * Maps blur score to penalty in [0, 1].
 *
 * Motion blur score typically comes from computer vision analysis.
 * Higher blur score → higher penalty.
 *
 * @param blurScore - Motion blur score [0, 1]
 * @returns Penalty score [0, 1]
 */
export function estimateMotionBlurPenalty(blurScore: number): number {
  // Clamp and apply quadratic scaling for sensitivity
  const clamped = Math.max(0, Math.min(1, blurScore));
  // Quadratic scaling makes the penalty more sensitive to higher blur
  return clamped * clamped;
}

/**
 * Get sensor feedback factor based on device capabilities.
 * Currently returns 1.0 (neutral). Can be extended for device-specific adjustments.
 *
 * @returns Sensor feedback factor [0, 1]
 */
export function getSensorFeedbackFactor(): number {
  return 1.0;
}
