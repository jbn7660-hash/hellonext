/**
 * TossPayments Client Library
 *
 * Wraps TossPayments SDK for:
 *  - One-time payments (coupon bundle purchase)
 *  - Billing key registration (Pro subscription)
 *  - Recurring billing execution
 *  - Payment confirmation (server-side)
 *
 * @module lib/payments/toss
 * @feature F-008
 * @see https://docs.tosspayments.com
 */

import { logger } from '@/lib/utils/logger';

// ─── Types ──────────────────────────────────────────────────────

export interface TossPaymentConfirmation {
  paymentKey: string;
  orderId: string;
  amount: number;
}

export interface TossPaymentResult {
  paymentKey: string;
  orderId: string;
  status: 'DONE' | 'CANCELED' | 'PARTIAL_CANCELED' | 'ABORTED' | 'EXPIRED';
  method: string;
  totalAmount: number;
  approvedAt: string;
  receipt?: { url: string };
}

export interface TossBillingKeyResult {
  billingKey: string;
  customerKey: string;
  method: string;
  card?: {
    issuerCode: string;
    number: string;
  };
}

export interface TossBillingPaymentResult {
  paymentKey: string;
  orderId: string;
  status: string;
  totalAmount: number;
  approvedAt: string;
}

// ─── Constants ──────────────────────────────────────────────────

const TOSS_API_URL = 'https://api.tosspayments.com/v1';

function getSecretKey(): string {
  const key = process.env.TOSS_PAYMENTS_SECRET_KEY;
  if (!key) throw new Error('Missing TOSS_PAYMENTS_SECRET_KEY');
  return key;
}

function getAuthHeader(): string {
  return `Basic ${Buffer.from(`${getSecretKey()}:`).toString('base64')}`;
}

// ─── One-time Payment Confirmation ──────────────────────────────

/**
 * Confirm a one-time payment (server-side).
 * Called after TossPayments client SDK completes on the frontend.
 */
export async function confirmPayment(
  params: TossPaymentConfirmation
): Promise<TossPaymentResult> {
  const res = await fetch(`${TOSS_API_URL}/payments/confirm`, {
    method: 'POST',
    headers: {
      Authorization: getAuthHeader(),
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(params),
  });

  if (!res.ok) {
    const error = await res.json().catch(() => ({}));
    logger.error('Toss payment confirm failed', { status: res.status, error });
    throw new TossPaymentError(
      error.code ?? 'CONFIRM_FAILED',
      error.message ?? '결제 승인에 실패했습니다.'
    );
  }

  return res.json();
}

// ─── Billing Key (Subscription) ─────────────────────────────────

/**
 * Issue a billing key from an auth key (after customer card registration).
 */
export async function issueBillingKey(
  authKey: string,
  customerKey: string
): Promise<TossBillingKeyResult> {
  const res = await fetch(`${TOSS_API_URL}/billing/authorizations/issue`, {
    method: 'POST',
    headers: {
      Authorization: getAuthHeader(),
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ authKey, customerKey }),
  });

  if (!res.ok) {
    const error = await res.json().catch(() => ({}));
    logger.error('Toss billing key issue failed', { error });
    throw new TossPaymentError(
      error.code ?? 'BILLING_KEY_FAILED',
      error.message ?? '카드 등록에 실패했습니다.'
    );
  }

  return res.json();
}

/**
 * Execute a recurring billing payment using a stored billing key.
 */
export async function executeBillingPayment(params: {
  billingKey: string;
  customerKey: string;
  amount: number;
  orderId: string;
  orderName: string;
}): Promise<TossBillingPaymentResult> {
  const res = await fetch(`${TOSS_API_URL}/billing/${params.billingKey}`, {
    method: 'POST',
    headers: {
      Authorization: getAuthHeader(),
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      customerKey: params.customerKey,
      amount: params.amount,
      orderId: params.orderId,
      orderName: params.orderName,
    }),
  });

  if (!res.ok) {
    const error = await res.json().catch(() => ({}));
    logger.error('Toss billing payment failed', { error });
    throw new TossPaymentError(
      error.code ?? 'BILLING_PAYMENT_FAILED',
      error.message ?? '정기결제에 실패했습니다.'
    );
  }

  return res.json();
}

// ─── Payment Cancellation ───────────────────────────────────────

export async function cancelPayment(
  paymentKey: string,
  cancelReason: string,
  cancelAmount?: number
): Promise<TossPaymentResult> {
  const body: Record<string, unknown> = { cancelReason };
  if (cancelAmount != null) body.cancelAmount = cancelAmount;

  const res = await fetch(`${TOSS_API_URL}/payments/${paymentKey}/cancel`, {
    method: 'POST',
    headers: {
      Authorization: getAuthHeader(),
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const error = await res.json().catch(() => ({}));
    logger.error('Toss cancel failed', { error });
    throw new TossPaymentError(
      error.code ?? 'CANCEL_FAILED',
      error.message ?? '결제 취소에 실패했습니다.'
    );
  }

  return res.json();
}

// ─── Error Class ────────────────────────────────────────────────

export class TossPaymentError extends Error {
  code: string;

  constructor(code: string, message: string) {
    super(message);
    this.name = 'TossPaymentError';
    this.code = code;
  }
}

// ─── Client-side Helper Constants ───────────────────────────────

export const TOSS_CLIENT_KEY = process.env.NEXT_PUBLIC_TOSS_PAYMENTS_CLIENT_KEY ?? '';

export const COUPON_BUNDLES = [
  { quantity: 5, price: 30000, perUnit: 6000, label: '5장 번들' },
  { quantity: 10, price: 50000, perUnit: 5000, label: '10장 번들', popular: true },
  { quantity: 30, price: 120000, perUnit: 4000, label: '30장 번들' },
] as const;

export const SUBSCRIPTION_PLANS = [
  { id: 'starter', name: 'Starter', price: 0, memberLimit: 5, features: ['회원 5명', 'PLG 쿠폰 3장'] },
  { id: 'pro', name: 'Pro', price: 19000, memberLimit: -1, features: ['회원 무제한', '우선 AI 분석', '고급 리포트'], popular: true },
  { id: 'academy', name: 'Academy', price: 149000, memberLimit: -1, features: ['전체 Pro 기능', '다중 프로 관리', '전용 대시보드', '우선 지원'] },
] as const;
