// 시스템 헬스체크 (v2.0)
// 데이터베이스, 인증, 특허 엔진, 실시간 통신 상태 확인

import { prisma } from '@/lib/prisma';

/**
 * 헬스 상태 인터페이스
 */
export interface HealthStatus {
  status: 'healthy' | 'degraded' | 'unhealthy';
  latency?: number; // 응답 시간 (ms)
  message?: string;
  lastChecked: string;
}

/**
 * 특허 엔진 헬스 상태
 */
export interface PatentEngineHealth {
  fsmController: HealthStatus;
  causalAnalysis: HealthStatus;
  measurementConfidence: HealthStatus;
  verificationHandler: HealthStatus;
  edgeWeightCalibration: HealthStatus;
}

/**
 * 전체 헬스체크 결과
 */
export interface HealthCheckResult {
  status: 'healthy' | 'degraded' | 'unhealthy';
  version: string;
  checks: {
    database: HealthStatus;
    auth: HealthStatus;
    patentEngine: PatentEngineHealth;
    realtime: HealthStatus;
  };
  timestamp: string;
  uptime: number; // 서버 업타임 (초)
  region?: string;
}

/**
 * 데이터베이스 헬스 확인
 * @returns HealthStatus
 */
export async function checkDatabase(): Promise<HealthStatus> {
  const startTime = Date.now();

  try {
    // 간단한 쿼리 실행
    await prisma.$queryRaw`SELECT 1`;

    const latency = Date.now() - startTime;

    return {
      status: latency < 100 ? 'healthy' : 'degraded',
      latency,
      lastChecked: new Date().toISOString(),
      message: latency < 100 ? 'Database connection healthy' : 'Database connection slow',
    };
  } catch (error) {
    return {
      status: 'unhealthy',
      latency: Date.now() - startTime,
      lastChecked: new Date().toISOString(),
      message: `Database connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
    };
  }
}

/**
 * 인증 서비스 헬스 확인
 * @returns HealthStatus
 */
export async function checkAuth(): Promise<HealthStatus> {
  const startTime = Date.now();

  try {
    // Auth 서비스 엔드포인트 확인
    const authEndpoint = process.env.NEXT_PUBLIC_AUTH_URL || 'http://localhost:3000/api/auth/health';
    const response = await fetch(authEndpoint, {
      method: 'GET',
      timeout: 5000,
    });

    const latency = Date.now() - startTime;

    if (response.ok) {
      return {
        status: latency < 100 ? 'healthy' : 'degraded',
        latency,
        lastChecked: new Date().toISOString(),
        message: 'Auth service healthy',
      };
    }

    return {
      status: 'degraded',
      latency,
      lastChecked: new Date().toISOString(),
      message: `Auth service returned ${response.status}`,
    };
  } catch (error) {
    return {
      status: 'unhealthy',
      latency: Date.now() - startTime,
      lastChecked: new Date().toISOString(),
      message: `Auth service check failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
    };
  }
}

/**
 * FSM 컨트롤러 헬스 확인
 * DC-5 (FSM 상태 전이) 무결성 검증
 */
export async function checkFsmController(): Promise<HealthStatus> {
  const startTime = Date.now();

  try {
    // FSM 상태 검증 엣지 함수 호출
    const response = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000'}/api/health/fsm-controller`,
      {
        method: 'GET',
        timeout: 3000,
      }
    );

    const latency = Date.now() - startTime;

    if (!response.ok) {
      return {
        status: 'unhealthy',
        latency,
        lastChecked: new Date().toISOString(),
        message: `FSM Controller returned ${response.status}`,
      };
    }

    const data = await response.json();

    return {
      status: data.healthy ? (latency < 200 ? 'healthy' : 'degraded') : 'unhealthy',
      latency,
      lastChecked: new Date().toISOString(),
      message: data.message || 'FSM Controller healthy',
    };
  } catch (error) {
    return {
      status: 'unhealthy',
      latency: Date.now() - startTime,
      lastChecked: new Date().toISOString(),
      message: `FSM Controller check failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
    };
  }
}

/**
 * 인과 분석 (Causal Analysis) 헬스 확인
 * DC-1 (인과 그래프 무결성) 검증
 */
export async function checkCausalAnalysis(): Promise<HealthStatus> {
  const startTime = Date.now();

  try {
    // IIS (Importance Impact Score) 계산 테스트
    const response = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000'}/api/health/causal-analysis`,
      {
        method: 'GET',
        timeout: 5000, // F-015 제약: IIS 계산은 5초 이내
      }
    );

    const latency = Date.now() - startTime;

    if (!response.ok) {
      return {
        status: 'unhealthy',
        latency,
        lastChecked: new Date().toISOString(),
        message: `Causal Analysis returned ${response.status}`,
      };
    }

    const data = await response.json();

    // F-015 위반 확인: IIS 계산이 5초를 초과한 경우
    const status = latency > 5000 ? 'unhealthy' : latency > 2000 ? 'degraded' : 'healthy';

    return {
      status,
      latency,
      lastChecked: new Date().toISOString(),
      message: data.message || 'Causal Analysis healthy',
    };
  } catch (error) {
    return {
      status: 'unhealthy',
      latency: Date.now() - startTime,
      lastChecked: new Date().toISOString(),
      message: `Causal Analysis check failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
    };
  }
}

/**
 * 측정 신뢰도 (Measurement Confidence) 헬스 확인
 * DC-2 (신뢰도 계산) 무결성 검증
 */
export async function checkMeasurementConfidence(): Promise<HealthStatus> {
  const startTime = Date.now();

  try {
    const response = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000'}/api/health/measurement-confidence`,
      {
        method: 'GET',
        timeout: 3000,
      }
    );

    const latency = Date.now() - startTime;

    if (!response.ok) {
      return {
        status: 'unhealthy',
        latency,
        lastChecked: new Date().toISOString(),
        message: `Measurement Confidence returned ${response.status}`,
      };
    }

    const data = await response.json();

    return {
      status: data.healthy ? (latency < 200 ? 'healthy' : 'degraded') : 'unhealthy',
      latency,
      lastChecked: new Date().toISOString(),
      message: data.message || 'Measurement Confidence healthy',
    };
  } catch (error) {
    return {
      status: 'unhealthy',
      latency: Date.now() - startTime,
      lastChecked: new Date().toISOString(),
      message: `Measurement Confidence check failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
    };
  }
}

/**
 * 검증 핸들러 (Verification Handler) 헬스 확인
 * F-016 제약: 검증 큐 지연 (>24시간) 확인
 */
export async function checkVerificationHandler(): Promise<HealthStatus> {
  const startTime = Date.now();

  try {
    const response = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000'}/api/health/verification-handler`,
      {
        method: 'GET',
        timeout: 3000,
      }
    );

    const latency = Date.now() - startTime;

    if (!response.ok) {
      return {
        status: 'unhealthy',
        latency,
        lastChecked: new Date().toISOString(),
        message: `Verification Handler returned ${response.status}`,
      };
    }

    const data = await response.json();

    // F-016: 검증 큐에 24시간 이상 대기 중인 항목 확인
    const queueStatus = data.oldestQueueItemAge > 86400000 ? 'degraded' : 'healthy';

    return {
      status: data.healthy && queueStatus === 'healthy' ? 'healthy' : data.healthy ? 'degraded' : 'unhealthy',
      latency,
      lastChecked: new Date().toISOString(),
      message: data.message || 'Verification Handler healthy',
    };
  } catch (error) {
    return {
      status: 'unhealthy',
      latency: Date.now() - startTime,
      lastChecked: new Date().toISOString(),
      message: `Verification Handler check failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
    };
  }
}

/**
 * 엣지 가중치 교정 (Edge Weight Calibration) 헬스 확인
 * DC-4 (엣지 가중치 계산) 무결성 검증
 */
export async function checkEdgeWeightCalibration(): Promise<HealthStatus> {
  const startTime = Date.now();

  try {
    const response = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000'}/api/health/edge-weight-calibration`,
      {
        method: 'GET',
        timeout: 3000,
      }
    );

    const latency = Date.now() - startTime;

    if (!response.ok) {
      return {
        status: 'unhealthy',
        latency,
        lastChecked: new Date().toISOString(),
        message: `Edge Weight Calibration returned ${response.status}`,
      };
    }

    const data = await response.json();

    return {
      status: data.healthy ? (latency < 200 ? 'healthy' : 'degraded') : 'unhealthy',
      latency,
      lastChecked: new Date().toISOString(),
      message: data.message || 'Edge Weight Calibration healthy',
    };
  } catch (error) {
    return {
      status: 'unhealthy',
      latency: Date.now() - startTime,
      lastChecked: new Date().toISOString(),
      message: `Edge Weight Calibration check failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
    };
  }
}

/**
 * 실시간 통신 (WebSocket/Realtime) 헬스 확인
 */
export async function checkRealtime(): Promise<HealthStatus> {
  const startTime = Date.now();

  try {
    const realtimeUrl = process.env.NEXT_PUBLIC_REALTIME_URL || 'ws://localhost:3000/ws/health';

    // WebSocket 헬스 체크는 일반적으로 별도 엔드포인트 사용
    const response = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000'}/api/health/realtime`,
      {
        method: 'GET',
        timeout: 3000,
      }
    );

    const latency = Date.now() - startTime;

    if (!response.ok) {
      return {
        status: 'degraded',
        latency,
        lastChecked: new Date().toISOString(),
        message: `Realtime service returned ${response.status}`,
      };
    }

    const data = await response.json();

    return {
      status: data.healthy ? (latency < 100 ? 'healthy' : 'degraded') : 'degraded',
      latency,
      lastChecked: new Date().toISOString(),
      message: data.message || 'Realtime service healthy',
    };
  } catch (error) {
    // Realtime 장애는 심각도를 degraded로 제한 (완전 서비스 중단 아님)
    return {
      status: 'degraded',
      latency: Date.now() - startTime,
      lastChecked: new Date().toISOString(),
      message: `Realtime check failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
    };
  }
}

/**
 * 모든 특허 엔진 컴포넌트 헬스 확인
 */
export async function checkPatentEngineHealth(): Promise<PatentEngineHealth> {
  const [
    fsmController,
    causalAnalysis,
    measurementConfidence,
    verificationHandler,
    edgeWeightCalibration,
  ] = await Promise.all([
    checkFsmController(),
    checkCausalAnalysis(),
    checkMeasurementConfidence(),
    checkVerificationHandler(),
    checkEdgeWeightCalibration(),
  ]);

  return {
    fsmController,
    causalAnalysis,
    measurementConfidence,
    verificationHandler,
    edgeWeightCalibration,
  };
}

/**
 * 전체 헬스체크 실행
 */
export async function performHealthCheck(): Promise<HealthCheckResult> {
  const startTime = Date.now();

  const [
    database,
    auth,
    patentEngine,
    realtime,
  ] = await Promise.all([
    checkDatabase(),
    checkAuth(),
    checkPatentEngineHealth(),
    checkRealtime(),
  ]);

  // 전체 상태 결정 로직
  const allStatuses = [
    database.status,
    auth.status,
    patentEngine.fsmController.status,
    patentEngine.causalAnalysis.status,
    patentEngine.measurementConfidence.status,
    patentEngine.verificationHandler.status,
    patentEngine.edgeWeightCalibration.status,
    realtime.status,
  ];

  let overallStatus: 'healthy' | 'degraded' | 'unhealthy' = 'healthy';

  if (allStatuses.includes('unhealthy')) {
    // 특허 엔진 컴포넌트가 unhealthy면 전체 unhealthy
    const patentEngineStatuses = [
      patentEngine.fsmController.status,
      patentEngine.causalAnalysis.status,
      patentEngine.measurementConfidence.status,
      patentEngine.verificationHandler.status,
      patentEngine.edgeWeightCalibration.status,
    ];

    if (patentEngineStatuses.some(s => s === 'unhealthy')) {
      overallStatus = 'unhealthy';
    }

    // 데이터베이스가 unhealthy면 전체 unhealthy
    if (database.status === 'unhealthy') {
      overallStatus = 'unhealthy';
    }
  } else if (allStatuses.includes('degraded')) {
    overallStatus = 'degraded';
  }

  return {
    status: overallStatus,
    version: process.env.NEXT_PUBLIC_APP_VERSION || '2.0.0',
    checks: {
      database,
      auth,
      patentEngine,
      realtime,
    },
    timestamp: new Date().toISOString(),
    uptime: Math.floor(process.uptime()),
    region: process.env.NEXT_PUBLIC_REGION || 'us-east-1',
  };
}

export default {
  performHealthCheck,
  checkDatabase,
  checkAuth,
  checkPatentEngineHealth,
  checkFsmController,
  checkCausalAnalysis,
  checkMeasurementConfidence,
  checkVerificationHandler,
  checkEdgeWeightCalibration,
  checkRealtime,
};
