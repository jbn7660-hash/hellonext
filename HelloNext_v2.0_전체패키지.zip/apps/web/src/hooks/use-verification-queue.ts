/**
 * useVerificationQueue Hook
 *
 * Manages the professional verification queue for measurements.
 * Subscribes to Realtime for new pending verifications and provides
 * methods to submit verification responses.
 *
 * @module hooks/use-verification-queue
 * @feature F-016
 */

'use client';

import { useState, useEffect, useCallback } from 'react';
import { createClient } from '@/lib/supabase/client';
import { logger } from '@/lib/utils/logger';
import type {
  VerificationQueueEntry as DbVerificationQueueEntry,
  VerificationResponse as DbVerificationResponse,
} from '@hellonext/shared';

// Re-export DB 타입 (참조용)
export type { DbVerificationQueueEntry, DbVerificationResponse };

/**
 * 클라이언트 측 검증 큐 항목 (DB row → UI 친화적 변환).
 * DB 스키마: shared/types/verification.ts의 VerificationQueueEntry
 */
export interface VerificationQueueEntry {
  id: string;
  sessionId: string;
  measurementId: string;
  measurementType: string;
  confidenceScore: number;
  predictedValue: number;
  unit: string;
  capturedAt: string;
}

/**
 * Verification response type (shared와 동일한 string union).
 */
export type VerificationResponse = 'confirm' | 'correct' | 'reject';

/**
 * Hook state.
 */
export interface UseVerificationQueueState {
  items: VerificationQueueEntry[];
  pendingCount: number;
  loading: boolean;
  error: string | null;
}

/**
 * Hook actions.
 */
export interface UseVerificationQueueActions {
  submitVerification: (
    token: string,
    responseType: VerificationResponse,
    correctedValue?: number
  ) => Promise<void>;
  refresh: () => Promise<void>;
}

/**
 * useVerificationQueue hook.
 * Subscribes to verification queue updates and provides verification submission.
 *
 * @returns Hook state and actions
 */
export function useVerificationQueue(): UseVerificationQueueState & UseVerificationQueueActions {
  const [items, setItems] = useState<VerificationQueueEntry[]>([]);
  const [pendingCount, setPendingCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const supabase = createClient();

  // Fetch initial verification queue
  const refresh = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase
        .from('verification_queue')
        .select('*')
        .eq('status', 'pending')
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;

      const entries = (data || []).map((item: any) => ({
        id: item.id,
        sessionId: item.session_id,
        measurementId: item.measurement_id,
        measurementType: item.measurement_type,
        confidenceScore: item.confidence_score,
        predictedValue: item.predicted_value,
        unit: item.unit,
        capturedAt: item.created_at,
      }));

      setItems(entries);
      setPendingCount(entries.length);

      logger.info('Verification queue refreshed', { count: entries.length });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to load verification queue';
      setError(message);
      logger.error('Failed to load verification queue', { error: err });
    } finally {
      setLoading(false);
    }
  }, [supabase]);

  // Subscribe to Realtime updates
  useEffect(() => {
    refresh();

    const channel = supabase
      .channel('verification_queue_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'verification_queue',
        },
        (payload) => {
          logger.info('Verification queue update received', { payload });
          refresh();
        }
      )
      .subscribe();

    return () => {
      channel.unsubscribe();
    };
  }, [supabase, refresh]);

  // Submit verification response
  const submitVerification = useCallback(
    async (token: string, responseType: VerificationResponse, correctedValue?: number) => {
      try {
        setError(null);

        const { error: submitError } = await supabase.functions.invoke(
          'verification-handler',
          {
            body: {
              token,
              responseType,
              correctedValue,
            },
          }
        );

        if (submitError) throw submitError;

        logger.info('Verification submitted', { responseType });

        // Refresh queue after submission
        await refresh();
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Failed to submit verification';
        setError(message);
        logger.error('Failed to submit verification', { error: err });
        throw err;
      }
    },
    [supabase, refresh]
  );

  return {
    items,
    pendingCount,
    loading,
    error,
    submitVerification,
    refresh,
  };
}
