/**
 * useCausalGraph Hook
 *
 * Manages causal graph visualization and analysis for error pattern relationships.
 * Provides causal graph data, IIS scores, and primary fix recommendation.
 *
 * @module hooks/use-causal-graph
 * @feature F-015
 */

'use client';

import { useState, useEffect, useCallback } from 'react';
import { createClient } from '@/lib/supabase/client';
import { logger } from '@/lib/utils/logger';

/**
 * Causal graph node representing an error pattern.
 */
export interface CausalGraphNode {
  id: string;
  label: string;
  errorPattern: string;
  iisScore: number;
}

/**
 * Causal graph edge representing causal relationship.
 */
export interface CausalGraphEdge {
  source: string;
  target: string;
  weight: number; // Causal strength [0, 1]
}

/**
 * Primary fix recommendation.
 */
export interface PrimaryFix {
  nodeId: string;
  errorPattern: string;
  iisScore: number;
  rationale: string;
}

/**
 * Hook state.
 */
export interface UseCausalGraphState {
  nodes: CausalGraphNode[];
  edges: CausalGraphEdge[];
  primaryFix: PrimaryFix | null;
  iisScores: Record<string, number>;
  loading: boolean;
  error: string | null;
}

/**
 * Hook actions.
 */
export interface UseCausalGraphActions {
  triggerAnalysis: (sessionId: string) => Promise<void>;
  refresh: () => Promise<void>;
}

/**
 * useCausalGraph hook.
 * Loads causal graph data for error pattern analysis.
 *
 * @param sessionId - Optional session ID to initialize with
 * @returns Hook state and actions
 */
export function useCausalGraph(sessionId?: string): UseCausalGraphState & UseCausalGraphActions {
  const [nodes, setNodes] = useState<CausalGraphNode[]>([]);
  const [edges, setEdges] = useState<CausalGraphEdge[]>([]);
  const [primaryFix, setPrimaryFix] = useState<PrimaryFix | null>(null);
  const [iisScores, setIisScores] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const supabase = createClient();

  // Fetch causal graph data
  const refresh = useCallback(async (targetSessionId?: string) => {
    if (!targetSessionId && !sessionId) {
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const sId = targetSessionId || sessionId;

      const { data, error: fetchError } = await supabase
        .from('causal_graphs')
        .select('*')
        .eq('session_id', sId)
        .single();

      if (fetchError) throw fetchError;

      if (!data) {
        setNodes([]);
        setEdges([]);
        setPrimaryFix(null);
        return;
      }

      // Parse graph data
      const graphNodes = (data.nodes || []).map((node: any) => ({
        id: node.id,
        label: node.label,
        errorPattern: node.error_pattern,
        iisScore: node.iis_score,
      }));

      const graphEdges = (data.edges || []).map((edge: any) => ({
        source: edge.source,
        target: edge.target,
        weight: edge.weight,
      }));

      const scores: Record<string, number> = {};
      graphNodes.forEach((node: CausalGraphNode) => {
        scores[node.id] = node.iisScore;
      });

      // Find primary fix (highest IIS score)
      const primaryNode = graphNodes.reduce(
        (max: CausalGraphNode | null, node: CausalGraphNode) =>
          !max || node.iisScore > max.iisScore ? node : max,
        null
      );

      setNodes(graphNodes);
      setEdges(graphEdges);
      setIisScores(scores);

      if (primaryNode) {
        setPrimaryFix({
          nodeId: primaryNode.id,
          errorPattern: primaryNode.errorPattern,
          iisScore: primaryNode.iisScore,
          rationale: data.primary_fix_rationale || '',
        });
      }

      logger.info('Causal graph loaded', { nodeCount: graphNodes.length, edgeCount: graphEdges.length });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to load causal graph';
      setError(message);
      logger.error('Failed to load causal graph', { error: err });
    } finally {
      setLoading(false);
    }
  }, [supabase, sessionId]);

  // Load on mount
  useEffect(() => {
    if (sessionId) {
      refresh();
    }
  }, [sessionId, refresh]);

  // Trigger full analysis
  const triggerAnalysis = useCallback(
    async (targetSessionId: string) => {
      try {
        setLoading(true);
        setError(null);

        const { error: invokeError } = await supabase.functions.invoke('causal-analysis', {
          body: {
            sessionId: targetSessionId,
          },
        });

        if (invokeError) throw invokeError;

        logger.info('Causal analysis triggered', { sessionId: targetSessionId });

        // Refresh after analysis completes
        await new Promise((resolve) => setTimeout(resolve, 2000)); // Wait for processing
        await refresh(targetSessionId);
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Failed to trigger analysis';
        setError(message);
        logger.error('Failed to trigger causal analysis', { error: err });
        throw err;
      }
    },
    [supabase, refresh]
  );

  return {
    nodes,
    edges,
    primaryFix,
    iisScores,
    loading,
    error,
    triggerAnalysis,
    refresh,
  };
}
