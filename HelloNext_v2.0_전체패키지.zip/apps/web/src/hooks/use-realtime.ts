/**
 * useRealtime Hook
 *
 * Subscribes to Supabase Realtime channels for live updates.
 * Used for report pipeline status and notification delivery.
 *
 * @module hooks/use-realtime
 * @feature F-001, F-014
 */

'use client';

import { useEffect, useRef, useCallback } from 'react';
import { createClient } from '@/lib/supabase/client';
import { logger } from '@/lib/utils/logger';
import type { RealtimeChannel } from '@supabase/supabase-js';

interface RealtimeEvent<T = Record<string, unknown>> {
  event: string;
  payload: T;
}

/**
 * Subscribe to a Supabase Realtime broadcast channel.
 */
export function useRealtimeBroadcast<T = Record<string, unknown>>(
  channelName: string,
  eventName: string,
  onEvent: (payload: T) => void,
  enabled: boolean = true
) {
  const channelRef = useRef<RealtimeChannel | null>(null);
  const callbackRef = useRef(onEvent);
  callbackRef.current = onEvent;

  useEffect(() => {
    if (!enabled) return;

    const supabase = createClient();
    const channel = supabase.channel(channelName);

    channel
      .on('broadcast', { event: eventName }, (message: RealtimeEvent<T>) => {
        logger.debug('Realtime broadcast received', {
          channel: channelName,
          event: eventName,
        });
        callbackRef.current(message.payload);
      })
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          logger.info('Realtime channel subscribed', { channel: channelName });
        }
      });

    channelRef.current = channel;

    return () => {
      channel.unsubscribe();
      channelRef.current = null;
    };
  }, [channelName, eventName, enabled]);
}

/**
 * Subscribe to Supabase Realtime Postgres Changes on a table.
 */
export function useRealtimeTable<T = Record<string, unknown>>(
  table: string,
  event: 'INSERT' | 'UPDATE' | 'DELETE' | '*',
  filter: string | undefined,
  onEvent: (payload: { new: T; old: T; eventType: string }) => void,
  enabled: boolean = true
) {
  const callbackRef = useRef(onEvent);
  callbackRef.current = onEvent;

  useEffect(() => {
    if (!enabled) return;

    const supabase = createClient();
    const channelName = `table-${table}-${event}-${filter ?? 'all'}`;

    type PostgresPayload = {
      new: T;
      old: T;
      eventType: string;
    };

    const channel = supabase
      .channel(channelName)
      .on(
        'postgres_changes' as 'system',
        {
          event,
          schema: 'public',
          table,
          ...(filter ? { filter } : {}),
        } as Record<string, string>,
        (payload: PostgresPayload) => {
          callbackRef.current({
            new: payload.new,
            old: payload.old,
            eventType: payload.eventType,
          });
        }
      )
      .subscribe();

    return () => {
      channel.unsubscribe();
    };
  }, [table, event, filter, enabled]);
}

/**
 * Subscribe to report pipeline updates for the current pro.
 */
export function useReportPipelineUpdates(
  onReportReady: (data: { memo_id: string; report_id: string | null; status: string }) => void
) {
  return useRealtimeBroadcast(
    'report-updates',
    'report_ready',
    onReportReady
  );
}
