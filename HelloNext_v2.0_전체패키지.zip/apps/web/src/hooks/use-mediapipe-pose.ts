/**
 * useMediaPipePose — Client-side 2D Pose Estimation Hook
 *
 * Wraps MediaPipe Pose (via @mediapipe/tasks-vision) for real-time
 * skeletal tracking during swing video recording.
 *
 * Limitations (2D only):
 *  - No X-Factor or hip rotation precision
 *  - Accuracy degrades with poor lighting or partial body visibility
 *
 * @module hooks/use-mediapipe-pose
 * @feature F-005
 */

'use client';

import { useState, useRef, useCallback, useEffect } from 'react';
import { logger } from '@/lib/utils/logger';

interface Keypoint {
  name: string;
  x: number;
  y: number;
  score: number;
}

interface PoseFrame {
  frame_index: number;
  timestamp_ms: number;
  keypoints: Keypoint[];
}

interface UsePoseResult {
  isModelLoaded: boolean;
  isProcessing: boolean;
  frames: PoseFrame[];
  error: string | null;
  initModel: () => Promise<void>;
  processVideoFrame: (video: HTMLVideoElement, frameIndex: number, timestampMs: number) => void;
  resetFrames: () => void;
}

// MediaPipe landmark names mapped to our keypoint naming convention
const LANDMARK_NAMES = [
  'nose', 'left_eye_inner', 'left_eye', 'left_eye_outer',
  'right_eye_inner', 'right_eye', 'right_eye_outer',
  'left_ear', 'right_ear', 'mouth_left', 'mouth_right',
  'left_shoulder', 'right_shoulder', 'left_elbow', 'right_elbow',
  'left_wrist', 'right_wrist', 'left_pinky', 'right_pinky',
  'left_index', 'right_index', 'left_thumb', 'right_thumb',
  'left_hip', 'right_hip', 'left_knee', 'right_knee',
  'left_ankle', 'right_ankle', 'left_heel', 'right_heel',
  'left_foot_index', 'right_foot_index',
] as const;

// Keypoints essential for golf swing analysis
const GOLF_KEYPOINTS = new Set([
  'nose', 'left_shoulder', 'right_shoulder',
  'left_elbow', 'right_elbow', 'left_wrist', 'right_wrist',
  'left_hip', 'right_hip', 'left_knee', 'right_knee',
  'left_ankle', 'right_ankle',
]);

export function useMediaPipePose(): UsePoseResult {
  const [isModelLoaded, setIsModelLoaded] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [frames, setFrames] = useState<PoseFrame[]>([]);
  const [error, setError] = useState<string | null>(null);

  const poseLandmarkerRef = useRef<unknown>(null);
  const canvasRef = useRef<OffscreenCanvas | null>(null);

  const initModel = useCallback(async () => {
    try {
      setError(null);

      // Dynamically import MediaPipe Tasks Vision
      const vision = await import('@mediapipe/tasks-vision');
      const { PoseLandmarker, FilesetResolver } = vision;

      const wasmFileset = await FilesetResolver.forVisionTasks(
        'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@latest/wasm'
      );

      const landmarker = await PoseLandmarker.createFromOptions(wasmFileset, {
        baseOptions: {
          modelAssetPath:
            'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task',
          delegate: 'GPU',
        },
        runningMode: 'VIDEO',
        numPoses: 1,
        minPoseDetectionConfidence: 0.5,
        minPosePresenceConfidence: 0.5,
        minTrackingConfidence: 0.5,
      });

      poseLandmarkerRef.current = landmarker;
      canvasRef.current = new OffscreenCanvas(640, 480);
      setIsModelLoaded(true);

      logger.info('MediaPipe Pose model loaded');
    } catch (err) {
      const message = err instanceof Error ? err.message : 'MediaPipe 모델 로딩 실패';
      setError(message);
      logger.error('MediaPipe init failed', { error: err });
    }
  }, []);

  const processVideoFrame = useCallback(
    (video: HTMLVideoElement, frameIndex: number, timestampMs: number) => {
      const landmarker = poseLandmarkerRef.current as {
        detectForVideo: (
          video: HTMLVideoElement,
          timestamp: number
        ) => { landmarks: { x: number; y: number; z: number; visibility: number }[][] };
      } | null;

      if (!landmarker) return;

      try {
        setIsProcessing(true);
        const result = landmarker.detectForVideo(video, timestampMs);

        if (result.landmarks && result.landmarks.length > 0) {
          const landmarks = result.landmarks[0]!;

          const keypoints: Keypoint[] = landmarks
            .map((lm, idx) => ({
              name: LANDMARK_NAMES[idx] ?? `point_${idx}`,
              x: lm.x,
              y: lm.y,
              score: lm.visibility ?? 0,
            }))
            .filter((kp) => GOLF_KEYPOINTS.has(kp.name));

          // Validate: need minimum keypoints for analysis
          const highConfidence = keypoints.filter((kp) => kp.score > 0.5);
          if (highConfidence.length < 8) {
            // Not enough body visible — skip frame but don't error
            return;
          }

          const frame: PoseFrame = {
            frame_index: frameIndex,
            timestamp_ms: timestampMs,
            keypoints,
          };

          setFrames((prev) => [...prev, frame]);
        }
      } catch (err) {
        logger.error('Pose detection frame error', { frameIndex, error: err });
      } finally {
        setIsProcessing(false);
      }
    },
    []
  );

  const resetFrames = useCallback(() => {
    setFrames([]);
  }, []);

  // Cleanup
  useEffect(() => {
    return () => {
      const landmarker = poseLandmarkerRef.current as { close?: () => void } | null;
      if (landmarker?.close) {
        landmarker.close();
      }
    };
  }, []);

  return {
    isModelLoaded,
    isProcessing,
    frames,
    error,
    initModel,
    processVideoFrame,
    resetFrames,
  };
}
