/**
 * Sentry 클라이언트 설정 (v2.0 Patent Engine 모니터링)
 * 성능 모니터링, 세션 리플레이, 커스텀 태그
 *
 * @sentry/nextjs에 의해 자동으로 로드됨
 */

import * as Sentry from '@sentry/nextjs';

Sentry.init({
  // DSN 설정
  dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,
  enabled: process.env.NODE_ENV === 'production',
  environment: process.env.NODE_ENV,

  // 버전 설정
  release: process.env.NEXT_PUBLIC_APP_VERSION || '2.0.0',

  // 성능 모니터링 샘플링
  tracesSampleRate: process.env.NODE_ENV === 'production' ? 0.1 : 1.0,

  // 세션 리플레이 샘플링
  replaysSessionSampleRate: process.env.NODE_ENV === 'production' ? 0.1 : 1.0,
  replaysOnErrorSampleRate: 1.0,

  // 통합 설정
  integrations: [
    // 성능 모니터링 및 세션 리플레이
    Sentry.replayIntegration({
      maskAllText: true,
      blockAllMedia: true,
      maskAllInputs: true,
    }),

    // 콘솔 로그 캡처
    new Sentry.CaptureConsole({
      levels: ['error', 'warn'],
    }),

    // 사용자 인터랙션 모니터링
    new Sentry.Breadcrumbs({
      click: true,
      scroll: false,
      navigation: true,
    }),
  ],

  // 초기 에러 핸들러 설정
  beforeSend(event, hint) {
    // 민감한 정보 제거
    if (event.request?.cookies) {
      event.request.cookies = {};
    }

    // ResizeObserver 에러는 무시
    if (hint.originalException instanceof TypeError) {
      const typeError = hint.originalException as TypeError;
      if (typeError.message?.includes('ResizeObserver')) {
        return null;
      }
    }

    // 특허 엔진 관련 에러에 태그 추가
    if (event.message?.includes('patent') || event.tags?.['source'] === 'patent-engine') {
      event.level = 'error';
      event.tags = {
        ...event.tags,
        'source': 'patent-engine',
      };
    }

    return event;
  },

  // Breadcrumb 필터
  beforeBreadcrumb(breadcrumb, hint) {
    // 민감한 정보 필터링
    if (breadcrumb.category === 'console' && breadcrumb.level === 'debug') {
      return null;
    }

    // 특허 엔진 breadcrumb은 유지
    if (breadcrumb.message?.includes('patent')) {
      breadcrumb.category = 'patent-engine';
    }

    return breadcrumb;
  },

  // 에러 필터링 - 브라우저 확장 프로그램 에러 무시
  denyUrls: [
    /extensions\//i,
    /^chrome:\/\//i,
  ],

  // 허용된 URL 패턴
  allowUrls: [
    /https?:\/\/(?:www\.)?arcup\.local/,
    /https?:\/\/(?:www\.)?hellonext\.io/,
    /https?:\/\/(?:www\.)?arcup\.dev/,
  ],

  // 성능 모니터링 옵션
  tracingOptions: {
    tracingOrigins: [
      'localhost',
      'arcup.local',
      'arcup.dev',
      'hellonext.io',
      /^\//,
    ],
  },
});
