/**
 * Sentry 서버 설정 (v2.0 Patent Engine 모니터링)
 * API 라우트 모니터링, 데이터베이스 쿼리 성능, Patent Edge Function 추적
 *
 * @sentry/nextjs에 의해 자동으로 로드됨
 */

import * as Sentry from '@sentry/nextjs';

Sentry.init({
  // DSN 설정
  dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,
  enabled: process.env.NODE_ENV === 'production',
  environment: process.env.NODE_ENV,

  // 버전 설정
  release: process.env.NEXT_PUBLIC_APP_VERSION || '2.0.0',

  // 성능 모니터링 샘플링 (서버는 클라이언트보다 높음)
  tracesSampleRate: process.env.NODE_ENV === 'production' ? 0.2 : 1.0,

  // 서버사이드 통합
  integrations: [
    // HTTP 요청 모니터링
    new Sentry.RequestDataIntegration({
      include: {
        cookies: false,
        headers: true,
        query_string: true,
        url: true,
      },
    }),

    // 성능 프로파일링
    new Sentry.Profiler(),
  ],

  // 민감한 정보 제거
  beforeSend(event) {
    // 민감한 헤더 제거
    if (event.request?.headers) {
      delete event.request.headers['authorization'];
      delete event.request.headers['cookie'];
      delete event.request.headers['x-api-key'];
    }

    // 특허 엔진 API 요청에 태그 추가
    if (event.request?.url?.includes('/api/patents') || event.request?.url?.includes('/patent-engine')) {
      event.tags = {
        ...event.tags,
        'patent.engine': 'api-route',
      };
    }

    // Edge Function 요청에 태그 추가
    if (event.request?.url?.includes('/edge/') || event.request?.url?.includes('/.vercel/functions')) {
      event.tags = {
        ...event.tags,
        'patent.engine': 'edge-function',
        'serverless.runtime': 'edge',
      };
    }

    return event;
  },

  // Breadcrumb 필터
  beforeBreadcrumb(breadcrumb) {
    // 데이터베이스 쿼리 정보 추적
    if (breadcrumb.category === 'db.query') {
      breadcrumb.category = 'database';
      breadcrumb.data = {
        ...breadcrumb.data,
        'patent.engine': 'database',
      };
    }

    return breadcrumb;
  },

  // 성능 모니터링 옵션
  tracingOptions: {
    tracingOrigins: [
      'localhost',
      'arcup.local',
      'arcup.dev',
      /^\//,
    ],
  },

  // 데이터베이스 모니터링
  attachStacktrace: true,
  maxBreadcrumbs: 50,

  // 프로파일링 샘플링 (성능 오버헤드 방지)
  profilesSampleRate: process.env.NODE_ENV === 'production' ? 0.1 : 0.5,
});
