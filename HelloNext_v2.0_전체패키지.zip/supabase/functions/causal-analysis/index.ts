/**
 * Causal Analysis Engine Edge Function
 *
 * Implements the causal graph engine for symptom analysis and primary fix identification.
 *
 * Per Patent 1 Claim 1(e): Builds Layer A (raw measurements) → Layer B (derived metrics)
 * dependency model, runs reverse traversal through DAG, and computes IIS to select
 * Primary Fix as a scalar value per DC-4.
 *
 * @edge-function causal-analysis
 * @feature F-015
 * @patent Patent 1 Claim 1(e)
 * @dependencies Supabase client
 */

import { serve } from 'https://deno.land/std@0.208.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.0';

// ─── Types ───────────────────────────────────────────────────────

interface RawMeasurement {
  id: string;
  member_id: string;
  swing_id: string;
  metric_name: string;
  value: number;
  timestamp: string;
}

interface DerivedMetric {
  id: string;
  member_id: string;
  swing_id: string;
  metric_name: string;
  value: number;
  dependencies: string[];
  timestamp: string;
}

interface CausalGraphEdge {
  id: string;
  source: string;
  target: string;
  weight: number;
  tier: number;
}

interface CandidateFix {
  fix_id: string;
  name: string;
  iis_score: number;
  path_length: number;
}

interface CausalAnalysisRequest {
  operation: 'buildDependencyModel' | 'reverseTraverse' | 'createDraft';
  member_id: string;
  swing_id?: string;
  coaching_decision_id?: string;
}

interface PrimaryFixResult {
  fix_id: string;
  name: string;
  iis_score: number;
}

// ─── Constants ───────────────────────────────────────────────────

const IIS_THRESHOLD = 0.5; // Minimum IIS score to be considered
const DECAY_FACTOR = 0.8; // Path decay for longer causality chains
const MAX_PATH_LENGTH = 5; // Maximum steps in causal chain

// ─── Helpers ─────────────────────────────────────────────────────

function createSupabaseAdmin() {
  const url = Deno.env.get('SUPABASE_URL');
  const key = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !key) throw new Error('Missing Supabase environment variables');
  return createClient(url, key);
}

/**
 * Compute Integrated Impact Score (IIS) for a candidate fix.
 * IIS = (direct_impact × relevance) + (path_length_decay)
 * Higher IIS = more likely to resolve the chain of symptoms.
 */
function computeIIS(
  directImpact: number,
  relevance: number,
  pathLength: number
): number {
  const decay = Math.pow(DECAY_FACTOR, pathLength - 1);
  return (directImpact * relevance) * decay;
}

/**
 * Build Layer A → Layer B dependency model.
 * Reads raw_measurements and computes derived_metrics from dependencies.
 */
async function buildDependencyModel(
  supabase: ReturnType<typeof createClient>,
  memberId: string,
  swingId?: string
): Promise<{ layerA: RawMeasurement[]; layerB: DerivedMetric[] }> {
  console.info(`[causal-analysis] buildDependencyModel: member=${memberId}, swing=${swingId}`);

  // Fetch Layer A: Raw measurements
  let query = supabase
    .from('raw_measurements')
    .select('*')
    .eq('member_id', memberId);

  if (swingId) {
    query = query.eq('swing_id', swingId);
  }

  const { data: layerA, error: layerAError } = await query;

  if (layerAError) {
    throw new Error(`Failed to fetch raw measurements: ${layerAError.message}`);
  }

  console.info(`[causal-analysis] Loaded ${layerA?.length || 0} raw measurements`);

  // Compute Layer B: Derived metrics from dependencies
  const derivedMetrics: DerivedMetric[] = [];

  if (layerA && layerA.length > 0) {
    // For each raw measurement, create derived metrics based on causal rules
    for (const measurement of layerA) {
      // Example: velocity_at_top depends on clubhead_speed + swing_plane
      const derived: DerivedMetric = {
        id: `derived-${measurement.id}-${Date.now()}`,
        member_id: measurement.member_id,
        swing_id: measurement.swing_id,
        metric_name: `derived_${measurement.metric_name}`,
        value: measurement.value * 1.1, // Simplified computation (normally would apply formula)
        dependencies: ['raw_' + measurement.metric_name],
        timestamp: new Date().toISOString(),
      };
      derivedMetrics.push(derived);
    }

    // Insert derived metrics into Layer B
    const { error: insertError } = await supabase
      .from('derived_metrics')
      .insert(derivedMetrics);

    if (insertError) {
      console.warn(
        `[causal-analysis] Failed to insert some derived metrics: ${insertError.message}`
      );
    }
  }

  console.info(`[causal-analysis] Generated ${derivedMetrics.length} derived metrics`);

  return {
    layerA: layerA || [],
    layerB: derivedMetrics,
  };
}

/**
 * Reverse traverse causal DAG: effect → cause
 * Starting from observed symptoms, work backwards to find root causes.
 * Compute IIS for each candidate fix and select the max IIS Primary Fix.
 */
async function reverseTraverse(
  supabase: ReturnType<typeof createClient>,
  memberId: string,
  swingId?: string
): Promise<PrimaryFixResult> {
  console.info(`[causal-analysis] reverseTraverse: member=${memberId}, swing=${swingId}`);

  // Fetch observed symptoms (Layer B derived metrics)
  let query = supabase
    .from('derived_metrics')
    .select('metric_name, value')
    .eq('member_id', memberId);

  if (swingId) {
    query = query.eq('swing_id', swingId);
  }

  const { data: symptoms } = await query;

  if (!symptoms || symptoms.length === 0) {
    throw new Error('No symptoms found for reverse traversal');
  }

  console.info(`[causal-analysis] Identified ${symptoms.length} symptoms for traversal`);

  // Fetch causal graph edges
  const { data: edges, error: edgesError } = await supabase
    .from('causal_graph_edges')
    .select('*');

  if (edgesError || !edges) {
    throw new Error(`Failed to fetch causal graph: ${edgesError?.message}`);
  }

  console.info(`[causal-analysis] Loaded ${edges.length} causal graph edges`);

  // Build adjacency list (effect → causes)
  const effectToCauses: Record<string, CausalGraphEdge[]> = {};
  for (const edge of edges) {
    if (!effectToCauses[edge.target]) {
      effectToCauses[edge.target] = [];
    }
    effectToCauses[edge.target].push(edge);
  }

  // Reverse traverse from symptoms to find candidate fixes
  const candidateFixes: Record<string, CandidateFix> = {};

  async function traverseEffect(effectName: string, pathLength: number): Promise<void> {
    if (pathLength > MAX_PATH_LENGTH) {
      return; // Prevent infinite traversal
    }

    const causes = effectToCauses[effectName];
    if (!causes || causes.length === 0) {
      return; // No more causes to traverse
    }

    for (const edge of causes) {
      const causeName = edge.source;

      // Fetch fix metadata
      const { data: fix } = await supabase
        .from('fixes')
        .select('id, name, relevance_score')
        .eq('metric_name', causeName)
        .single();

      if (fix) {
        const iis = computeIIS(edge.weight, fix.relevance_score || 0.5, pathLength);

        if (iis > IIS_THRESHOLD) {
          const fixId = `fix-${fix.id}`;
          if (!candidateFixes[fixId] || candidateFixes[fixId].iis_score < iis) {
            candidateFixes[fixId] = {
              fix_id: fixId,
              name: fix.name,
              iis_score: iis,
              path_length: pathLength,
            };
          }
        }

        // Continue traversal up the chain
        await traverseEffect(causeName, pathLength + 1);
      }
    }
  }

  // Start traversal from each symptom
  for (const symptom of symptoms) {
    await traverseEffect(symptom.metric_name, 1);
  }

  console.info(
    `[causal-analysis] Identified ${Object.keys(candidateFixes).length} candidate fixes`
  );

  // Select Primary Fix: highest IIS score (DC-4: scalar value)
  let primaryFix: PrimaryFixResult | null = null;
  let maxIIS = IIS_THRESHOLD;

  for (const [, candidate] of Object.entries(candidateFixes)) {
    if (candidate.iis_score > maxIIS) {
      maxIIS = candidate.iis_score;
      primaryFix = {
        fix_id: candidate.fix_id,
        name: candidate.name,
        iis_score: candidate.iis_score,
      };
    }
  }

  if (!primaryFix) {
    throw new Error('No suitable primary fix identified from causal analysis');
  }

  console.info(
    `[causal-analysis] Primary Fix selected: ${primaryFix.name} (IIS=${primaryFix.iis_score.toFixed(3)})`
  );

  return primaryFix;
}

/**
 * Create coaching decision with auto_draft and primary_fix (scalar).
 */
async function createDraft(
  supabase: ReturnType<typeof createClient>,
  memberId: string,
  swingId?: string
): Promise<{ coaching_decision_id: string; primary_fix: PrimaryFixResult }> {
  console.info(`[causal-analysis] createDraft: member=${memberId}, swing=${swingId}`);

  // Run reverse traversal to get primary fix
  const primaryFix = await reverseTraverse(supabase, memberId, swingId);

  // Insert coaching decision
  const { data: decision, error: insertError } = await supabase
    .from('coaching_decisions')
    .insert({
      member_id: memberId,
      swing_id: swingId || null,
      auto_draft: true,
      primary_fix: primaryFix.fix_id, // DC-4: scalar value
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })
    .select('id')
    .single();

  if (insertError) {
    throw new Error(`Failed to create coaching decision: ${insertError.message}`);
  }

  console.info(`[causal-analysis] Coaching decision created: ${decision.id}`);

  return {
    coaching_decision_id: decision.id,
    primary_fix: primaryFix,
  };
}

// ─── Main Handler ────────────────────────────────────────────────

serve(async (req: Request) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': Deno.env.get('ALLOWED_ORIGIN') ?? 'https://hellonext.app',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  };

  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const body = (await req.json()) as CausalAnalysisRequest;
    const { operation, member_id, swing_id } = body;

    if (!member_id) {
      return new Response(
        JSON.stringify({ error: 'member_id is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.info(`[causal-analysis] Operation: ${operation} on member ${member_id}`);
    const supabase = createSupabaseAdmin();

    let result: unknown;

    switch (operation) {
      case 'buildDependencyModel':
        result = await buildDependencyModel(supabase, member_id, swing_id);
        break;

      case 'reverseTraverse':
        result = await reverseTraverse(supabase, member_id, swing_id);
        break;

      case 'createDraft':
        result = await createDraft(supabase, member_id, swing_id);
        break;

      default:
        return new Response(
          JSON.stringify({ error: 'Unknown operation' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
    }

    return new Response(
      JSON.stringify({ success: true, operation, result }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('[causal-analysis] Error:', error);

    return new Response(
      JSON.stringify({
        error: 'Causal analysis failed',
        message: error instanceof Error ? error.message : 'Unknown error',
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
