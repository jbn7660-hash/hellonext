/**
 * Swing Analysis — Supabase Edge Function
 *
 * Processes swing video pose data and generates AI observations.
 *
 * Pipeline:
 * 1. Receive pose_data (keypoints per frame) + feel_check + member_id
 * 2. Fetch AI scope settings (F-013) for the pro-member pair
 * 3. Compute swing metrics (joint angles, tempo, position markers)
 * 4. Generate AI observation via GPT-4o in "curious observer" tone
 * 5. Store ai_observation record + update swing_video status
 * 6. Broadcast result via Realtime
 *
 * @function swing-analysis
 * @feature F-005, F-013
 */

import { serve } from 'https://deno.land/std@0.208.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.0';

const allowedOrigin = Deno.env.get('ALLOWED_ORIGIN') ?? 'https://hellonext.app';

const corsHeaders = {
  'Access-Control-Allow-Origin': allowedOrigin,
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface SwingAnalysisRequest {
  video_id: string;
  member_id: string;
  pose_data: PoseFrame[];
  feel_check_id: string;
}

interface PoseFrame {
  frame_index: number;
  timestamp_ms: number;
  keypoints: { name: string; x: number; y: number; score: number }[];
}

interface AIScopeSettings {
  hidden_patterns: string[];
  tone_level: 'observe_only' | 'gentle_suggest' | 'specific_guide';
}

const CHAT_API_URL = 'https://api.openai.com/v1/chat/completions';

const OBSERVATION_SYSTEM_PROMPT = `당신은 골프 스윙을 "관찰"하는 AI 어시스턴트입니다.

## 핵심 원칙
1. 교정이 아닌 관찰: "~가 보입니다" "~에 변화가 있는 것 같습니다"
2. 팩트 호기심 톤: "프로님에게 물어보세요" 등 질문 유도
3. 프로 통제권 존중: hidden_patterns에 해당하는 항목은 절대 언급하지 않음
4. Feel Check 연결: 회원의 느낌과 실제 데이터의 차이를 부드럽게 관찰

## 톤 레벨
- observe_only: 변화 관찰만. 제안 없음.
- gentle_suggest: "~해보면 어떨까요?" 수준의 부드러운 제안
- specific_guide: 구체적 드릴 추천 포함

## 출력 형식 (JSON)
{
  "observations": [
    {
      "position": "P1~P8",
      "observation": "관찰 내용",
      "error_pattern_code": "EP-XXX 또는 null",
      "coach_consultation_flag": true/false,
      "visible": true/false
    }
  ],
  "feel_accuracy_note": "Feel Check과 실제 데이터 비교 관찰",
  "summary": "1-2문장 전체 요약"
}`;

serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const payload: SwingAnalysisRequest = await req.json();
    const { video_id, member_id, pose_data, feel_check_id } = payload;

    if (!video_id || !member_id || !pose_data?.length || !feel_check_id) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    // 1. Get feel check data
    const { data: feelCheck } = await supabase
      .from('feel_checks')
      .select('feeling, notes')
      .eq('id', feel_check_id)
      .single();

    // 2. Get AI scope settings from linked pro(s)
    const { data: proLinks } = await supabase
      .from('pro_member_links')
      .select('pro_id')
      .eq('member_id', member_id)
      .eq('is_active', true);

    let scopeSettings: AIScopeSettings = {
      hidden_patterns: [],
      tone_level: 'observe_only',
    };

    if (proLinks && proLinks.length > 0) {
      const { data: scopeData } = await supabase
        .from('ai_scope_settings')
        .select('hidden_patterns, tone_level')
        .eq('member_id', member_id)
        .eq('pro_id', proLinks[0]!.pro_id)
        .maybeSingle();

      if (scopeData) {
        scopeSettings = scopeData as AIScopeSettings;
      }
    }

    // 3. Compute swing metrics from pose data
    const metrics = computeSwingMetrics(pose_data);

    // 4. Generate AI observation
    const openaiKey = Deno.env.get('OPENAI_API_KEY');
    if (!openaiKey) throw new Error('Missing OPENAI_API_KEY');

    const userPrompt = buildAnalysisPrompt(metrics, feelCheck, scopeSettings);

    const llmResponse = await fetch(CHAT_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${openaiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          { role: 'system', content: OBSERVATION_SYSTEM_PROMPT },
          { role: 'user', content: userPrompt },
        ],
        response_format: { type: 'json_object' },
        temperature: 0.4,
        max_tokens: 1500,
      }),
    });

    if (!llmResponse.ok) {
      throw new Error(`OpenAI API error: ${llmResponse.status}`);
    }

    const llmData = await llmResponse.json();
    const observation = JSON.parse(llmData.choices[0].message.content);

    // 5. Apply visibility filter (hidden patterns → visible: false)
    if (observation.observations) {
      for (const obs of observation.observations) {
        if (
          obs.error_pattern_code &&
          scopeSettings.hidden_patterns.includes(obs.error_pattern_code)
        ) {
          obs.visible = false;
        }
      }
    }

    // 6. Store AI observation
    const { data: savedObservation, error: insertError } = await supabase
      .from('ai_observations')
      .insert({
        swing_video_id: video_id,
        member_id,
        feel_check_id,
        observations: observation.observations,
        feel_accuracy_note: observation.feel_accuracy_note,
        summary: observation.summary,
        tone_level: scopeSettings.tone_level,
        raw_metrics: metrics,
      })
      .select('id')
      .single();

    if (insertError) {
      console.error('Failed to save observation:', insertError);
      throw new Error('Failed to save observation');
    }

    // 7. Update swing video status
    await supabase
      .from('swing_videos')
      .update({ status: 'analyzed', analysis_id: savedObservation.id })
      .eq('id', video_id);

    // 8. Broadcast via Realtime
    await supabase.channel(`member-${member_id}`).send({
      type: 'broadcast',
      event: 'swing_analyzed',
      payload: {
        video_id,
        observation_id: savedObservation.id,
        summary: observation.summary,
      },
    });

    console.log('Swing analysis complete', { video_id, observation_id: savedObservation.id });

    return new Response(
      JSON.stringify({ success: true, observation_id: savedObservation.id }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (err) {
    console.error('swing-analysis error:', err);
    return new Response(
      JSON.stringify({ error: 'Internal error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

/**
 * Compute swing metrics from MediaPipe 2D pose keypoints.
 * Identifies P1-P8 positions and extracts key angles.
 */
function computeSwingMetrics(frames: PoseFrame[]) {
  const totalFrames = frames.length;

  // Identify swing phase boundaries (simplified heuristic based on wrist trajectory)
  const wristPositions = frames.map((f) => {
    const leftWrist = f.keypoints.find((k) => k.name === 'left_wrist');
    const rightWrist = f.keypoints.find((k) => k.name === 'right_wrist');
    return {
      frame: f.frame_index,
      timestamp: f.timestamp_ms,
      leadWristY: leftWrist?.y ?? 0,
      trailWristY: rightWrist?.y ?? 0,
    };
  });

  // Find highest point (top of backswing → P3)
  let topFrameIdx = 0;
  let minWristY = Infinity;
  for (const wp of wristPositions) {
    if (wp.leadWristY < minWristY) {
      minWristY = wp.leadWristY;
      topFrameIdx = wp.frame;
    }
  }

  // Estimate swing phases as frame percentages
  const phases = {
    P1_address: Math.round(totalFrames * 0.0),
    P2_takeaway: Math.round(totalFrames * 0.15),
    P3_top: topFrameIdx,
    P4_downswing: Math.round((topFrameIdx + totalFrames * 0.65) / 2),
    P5_impact: Math.round(totalFrames * 0.65),
    P6_followthrough: Math.round(totalFrames * 0.75),
    P7_extension: Math.round(totalFrames * 0.85),
    P8_finish: totalFrames - 1,
  };

  // Extract key joint angles at each phase
  const phaseAngles: Record<string, Record<string, number>> = {};

  for (const [phaseName, frameIdx] of Object.entries(phases)) {
    const frame = frames[frameIdx];
    if (!frame) continue;

    const kp = Object.fromEntries(frame.keypoints.map((k) => [k.name, k]));

    phaseAngles[phaseName] = {
      left_elbow: computeAngle(kp['left_shoulder'], kp['left_elbow'], kp['left_wrist']),
      right_elbow: computeAngle(kp['right_shoulder'], kp['right_elbow'], kp['right_wrist']),
      left_knee: computeAngle(kp['left_hip'], kp['left_knee'], kp['left_ankle']),
      spine_tilt: computeAngle(kp['left_hip'], kp['left_shoulder'], kp['nose']),
    };
  }

  // Tempo calculation
  const backswingDuration = frames[phases.P3_top]?.timestamp_ms ?? 0;
  const downswingDuration =
    (frames[phases.P5_impact]?.timestamp_ms ?? 0) - backswingDuration;
  const tempoRatio =
    downswingDuration > 0 ? (backswingDuration / downswingDuration).toFixed(1) : 'N/A';

  return {
    total_frames: totalFrames,
    phases,
    phase_angles: phaseAngles,
    tempo_ratio: tempoRatio,
    backswing_duration_ms: backswingDuration,
    downswing_duration_ms: downswingDuration,
  };
}

function computeAngle(
  a?: { x: number; y: number },
  b?: { x: number; y: number },
  c?: { x: number; y: number }
): number {
  if (!a || !b || !c) return 0;
  const radians =
    Math.atan2(c.y - b.y, c.x - b.x) - Math.atan2(a.y - b.y, a.x - b.x);
  let degrees = Math.abs((radians * 180) / Math.PI);
  if (degrees > 180) degrees = 360 - degrees;
  return Math.round(degrees);
}

function buildAnalysisPrompt(
  metrics: ReturnType<typeof computeSwingMetrics>,
  feelCheck: { feeling: string; notes: string | null } | null,
  scope: AIScopeSettings
): string {
  const parts: string[] = [];

  parts.push(`## 스윙 메트릭스`);
  parts.push(`- 총 프레임: ${metrics.total_frames}`);
  parts.push(`- 템포 비율 (백스윙:다운스윙): ${metrics.tempo_ratio}`);
  parts.push(`- 백스윙 ${metrics.backswing_duration_ms}ms / 다운스윙 ${metrics.downswing_duration_ms}ms`);

  parts.push(`\n## 포지션별 관절 각도`);
  for (const [phase, angles] of Object.entries(metrics.phase_angles)) {
    parts.push(`### ${phase}`);
    for (const [joint, angle] of Object.entries(angles)) {
      parts.push(`  - ${joint}: ${angle}°`);
    }
  }

  if (feelCheck) {
    parts.push(`\n## Feel Check`);
    parts.push(`- 느낌: ${feelCheck.feeling}`);
    if (feelCheck.notes) parts.push(`- 메모: ${feelCheck.notes}`);
  }

  parts.push(`\n## AI 범위 설정`);
  parts.push(`- 톤 레벨: ${scope.tone_level}`);
  if (scope.hidden_patterns.length > 0) {
    parts.push(`- 비공개 패턴 (절대 언급 금지): ${scope.hidden_patterns.join(', ')}`);
  }

  return parts.join('\n');
}
