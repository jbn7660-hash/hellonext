/**
 * Send Notification — Supabase Edge Function
 *
 * Multi-channel notification dispatcher:
 *  1. In-app notification (always — stored in notifications table)
 *  2. Kakao Alimtalk (if enabled + phone verified)
 *  3. Push notification (if FCM token registered)
 *
 * Called internally from other Edge Functions / API routes.
 *
 * @function send-notification
 * @feature F-011, F-014
 */

import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.0';

const allowedOrigin = Deno.env.get('ALLOWED_ORIGIN') ?? 'https://hellonext.app';

const corsHeaders = {
  'Access-Control-Allow-Origin': allowedOrigin,
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface NotificationPayload {
  user_id: string;
  type: 'report' | 'reminder' | 'coupon' | 'system';
  title: string;
  body: string;
  data?: Record<string, string>;
  channels?: ('kakao' | 'push' | 'in_app')[];
}

serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const payload: NotificationPayload = await req.json();
    const { user_id, type, title, body, data, channels = ['in_app'] } = payload;

    if (!user_id || !type || !title || !body) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields: user_id, type, title, body' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const results: Record<string, { success: boolean; error?: string }> = {};

    // 1. Always create in-app notification
    if (channels.includes('in_app') || channels.length === 0) {
      const { error: insertError } = await supabase
        .from('notifications')
        .insert({
          user_id,
          type,
          title,
          body,
          data: data ?? {},
          is_read: false,
        });

      results.in_app = insertError
        ? { success: false, error: insertError.message }
        : { success: true };
    }

    // 2. Kakao Alimtalk
    if (channels.includes('kakao')) {
      const kakaoApiKey = Deno.env.get('KAKAO_ALIMTALK_API_KEY');
      const kakaoSenderId = Deno.env.get('KAKAO_ALIMTALK_SENDER_ID');

      if (!kakaoApiKey || !kakaoSenderId) {
        results.kakao = { success: false, error: 'Kakao Alimtalk not configured' };
      } else {
        // Get user's phone from auth metadata
        const { data: userData } = await supabase.auth.admin.getUserById(user_id);
        const phone = userData?.user?.phone;

        if (!phone) {
          results.kakao = { success: false, error: 'User phone not verified' };
        } else {
          try {
            // Kakao Alimtalk API call
            const templateCode = getTemplateCode(type);
            const response = await fetch('https://api-alimtalk.kakao.com/v2/sender/send', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${kakaoApiKey}`,
              },
              body: JSON.stringify({
                senderKey: kakaoSenderId,
                templateCode,
                recipientList: [
                  {
                    recipientNo: phone,
                    templateParameter: {
                      title,
                      body,
                      ...(data?.report_id ? { report_id: data.report_id } : {}),
                    },
                  },
                ],
              }),
            });

            results.kakao = response.ok
              ? { success: true }
              : { success: false, error: `Kakao API ${response.status}` };
          } catch (err) {
            results.kakao = {
              success: false,
              error: err instanceof Error ? err.message : 'Kakao send failed',
            };
          }
        }
      }
    }

    // 3. FCM Push
    if (channels.includes('push')) {
      const fcmServiceAccount = Deno.env.get('FCM_SERVICE_ACCOUNT_KEY');

      if (!fcmServiceAccount) {
        results.push = { success: false, error: 'FCM not configured' };
      } else {
        // Get user's FCM token from profile or devices table
        const { data: profile } = await supabase
          .from('member_profiles')
          .select('fcm_token')
          .eq('user_id', user_id)
          .maybeSingle();

        const { data: proProfile } = await supabase
          .from('pro_profiles')
          .select('fcm_token')
          .eq('user_id', user_id)
          .maybeSingle();

        const fcmToken = profile?.fcm_token ?? proProfile?.fcm_token;

        if (!fcmToken) {
          results.push = { success: false, error: 'No FCM token registered' };
        } else {
          try {
            // FCM v1 API (HTTP)
            const response = await fetch(
              `https://fcm.googleapis.com/v1/projects/${Deno.env.get('GCP_PROJECT_ID')}/messages:send`,
              {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': `Bearer ${fcmServiceAccount}`,
                },
                body: JSON.stringify({
                  message: {
                    token: fcmToken,
                    notification: { title, body },
                    data: data ?? {},
                    webpush: {
                      fcm_options: {
                        link: data?.report_id
                          ? `/reports/${data.report_id}`
                          : '/',
                      },
                    },
                  },
                }),
              }
            );

            results.push = response.ok
              ? { success: true }
              : { success: false, error: `FCM API ${response.status}` };
          } catch (err) {
            results.push = {
              success: false,
              error: err instanceof Error ? err.message : 'FCM send failed',
            };
          }
        }
      }
    }

    // Broadcast via Realtime for instant in-app delivery
    await supabase.channel(`user-${user_id}`).send({
      type: 'broadcast',
      event: 'notification',
      payload: { type, title, body, data },
    });

    console.log('Notification sent', { user_id, type, results });

    return new Response(
      JSON.stringify({ success: true, results }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (err) {
    console.error('send-notification error:', err);
    return new Response(
      JSON.stringify({ error: 'Internal error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

function getTemplateCode(type: string): string {
  const templates: Record<string, string> = {
    report: 'HELLONEXT_REPORT_READY',
    reminder: 'HELLONEXT_LESSON_REMINDER',
    coupon: 'HELLONEXT_COUPON_RECEIVED',
    system: 'HELLONEXT_SYSTEM_NOTICE',
  };
  return templates[type] ?? 'HELLONEXT_SYSTEM_NOTICE';
}
