/**
 * Edge Weight Calibration Edge Function
 *
 * Runs batch calibration of causal graph edge weights based on edit deltas.
 *
 * Per Patent 1 Claim 1(e) AC-4: Loads unprocessed edit_deltas, groups by causal path,
 * applies tier-weighted coefficients (tier_1=0, tier_2=1.0, tier_3=0.5), and updates
 * edge weights in the causal graph.
 *
 * @edge-function edge-weight-calibration
 * @feature F-015 AC-4
 * @patent Patent 1 Claim 1(e)
 * @dependencies Supabase client
 */

import { serve } from 'https://deno.land/std@0.208.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.0';

// ─── Types ───────────────────────────────────────────────────────

interface EditDelta {
  id: string;
  causal_path: string; // e.g., "swing_plane->clubhead_speed->ball_velocity"
  source_metric: string;
  target_metric: string;
  delta_value: number;
  tier: number; // 1, 2, or 3
  processed: boolean;
  created_at: string;
}

interface CausalGraphEdge {
  id: string;
  source: string;
  target: string;
  weight: number;
  tier: number;
  updated_at?: string;
}

interface CalibrationResult {
  causal_path: string;
  source_metric: string;
  target_metric: string;
  delta_count: number;
  tier: number;
  coefficient: number;
  old_weight: number;
  new_weight: number;
  processed_deltas: string[];
}

interface EdgeWeightCalibrationRequest {
  operation: 'calibrate';
  batch_size?: number;
}

interface CalibrationBatchResult {
  total_paths_calibrated: number;
  total_edges_updated: number;
  total_deltas_processed: number;
  calibration_results: CalibrationResult[];
  batch_timestamp: string;
}

// ─── Constants ───────────────────────────────────────────────────

// Tier-based coefficients per Patent 1 Claim 1(e)
const TIER_COEFFICIENTS: Record<number, number> = {
  1: 0.0, // No calibration for tier 1 (foundational metrics)
  2: 1.0, // Standard calibration for tier 2
  3: 0.5, // Conservative calibration for tier 3 (speculative)
};

const DEFAULT_BATCH_SIZE = 100;

// ─── Helpers ─────────────────────────────────────────────────────

function createSupabaseAdmin() {
  const url = Deno.env.get('SUPABASE_URL');
  const key = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !key) throw new Error('Missing Supabase environment variables');
  return createClient(url, key);
}

/**
 * Get tier coefficient for calibration.
 */
function getTierCoefficient(tier: number): number {
  return TIER_COEFFICIENTS[tier] ?? 0.0;
}

/**
 * Parse causal path string into edge components.
 * Example: "swing_plane->clubhead_speed->ball_velocity" → [
 *   {source: "swing_plane", target: "clubhead_speed"},
 *   {source: "clubhead_speed", target: "ball_velocity"}
 * ]
 */
function parsePathEdges(path: string): Array<{ source: string; target: string }> {
  const parts = path.split('->').map((p) => p.trim());
  const edges: Array<{ source: string; target: string }> = [];

  for (let i = 0; i < parts.length - 1; i++) {
    edges.push({
      source: parts[i],
      target: parts[i + 1],
    });
  }

  return edges;
}

/**
 * Calculate adjusted weight based on delta and coefficient.
 * Adjusted Weight = Current Weight + (Delta Value × Coefficient)
 */
function calculateAdjustedWeight(
  currentWeight: number,
  deltaValue: number,
  coefficient: number
): number {
  const adjustment = deltaValue * coefficient;
  const newWeight = currentWeight + adjustment;

  // Clamp to reasonable range [0.0, 2.0]
  return Math.max(0.0, Math.min(2.0, newWeight));
}

/**
 * Run batch calibration of edge weights.
 */
async function calibrate(
  supabase: ReturnType<typeof createClient>,
  batchSize: number = DEFAULT_BATCH_SIZE
): Promise<CalibrationBatchResult> {
  console.info(
    `[edge-weight-calibration] calibrate: batch_size=${batchSize}`
  );

  // Fetch unprocessed edit deltas
  const { data: deltas, error: deltaError } = await supabase
    .from('edit_deltas')
    .select('*')
    .eq('processed', false)
    .limit(batchSize);

  if (deltaError || !deltas) {
    throw new Error(`Failed to fetch edit deltas: ${deltaError?.message}`);
  }

  console.info(`[edge-weight-calibration] Fetched ${deltas.length} unprocessed deltas`);

  // Group deltas by causal path
  const deltasByPath: Record<string, EditDelta[]> = {};
  for (const delta of deltas) {
    if (!deltasByPath[delta.causal_path]) {
      deltasByPath[delta.causal_path] = [];
    }
    deltasByPath[delta.causal_path].push(delta);
  }

  console.info(
    `[edge-weight-calibration] Grouped into ${Object.keys(deltasByPath).length} causal paths`
  );

  const calibrationResults: CalibrationResult[] = [];
  const processedDeltaIds: string[] = [];
  let totalEdgesUpdated = 0;

  // Process each causal path
  for (const [causePath, pathDeltas] of Object.entries(deltasByPath)) {
    // Determine tier from first delta (all should have same tier for a path)
    const tier = pathDeltas[0]?.tier || 2;
    const coefficient = getTierCoefficient(tier);

    console.info(
      `[edge-weight-calibration] Processing path: ${causePath}, tier=${tier}, coefficient=${coefficient}`
    );

    // Parse edges from causal path
    const edges = parsePathEdges(causePath);

    // For each edge in the path
    for (const edge of edges) {
      // Fetch current edge from graph
      const { data: graphEdge, error: edgeError } = await supabase
        .from('causal_graph_edges')
        .select('*')
        .eq('source', edge.source)
        .eq('target', edge.target)
        .single();

      if (edgeError && edgeError.code !== 'PGRST116') {
        // PGRST116 = no rows returned (create new edge)
        console.warn(
          `[edge-weight-calibration] Error fetching edge ${edge.source}->${edge.target}: ${edgeError.message}`
        );
        continue;
      }

      const currentWeight = graphEdge?.weight ?? 1.0;
      const oldWeight = currentWeight;

      // Calculate average delta across all deltas for this path
      const avgDelta =
        pathDeltas.reduce((sum, d) => sum + d.delta_value, 0) / pathDeltas.length;

      // Calculate adjusted weight
      const newWeight = calculateAdjustedWeight(currentWeight, avgDelta, coefficient);

      console.info(
        `[edge-weight-calibration] Edge: ${edge.source}->${edge.target}, weight: ${oldWeight.toFixed(3)} → ${newWeight.toFixed(3)}`
      );

      // Update or insert edge in causal_graph_edges
      if (graphEdge) {
        // Update existing edge
        const { error: updateError } = await supabase
          .from('causal_graph_edges')
          .update({
            weight: newWeight,
            updated_at: new Date().toISOString(),
          })
          .eq('id', graphEdge.id);

        if (updateError) {
          console.warn(
            `[edge-weight-calibration] Failed to update edge ${graphEdge.id}: ${updateError.message}`
          );
          continue;
        }
      } else {
        // Insert new edge
        const { error: insertError } = await supabase
          .from('causal_graph_edges')
          .insert({
            source: edge.source,
            target: edge.target,
            weight: newWeight,
            tier,
            updated_at: new Date().toISOString(),
          });

        if (insertError) {
          console.warn(
            `[edge-weight-calibration] Failed to insert edge ${edge.source}->${edge.target}: ${insertError.message}`
          );
          continue;
        }
      }

      totalEdgesUpdated++;

      // Record calibration result
      calibrationResults.push({
        causal_path: causePath,
        source_metric: edge.source,
        target_metric: edge.target,
        delta_count: pathDeltas.length,
        tier,
        coefficient,
        old_weight: oldWeight,
        new_weight: newWeight,
        processed_deltas: pathDeltas.map((d) => d.id),
      });
    }

    // Collect processed delta IDs
    pathDeltas.forEach((d) => processedDeltaIds.push(d.id));
  }

  console.info(
    `[edge-weight-calibration] Updating ${processedDeltaIds.length} deltas as processed`
  );

  // Mark all processed deltas as processed
  if (processedDeltaIds.length > 0) {
    const { error: markError } = await supabase
      .from('edit_deltas')
      .update({ processed: true })
      .in('id', processedDeltaIds);

    if (markError) {
      console.warn(`[edge-weight-calibration] Failed to mark deltas as processed: ${markError.message}`);
    }
  }

  console.info(
    `[edge-weight-calibration] Calibration complete: ${totalEdgesUpdated} edges updated, ${processedDeltaIds.length} deltas processed`
  );

  return {
    total_paths_calibrated: Object.keys(deltasByPath).length,
    total_edges_updated: totalEdgesUpdated,
    total_deltas_processed: processedDeltaIds.length,
    calibration_results: calibrationResults,
    batch_timestamp: new Date().toISOString(),
  };
}

// ─── Main Handler ────────────────────────────────────────────────

serve(async (req: Request) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': Deno.env.get('ALLOWED_ORIGIN') ?? 'https://hellonext.app',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  };

  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const body = (await req.json()) as EdgeWeightCalibrationRequest;
    const { operation, batch_size } = body;

    if (operation !== 'calibrate') {
      return new Response(
        JSON.stringify({ error: 'Unknown operation' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.info(`[edge-weight-calibration] Operation: ${operation}`);
    const supabase = createSupabaseAdmin();

    const result = await calibrate(supabase, batch_size);

    return new Response(
      JSON.stringify({ success: true, result }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('[edge-weight-calibration] Error:', error);

    return new Response(
      JSON.stringify({
        error: 'Calibration failed',
        message: error instanceof Error ? error.message : 'Unknown error',
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
