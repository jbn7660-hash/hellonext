/**
 * Coupon Activate Edge Function (F-012)
 *
 * Handles PLG coupon lifecycle:
 *  - Generate unique coupon codes for a pro
 *  - Activate a coupon when member redeems it
 *  - Track usage and expiry (90 days from activation)
 *
 * @function coupon-activate
 * @feature F-012
 */

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const ALLOWED_ORIGIN = Deno.env.get('ALLOWED_ORIGIN') ?? 'https://hellonext.app';

const corsHeaders = {
  'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface GenerateRequest {
  action: 'generate';
  quantity: number; // How many codes to generate
  source: 'plg_free' | 'purchased_bundle';
  bundle_order_id?: string; // If purchased
}

interface RedeemRequest {
  action: 'redeem';
  code: string;
}

type RequestBody = GenerateRequest | RedeemRequest;

serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    // Auth
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return jsonResponse({ error: 'Missing authorization' }, 401);
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      return jsonResponse({ error: 'Unauthorized' }, 401);
    }

    const body: RequestBody = await req.json();

    // ─── Action: Generate Coupon Codes ───────────────────────────
    if (body.action === 'generate') {
      return await handleGenerate(supabase, user.id, body as GenerateRequest);
    }

    // ─── Action: Redeem a Coupon Code ────────────────────────────
    if (body.action === 'redeem') {
      return await handleRedeem(supabase, user.id, body as RedeemRequest);
    }

    return jsonResponse({ error: 'Invalid action' }, 400);
  } catch (err) {
    console.error('coupon-activate error:', err);
    return jsonResponse({ error: 'Internal server error' }, 500);
  }
});

// ─── Generate ────────────────────────────────────────────────────

async function handleGenerate(
  supabase: ReturnType<typeof createClient>,
  userId: string,
  params: GenerateRequest
) {
  // Verify pro identity
  const { data: proProfile } = await supabase
    .from('pro_profiles')
    .select('id')
    .eq('user_id', userId)
    .single();

  if (!proProfile) {
    return jsonResponse({ error: 'Pro profile not found' }, 403);
  }

  const { quantity, source, bundle_order_id } = params;

  if (quantity < 1 || quantity > 30) {
    return jsonResponse({ error: 'Quantity must be 1-30' }, 400);
  }

  // For PLG free: check limit (3 free per pro)
  if (source === 'plg_free') {
    const { count } = await supabase
      .from('coupons')
      .select('*', { count: 'exact', head: true })
      .eq('pro_id', proProfile.id)
      .eq('source', 'plg_free');

    if ((count ?? 0) + quantity > 3) {
      return jsonResponse(
        { error: 'PLG 무료 쿠폰은 최대 3장까지 생성 가능합니다.' },
        400
      );
    }
  }

  // Generate unique codes
  const coupons = Array.from({ length: quantity }, () => ({
    pro_id: proProfile.id,
    code: generateCouponCode(),
    source,
    bundle_order_id: bundle_order_id ?? null,
    status: 'available',
    expires_at: null, // Set on activation (90 days from redeem)
  }));

  const { data, error } = await supabase
    .from('coupons')
    .insert(coupons)
    .select('id, code, source, status, created_at');

  if (error) {
    console.error('Coupon insert failed:', error);
    return jsonResponse({ error: 'Failed to generate coupons' }, 500);
  }

  return jsonResponse({ data, generated: data.length });
}

// ─── Redeem ──────────────────────────────────────────────────────

async function handleRedeem(
  supabase: ReturnType<typeof createClient>,
  userId: string,
  params: RedeemRequest
) {
  const { code } = params;

  if (!code || code.length < 6) {
    return jsonResponse({ error: 'Invalid coupon code' }, 400);
  }

  // Fetch coupon
  const { data: coupon, error: fetchError } = await supabase
    .from('coupons')
    .select('*, pro_profiles!inner(user_id, display_name)')
    .eq('code', code.toUpperCase().trim())
    .single();

  if (fetchError || !coupon) {
    return jsonResponse({ error: '유효하지 않은 쿠폰 코드입니다.' }, 404);
  }

  if (coupon.status !== 'available') {
    const statusMsg: Record<string, string> = {
      activated: '이미 사용된 쿠폰입니다.',
      expired: '만료된 쿠폰입니다.',
      revoked: '취소된 쿠폰입니다.',
    };
    return jsonResponse(
      { error: statusMsg[coupon.status] ?? '사용할 수 없는 쿠폰입니다.' },
      400
    );
  }

  // Activate: set member, status, expiry (90 days)
  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + 90);

  const { data: updated, error: updateError } = await supabase
    .from('coupons')
    .update({
      status: 'activated',
      member_user_id: userId,
      activated_at: new Date().toISOString(),
      expires_at: expiresAt.toISOString(),
    })
    .eq('id', coupon.id)
    .eq('status', 'available') // Optimistic lock
    .select('id, code, status, activated_at, expires_at, pro_id')
    .single();

  if (updateError || !updated) {
    return jsonResponse({ error: '쿠폰 활성화에 실패했습니다.' }, 500);
  }

  // Create pro-member relationship if not exists
  await supabase
    .from('pro_member_links')
    .upsert(
      {
        pro_id: coupon.pro_id,
        member_user_id: userId,
        status: 'active',
        linked_via: 'coupon',
      },
      { onConflict: 'pro_id,member_user_id' }
    );

  // Notify pro about new member activation
  await supabase.functions.invoke('send-notification', {
    body: {
      user_id: coupon.pro_profiles.user_id,
      type: 'coupon_activated',
      title: '쿠폰이 활성화되었습니다',
      body: `새 회원이 쿠폰 ${code}를 사용하여 등록했습니다.`,
      data: { coupon_id: updated.id, member_user_id: userId },
    },
  });

  return jsonResponse({
    data: updated,
    pro_name: coupon.pro_profiles.display_name,
    expires_at: expiresAt.toISOString(),
  });
}

// ─── Helpers ─────────────────────────────────────────────────────

function generateCouponCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // No I,O,0,1 to avoid confusion
  const segments = [4, 4]; // Format: XXXX-XXXX
  return segments
    .map((len) =>
      Array.from({ length: len }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
    )
    .join('-');
}

function jsonResponse(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}
