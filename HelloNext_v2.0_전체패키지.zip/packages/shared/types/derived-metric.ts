/** Layer B: Derived Metric (DC-1 — Recalculable) */
export interface DerivedMetric {
  id: string;
  session_id: string;
  compound_metrics: CompoundMetrics;
  auto_detected_symptoms: string[];
  dependency_edges: DependencyEdge[];
  formula_id: string;
  created_at: string;
  recalculated_at: string | null;
}

export interface CompoundMetrics {
  x_factor?: number;
  swing_tempo?: number;
  hip_rotation?: number;
  shoulder_rotation?: number;
  [key: string]: number | undefined;
}

export interface DependencyEdge {
  from_symptom: string;
  to_symptom: string;
  strength: number;
}
