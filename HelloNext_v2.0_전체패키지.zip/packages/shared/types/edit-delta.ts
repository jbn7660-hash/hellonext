/** Edit Delta Record (Patent 1 Claim 3) */
export interface EditDelta {
  id: string;
  decision_id: string;
  edited_fields: string[];
  original_value: Record<string, unknown>;
  edited_value: Record<string, unknown>;
  delta_value: Record<string, unknown>;
  data_quality_tier: 'tier_1' | 'tier_2' | 'tier_3';
  created_at: string;
}

/** Compute edit delta between original and edited coaching decisions */
export function computeEditDelta(
  original: Record<string, unknown>,
  edited: Record<string, unknown>
): { edited_fields: string[]; delta_value: Record<string, unknown> } {
  const edited_fields: string[] = [];
  const delta_value: Record<string, unknown> = {};

  for (const key of Object.keys(edited)) {
    if (JSON.stringify(original[key]) !== JSON.stringify(edited[key])) {
      edited_fields.push(key);
      delta_value[key] = { from: original[key], to: edited[key] };
    }
  }

  return { edited_fields, delta_value };
}
