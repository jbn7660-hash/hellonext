/** Layer C: Coaching Decision (DC-1, DC-4 — Coach-Editable) */
export interface CoachingDecision {
  id: string;
  session_id: string;
  coach_profile_id: string;
  primary_fix: string | null; // DC-4: scalar (single node only)
  auto_draft: AutoDraft;
  coach_edited: AutoDraft | null;
  data_quality_tier: 'tier_1' | 'tier_2' | 'tier_3';
  created_at: string;
  updated_at: string;
}

export interface AutoDraft {
  detected_symptoms: string[];
  primary_fix_candidate: string;
  iis_scores: Record<string, number>;
  causal_path: string[];
  recommendations: string[];
}
