import {
  CONFIDENCE_T1,
  CONFIDENCE_T2,
  classifyConfidence,
  type ConfidenceState,
} from '../constants/confidence-thresholds';

/**
 * Validate measurement confidence score range
 */
export function validateConfidenceScore(score: number): void {
  if (score < 0 || score > 1) {
    throw new Error(
      `Invalid confidence score: ${score}. Must be between 0 and 1.`
    );
  }
}

/**
 * Calculate composite measurement confidence (DC-2)
 * measurement_confidence = keypoint_visibility × camera_angle_penalty
 *   × motion_blur_penalty × occlusion_penalty × K
 */
export function calculateMeasurementConfidence(params: {
  keypoint_visibility: number;
  camera_angle_penalty: number;
  motion_blur_penalty: number;
  occlusion_penalty: number;
  K: number;
}): number {
  const score =
    params.keypoint_visibility *
    params.camera_angle_penalty *
    params.motion_blur_penalty *
    params.occlusion_penalty *
    params.K;

  return Math.max(0, Math.min(1, score));
}

/**
 * Determine if verification queue token should be issued (Patent 3 Claim 4)
 * Only pending_verification state gets tokens
 */
export function shouldIssueVerificationToken(state: ConfidenceState): boolean {
  return state === 'pending_verification';
}
